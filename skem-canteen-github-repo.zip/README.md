# SKEM Canteens Management System

Production-grade Canteen Management, Invoices & Billing, and Daily Sales System.

## Deploying on Vercel
1. Connect this repository to your Vercel project `skem_canteen_management`.
2. Framework: Vite
3. Build Command: `npm run build`
4. Output Directory: `dist`

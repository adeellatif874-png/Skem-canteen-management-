import { initializeApp } from 'firebase/app';
import {
  getFirestore,
  doc,
  onSnapshot,
  setDoc,
  enableIndexedDbPersistence,
  setLogLevel,
  terminate
} from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import firebaseConfig from '../firebase-applet-config.json';
import { AppState } from './types';
import { getDeletedIds } from './lib/storage';

// Silence internal Firestore SDK console errors
try {
  setLogLevel('silent');
} catch (e) {
  // Ignore
}

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

export const auth = getAuth(app);

const QUOTA_EXCEEDED_KEY = 'firestore_quota_exceeded_timestamp';

function isQuotaExceededRecently(): boolean {
  try {
    const raw = localStorage.getItem(QUOTA_EXCEEDED_KEY);
    if (raw) {
      const timestamp = parseInt(raw, 10);
      // Only keep quota block for 30 minutes, then auto-retry
      if (Date.now() - timestamp < 30 * 60 * 1000) {
        return true;
      } else {
        localStorage.removeItem(QUOTA_EXCEEDED_KEY);
      }
    }
  } catch (e) {
    // Ignore storage issues
  }
  return false;
}

function markQuotaExceeded() {
  try {
    localStorage.setItem(QUOTA_EXCEEDED_KEY, Date.now().toString());
  } catch (e) {
    // Ignore storage issues
  }
}

let isQuotaExceededLocal = isQuotaExceededRecently();
let currentUnsubListener: (() => void) | null = null;

// Enable offline persistence if available and quota not exceeded
if (!isQuotaExceededLocal) {
  try {
    enableIndexedDbPersistence(db).catch((err) => {
      if (err.code === 'failed-precondition') {
        console.warn('Multiple tabs open, persistence can only be enabled in one tab at a time.');
      } else if (err.code === 'unimplemented') {
        console.warn('The current browser does not support all of the features required to enable persistence');
      }
    });
  } catch (e) {
    console.log('Persistence initialization skipped:', e);
  }
}

// Ensure auth state check without throwing errors if anonymous auth is restricted
export function ensureAuth() {
  return Promise.resolve(auth.currentUser);
}

const STATE_DOC_REF = doc(db, 'app_state', 'main');

// Real-time listener for cloud state
export function subscribeToCloudState(
  onUpdate: (cloudState: Partial<AppState>) => void,
  onStatusChange?: (status: 'connecting' | 'synced' | 'offline' | 'error') => void
) {
  if (isQuotaExceededRecently()) {
    if (onStatusChange) onStatusChange('offline');
    return () => {};
  }

  if (onStatusChange) onStatusChange('connecting');

  // Attempt auth in background without blocking snapshot subscription
  ensureAuth().catch(() => {});

  try {
    const unsub = onSnapshot(
      STATE_DOC_REF,
      (docSnapshot) => {
        if (docSnapshot.exists()) {
          const data = docSnapshot.data() as Partial<AppState>;
          onUpdate(data);
        }
        if (onStatusChange) onStatusChange('synced');
      },
      (error: any) => {
        const isQuotaErr =
          error?.code === 'resource-exhausted' ||
          (error?.message && error.message.includes('Quota limit exceeded')) ||
          (error?.message && error.message.includes('resource-exhausted'));

        if (isQuotaErr) {
          isQuotaExceededLocal = true;
          markQuotaExceeded();
          if (currentUnsubListener) {
            try { currentUnsubListener(); } catch (e) { /* ignore */ }
            currentUnsubListener = null;
          }
        } else {
          console.warn('Firestore listener notice:', error?.message || error);
        }
        if (onStatusChange) onStatusChange(isQuotaErr ? 'offline' : 'synced');
      }
    );

    currentUnsubListener = unsub;

    return () => {
      if (currentUnsubListener) {
        try { currentUnsubListener(); } catch (e) { /* ignore */ }
        currentUnsubListener = null;
      }
    };
  } catch (err: any) {
    console.warn('Firestore subscription exception:', err);
    if (onStatusChange) onStatusChange('offline');
    return () => {};
  }
}

// Save state to cloud Firestore
let saveTimeout: any = null;
let lastSavedHash: string = '';

export function saveStateToCloud(state: AppState, immediate: boolean = false) {
  if (isQuotaExceededRecently()) {
    return;
  }

  // Calculate state fingerprint to avoid redundant writes, including invoice details
  const invoicesFingerprint = (state.invoices || [])
    .map((inv) => `${inv.id}:${inv.buyerAddress}:${inv.poDate || ''}:${inv.totalNetAmount || 0}`)
    .join(';');
  const stateSummary = `${state.canteens?.length || 0}-${state.dailyEntries?.length || 0}-${state.canteenCashDeposits?.length || 0}-${state.staffList?.length || 0}-${state.attendanceRecords?.length || 0}-${state.staffFinancials?.length || 0}-${state.invoices?.length || 0}-[${invoicesFingerprint}]-${state.parties?.length || 0}-${state.partyTransactions?.length || 0}-${state.windowShiftSales?.length || 0}-${state.labourWorkers?.length || 0}-${state.labourTokenIssues?.length || 0}-${state.labourTokenPayments?.length || 0}-${state.pettyCashExpenses?.length || 0}-${state.pettyCashFunds?.length || 0}-${state.currencySymbol}-${state.pinCode}-${state.isLocked}-${state.lockedCanteenId}`;

  if (!immediate && stateSummary === lastSavedHash) {
    return;
  }

  if (saveTimeout) {
    clearTimeout(saveTimeout);
    saveTimeout = null;
  }

  const executeSave = async () => {
    if (isQuotaExceededRecently()) return;

    try {
      const deleted = getDeletedIds();
      const purge = <T extends { id?: string }>(arr: any[]): T[] => {
        if (!Array.isArray(arr)) return [];
        return arr.filter((x) => x && x.id && !deleted.has(x.id));
      };

      const payload = {
        canteens: purge(state.canteens || []),
        dailyEntries: purge(state.dailyEntries || []),
        canteenCashDeposits: purge(state.canteenCashDeposits || []),
        staffList: purge(state.staffList || []),
        attendanceRecords: purge(state.attendanceRecords || []),
        staffFinancials: purge(state.staffFinancials || []),
        invoices: purge(state.invoices || []),
        parties: purge(state.parties || []),
        partyTransactions: purge(state.partyTransactions || []),
        windowShiftSales: purge(state.windowShiftSales || []),
        labourWorkers: purge(state.labourWorkers || []),
        labourTokenIssues: purge(state.labourTokenIssues || []),
        labourTokenPayments: purge(state.labourTokenPayments || []),
        pettyCashExpenses: purge(state.pettyCashExpenses || []),
        pettyCashFunds: purge(state.pettyCashFunds || []),
        currencySymbol: state.currencySymbol || 'Rs.',
        pinCode: state.pinCode || '',
        isLocked: state.isLocked || false,
        lockedCanteenId: state.lockedCanteenId || '',
        updatedAt: new Date().toISOString(),
      };

      await setDoc(STATE_DOC_REF, payload, { merge: true });
      lastSavedHash = stateSummary;
    } catch (error: any) {
      const isQuotaErr =
        error?.code === 'resource-exhausted' ||
        (error?.message && error.message.includes('Quota limit exceeded')) ||
        (error?.message && error.message.includes('resource-exhausted'));

      if (isQuotaErr) {
        isQuotaExceededLocal = true;
        markQuotaExceeded();
        if (currentUnsubListener) {
          try { currentUnsubListener(); } catch (e) { /* ignore */ }
          currentUnsubListener = null;
        }
      } else {
        console.warn('Firestore save notice:', error?.message || error);
      }
    }
  };

  if (immediate) {
    executeSave();
  } else {
    saveTimeout = setTimeout(executeSave, 800);
  }
}



import React, { useState, useEffect, useRef } from 'react';
import { RefreshCw, Sparkles, X, Menu, PlusCircle, Lock, Cloud, Store } from 'lucide-react';
import {
  AppState,
  Canteen,
  DailyEntry,
  Staff,
  AttendanceRecord,
  StaffFinancialRecord,
  Invoice,
  InvoiceChequePayment,
  Party,
  PartyTransaction,
  WindowShiftSale,
  LabourWorker,
  LabourTokenIssue,
  LabourTokenPayment,
  PettyCashExpense,
  PettyCashFund,
  CanteenCashDeposit,
} from './types';
import {
  getInitialState,
  saveStateToStorage,
  clearAllAppData,
  getFreshCleanState,
  initialCanteens,
  recordDeletedId,
  getDeletedIds,
} from './lib/storage';
import { resolveBuyerAddress } from './lib/invoiceUtils';
import { subscribeToCloudState, saveStateToCloud } from './firebase';
import { NavTab } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { CanteensView } from './components/CanteensView';
import { DailyEntryView } from './components/DailyEntryView';
import { PettyCashView } from './components/PettyCashView';
import { StaffView } from './components/StaffView';
import { AttendanceView } from './components/AttendanceView';
import { StaffFinancialsView } from './components/StaffFinancialsView';
import { InvoicesView } from './components/InvoicesView';
import { PartiesView } from './components/PartiesView';
import { WindowSalesView } from './components/WindowSalesView';
import { LabourTokensView } from './components/LabourTokensView';
import { ReportsView } from './components/ReportsView';
import { SettingsView } from './components/SettingsView';
import { LockScreenModal } from './components/LockScreenModal';

// Helper to merge local and cloud arrays without losing data or resurrecting deleted items
function smartMerge<T extends { id: string }>(localList: T[], cloudList?: T[]): T[] {
  const deletedSet = getDeletedIds();
  const filterDeleted = (list: T[]) => (list || []).filter((item) => item && item.id && !deletedSet.has(item.id));

  const cleanLocal = filterDeleted(localList);
  if (!Array.isArray(cloudList)) return cleanLocal;
  const cleanCloud = filterDeleted(cloudList);

  if (cleanLocal.length === 0) return cleanCloud;
  if (cleanCloud.length === 0) return cleanLocal;

  const map = new Map<string, T>();
  cleanLocal.forEach((item) => {
    if (item && item.id) map.set(item.id, item);
  });
  cleanCloud.forEach((item) => {
    if (item && item.id) map.set(item.id, item);
  });

  return Array.from(map.values()).filter((item) => !deletedSet.has(item.id));
}

export default function App() {
  const [state, setState] = useState<AppState>(getInitialState);
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [selectedCanteenId, setSelectedCanteenId] = useState<string>('all');
  const [quickAddEntryOpen, setQuickAddEntryOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [updateAvailable, setUpdateAvailable] = useState(false);
  const [cloudStatus, setCloudStatus] = useState<'connecting' | 'synced' | 'offline' | 'error'>('connecting');
  const [isRemoteUpdate, setIsRemoteUpdate] = useState(false);
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDateStr, setCurrentDateStr] = useState<string>('');
  const isCloudInitialized = useRef(false);

  // Live real-time clock ticker
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
      setCurrentDateStr(
        now.toLocaleDateString('en-US', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Listen for service worker updates
  useEffect(() => {
    const handleUpdate = () => setUpdateAvailable(true);
    window.addEventListener('app-update-available', handleUpdate);
    return () => window.removeEventListener('app-update-available', handleUpdate);
  }, []);

  // Subscribe to Firebase Cloud Firestore updates
  useEffect(() => {
    const unsubscribe = subscribeToCloudState(
      (cloudData) => {
        isCloudInitialized.current = true;
        if (cloudData && typeof cloudData === 'object') {
          setIsRemoteUpdate(true);
          setState((prev) => {
            const newState: AppState = {
              canteens: smartMerge(prev.canteens, cloudData.canteens),
              dailyEntries: smartMerge(prev.dailyEntries, cloudData.dailyEntries),
              staffList: smartMerge(prev.staffList, cloudData.staffList),
              attendanceRecords: smartMerge(prev.attendanceRecords, cloudData.attendanceRecords),
              staffFinancials: smartMerge(prev.staffFinancials, cloudData.staffFinancials),
              invoices: smartMerge(prev.invoices || [], cloudData.invoices).map((inv) => ({
                ...inv,
                buyerAddress: resolveBuyerAddress(inv.buyerAddress),
                poDate: '',
              })),
              invoiceChequePayments: smartMerge(prev.invoiceChequePayments || [], cloudData.invoiceChequePayments),
              parties: smartMerge(prev.parties || [], cloudData.parties),
              partyTransactions: smartMerge(prev.partyTransactions || [], cloudData.partyTransactions),
              windowShiftSales: smartMerge(prev.windowShiftSales || [], cloudData.windowShiftSales),
              labourWorkers: smartMerge(prev.labourWorkers || [], cloudData.labourWorkers),
              labourTokenIssues: smartMerge(prev.labourTokenIssues || [], cloudData.labourTokenIssues),
              labourTokenPayments: smartMerge(prev.labourTokenPayments || [], cloudData.labourTokenPayments),
              pettyCashExpenses: smartMerge(prev.pettyCashExpenses || [], cloudData.pettyCashExpenses),
              pettyCashFunds: smartMerge(prev.pettyCashFunds || [], cloudData.pettyCashFunds),
              currencySymbol: typeof cloudData.currencySymbol === 'string' && cloudData.currencySymbol.trim() !== '' ? cloudData.currencySymbol : prev.currencySymbol,
              pinCode: typeof cloudData.pinCode === 'string' ? cloudData.pinCode : prev.pinCode,
              isLocked: typeof cloudData.isLocked === 'boolean' ? cloudData.isLocked : prev.isLocked,
              lockedCanteenId: typeof cloudData.lockedCanteenId === 'string' ? cloudData.lockedCanteenId : prev.lockedCanteenId,
            };
            saveStateToStorage(newState);

            // Check if cloud had older address or poDate; if so, persist migrated invoices to Firestore immediately
            const needsCloudMigration = Array.isArray(cloudData.invoices) && cloudData.invoices.some((inv: any) => {
              const currentAddr = inv?.buyerAddress || '';
              const lower = currentAddr.toLowerCase();
              return (
                !currentAddr ||
                lower.includes('seikhupura') ||
                lower.includes('sheikhupura') ||
                lower.includes('35 k.m') ||
                lower.includes('35km') ||
                Boolean(inv?.poDate)
              );
            });

            if (needsCloudMigration) {
              saveStateToCloud(newState, true);
            }

            return newState;
          });
          setTimeout(() => setIsRemoteUpdate(false), 500);
        }
      },
      (status) => setCloudStatus(status)
    );

    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
  }, []);

  const handleApplyUpdate = async () => {
    try {
      if ('caches' in window) {
        const keys = await caches.keys();
        await Promise.all(keys.map((k) => caches.delete(k)));
      }
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const reg of registrations) {
          await reg.unregister();
        }
      }
    } catch (e) {
      // Ignore
    }
    window.location.reload();
  };

  // Sync state to localStorage and cloud whenever state changes
  useEffect(() => {
    saveStateToStorage(state);

    const hasContent =
      (state.dailyEntries && state.dailyEntries.length > 0) ||
      (state.staffList && state.staffList.length > 0) ||
      (state.attendanceRecords && state.attendanceRecords.length > 0) ||
      (state.staffFinancials && state.staffFinancials.length > 0) ||
      (state.invoices && state.invoices.length > 0) ||
      (state.invoiceChequePayments && state.invoiceChequePayments.length > 0) ||
      (state.parties && state.parties.length > 0) ||
      (state.windowShiftSales && state.windowShiftSales.length > 0) ||
      (state.labourWorkers && state.labourWorkers.length > 0) ||
      (state.labourTokenIssues && state.labourTokenIssues.length > 0);

    // Only push to cloud if remote update is not currently processing, AND (cloud is initialized OR state is not empty)
    if (!isRemoteUpdate && (isCloudInitialized.current || hasContent)) {
      saveStateToCloud(state);
    }
  }, [state, isRemoteUpdate]);

  // Helper to ensure critical state updates (like deletions) persist immediately both to LocalStorage and Cloud
  const applyStateWithImmediateSync = (updater: (prev: AppState) => AppState) => {
    setState((prev) => {
      const next = updater(prev);
      saveStateToStorage(next);
      saveStateToCloud(next, true);
      return next;
    });
  };

  // Canteen Actions
  const handleAddCanteen = (canteenData: Omit<Canteen, 'id' | 'createdAt'>) => {
    const newCanteen: Canteen = {
      ...canteenData,
      id: `cant-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      canteens: [newCanteen, ...prev.canteens],
    }));
  };

  const handleEditCanteen = (id: string, updated: Partial<Canteen>) => {
    setState((prev) => ({
      ...prev,
      canteens: prev.canteens.map((c) => (c.id === id ? { ...c, ...updated } : c)),
    }));
  };

  const handleDeleteCanteen = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      canteens: prev.canteens.filter((c) => c.id !== id),
    }));
  };

  // Daily Entry Actions
  const handleAddDailyEntry = (
    data: Omit<DailyEntry, 'id' | 'createdAt' | 'totalSale' | 'netAmount'>
  ) => {
    const totalSale = data.normalSale + data.tokenSale;
    const netAmount = totalSale - data.purchase - data.expenses;

    const newEntry: DailyEntry = {
      ...data,
      id: `de-${Date.now()}`,
      totalSale,
      netAmount,
      createdAt: new Date().toISOString(),
    };

    setState((prev) => ({
      ...prev,
      dailyEntries: [newEntry, ...prev.dailyEntries],
    }));
  };

  const handleEditDailyEntry = (
    id: string,
    data: Omit<DailyEntry, 'id' | 'createdAt' | 'totalSale' | 'netAmount'>
  ) => {
    const totalSale = data.normalSale + data.tokenSale;
    const netAmount = totalSale - data.purchase - data.expenses;

    setState((prev) => ({
      ...prev,
      dailyEntries: prev.dailyEntries.map((e) =>
        e.id === id ? { ...e, ...data, totalSale, netAmount } : e
      ),
    }));
  };

  const handleDeleteDailyEntry = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      dailyEntries: prev.dailyEntries.filter((e) => e.id !== id),
    }));
  };

  // Canteen Cash Deposit Actions (Bank / Head Office deposits)
  const handleAddCashDeposit = (
    data: Omit<CanteenCashDeposit, 'id' | 'createdAt'>
  ) => {
    const newDeposit: CanteenCashDeposit = {
      ...data,
      id: `dep-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      canteenCashDeposits: [newDeposit, ...(prev.canteenCashDeposits || [])],
    }));
  };

  const handleEditCashDeposit = (
    id: string,
    data: Partial<CanteenCashDeposit>
  ) => {
    setState((prev) => ({
      ...prev,
      canteenCashDeposits: (prev.canteenCashDeposits || []).map((d) =>
        d.id === id ? { ...d, ...data } : d
      ),
    }));
  };

  const handleDeleteCashDeposit = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      canteenCashDeposits: (prev.canteenCashDeposits || []).filter((d) => d.id !== id),
    }));
  };

  // Staff Actions
  const handleAddStaff = (staffData: Omit<Staff, 'id' | 'createdAt'>) => {
    const newStaff: Staff = {
      ...staffData,
      id: `st-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      staffList: [newStaff, ...prev.staffList],
    }));
  };

  const handleEditStaff = (id: string, updated: Partial<Staff>) => {
    setState((prev) => ({
      ...prev,
      staffList: prev.staffList.map((s) => (s.id === id ? { ...s, ...updated } : s)),
    }));
  };

  const handleDeleteStaff = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      staffList: prev.staffList.filter((s) => s.id !== id),
    }));
  };

  // Attendance Actions
  const handleAddAttendance = (recData: Omit<AttendanceRecord, 'id' | 'createdAt'>) => {
    const newRec: AttendanceRecord = {
      ...recData,
      id: `att-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      attendanceRecords: [newRec, ...prev.attendanceRecords],
    }));
  };

  const handleEditAttendance = (id: string, updated: Partial<AttendanceRecord>) => {
    setState((prev) => ({
      ...prev,
      attendanceRecords: prev.attendanceRecords.map((a) =>
        a.id === id ? { ...a, ...updated } : a
      ),
    }));
  };

  const handleDeleteAttendance = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      attendanceRecords: prev.attendanceRecords.filter((a) => a.id !== id),
    }));
  };

  // Staff Financial Actions
  const handleAddFinancialRecord = (
    recData: Omit<StaffFinancialRecord, 'id' | 'createdAt'>
  ) => {
    const newRec: StaffFinancialRecord = {
      ...recData,
      id: `fin-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      staffFinancials: [newRec, ...prev.staffFinancials],
    }));
  };

  const handleEditFinancialRecord = (
    id: string,
    updated: Partial<StaffFinancialRecord>
  ) => {
    setState((prev) => ({
      ...prev,
      staffFinancials: prev.staffFinancials.map((f) =>
        f.id === id ? { ...f, ...updated } : f
      ),
    }));
  };

  const handleDeleteFinancialRecord = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      staffFinancials: prev.staffFinancials.filter((f) => f.id !== id),
    }));
  };

  // Invoice Actions
  const handleAddInvoice = (invoiceData: Omit<Invoice, 'id' | 'createdAt'>) => {
    const newInvoice: Invoice = {
      ...invoiceData,
      id: `inv-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      invoices: [newInvoice, ...(prev.invoices || [])],
    }));
  };

  const handleUpdateInvoice = (updated: Invoice) => {
    setState((prev) => ({
      ...prev,
      invoices: (prev.invoices || []).map((inv) => (inv.id === updated.id ? updated : inv)),
    }));
  };

  const handleDeleteInvoice = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      invoices: (prev.invoices || []).filter((inv) => inv.id !== id),
    }));
  };

  // Invoice Cheque Payments Actions
  const handleAddInvoiceChequePayment = (chequeData: Omit<InvoiceChequePayment, 'id' | 'createdAt'>) => {
    const newCheque: InvoiceChequePayment = {
      ...chequeData,
      id: `chq-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      invoiceChequePayments: [newCheque, ...(prev.invoiceChequePayments || [])],
    }));
  };

  const handleUpdateInvoiceChequePayment = (updated: InvoiceChequePayment) => {
    setState((prev) => ({
      ...prev,
      invoiceChequePayments: (prev.invoiceChequePayments || []).map((c) =>
        c.id === updated.id ? updated : c
      ),
    }));
  };

  const handleDeleteInvoiceChequePayment = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      invoiceChequePayments: (prev.invoiceChequePayments || []).filter((c) => c.id !== id),
    }));
  };

  // Party Actions
  const handleAddParty = (partyData: Omit<Party, 'id' | 'currentBalance' | 'createdAt'>) => {
    const newParty: Party = {
      ...partyData,
      id: `party-${Date.now()}`,
      currentBalance: partyData.openingBalance || 0,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      parties: [newParty, ...(prev.parties || [])],
    }));
  };

  const handleEditParty = (updatedParty: Party) => {
    setState((prev) => ({
      ...prev,
      parties: (prev.parties || []).map((p) => (p.id === updatedParty.id ? updatedParty : p)),
    }));
  };

  const handleDeleteParty = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      parties: (prev.parties || []).filter((p) => p.id !== id),
      partyTransactions: (prev.partyTransactions || []).filter((t) => t.partyId !== id),
    }));
  };

  const handleAddPartyTransaction = (txData: Omit<PartyTransaction, 'id' | 'createdAt' | 'balanceAfter'>) => {
    const newTx: PartyTransaction = {
      ...txData,
      id: `ptx-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      partyTransactions: [newTx, ...(prev.partyTransactions || [])],
    }));
  };

  const handleDeletePartyTransaction = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      partyTransactions: (prev.partyTransactions || []).filter((t) => t.id !== id),
    }));
  };

  // Window / Shift Sales Actions
  const handleAddWindowSale = (saleData: Omit<WindowShiftSale, 'id' | 'createdAt'>) => {
    const newSale: WindowShiftSale = {
      ...saleData,
      id: `wsale-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      windowShiftSales: [newSale, ...(prev.windowShiftSales || [])],
    }));
  };

  const handleEditWindowSale = (updatedSale: WindowShiftSale) => {
    setState((prev) => ({
      ...prev,
      windowShiftSales: (prev.windowShiftSales || []).map((s) => (s.id === updatedSale.id ? updatedSale : s)),
    }));
  };

  const handleDeleteWindowSale = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      windowShiftSales: (prev.windowShiftSales || []).filter((s) => s.id !== id),
    }));
  };

  // Labour Monthly Token System Actions
  const handleAddLabourWorker = (workerData: Omit<LabourWorker, 'id' | 'createdAt'>) => {
    const newWorker: LabourWorker = {
      ...workerData,
      id: `lab-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      labourWorkers: [newWorker, ...(prev.labourWorkers || [])],
    }));
  };

  const handleEditLabourWorker = (id: string, updated: Partial<LabourWorker>) => {
    setState((prev) => ({
      ...prev,
      labourWorkers: (prev.labourWorkers || []).map((w) => (w.id === id ? { ...w, ...updated } : w)),
    }));
  };

  const handleDeleteLabourWorker = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      labourWorkers: (prev.labourWorkers || []).filter((w) => w.id !== id),
      labourTokenIssues: (prev.labourTokenIssues || []).filter((i) => i.labourId !== id),
      labourTokenPayments: (prev.labourTokenPayments || []).filter((p) => p.labourId !== id),
    }));
  };

  const handleAddLabourTokenIssue = (
    issueData: Omit<LabourTokenIssue, 'id' | 'createdAt' | 'totalAmount'> & { totalAmount?: number }
  ) => {
    const calculatedAmount = (Number(issueData.tokenQty) || 0) * (Number(issueData.tokenRate) || 0);
    const finalTotalAmount =
      issueData.totalAmount !== undefined && !isNaN(issueData.totalAmount) && issueData.totalAmount > 0
        ? issueData.totalAmount
        : calculatedAmount;

    const newIssue: LabourTokenIssue = {
      ...issueData,
      tokenQty: issueData.tokenQty !== undefined ? Number(issueData.tokenQty) : 0,
      tokenRate: issueData.tokenRate !== undefined ? Number(issueData.tokenRate) : 0,
      totalAmount: finalTotalAmount,
      id: `lti-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      labourTokenIssues: [newIssue, ...(prev.labourTokenIssues || [])],
    }));
  };

  const handleDeleteLabourTokenIssue = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      labourTokenIssues: (prev.labourTokenIssues || []).filter((i) => i.id !== id),
    }));
  };

  // Record Cash Collected from Labour: Automatically updates DailyEntry if depositedToDailySale is true!
  const handleRecordLabourTokenPayment = (paymentData: Omit<LabourTokenPayment, 'id' | 'createdAt'>) => {
    const newPayment: LabourTokenPayment = {
      ...paymentData,
      id: `ltp-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };

    setState((prev) => {
      let updatedDailyEntries = [...prev.dailyEntries];

      if (paymentData.depositedToDailySale) {
        const entryDate = paymentData.date;
        const targetCanteenId = paymentData.canteenId;
        const existingIndex = updatedDailyEntries.findIndex(
          (e) => e.date === entryDate && e.canteenId === targetCanteenId
        );

        if (existingIndex >= 0) {
          const existing = updatedDailyEntries[existingIndex];
          const newNormalSale = existing.normalSale + paymentData.amount;
          const newTotalSale = newNormalSale + existing.tokenSale;
          const newNet = newTotalSale - existing.purchase - existing.expenses;
          const labourNote = `[Labour Cash: +${paymentData.amount} from ${paymentData.labourName}]`;
          const updatedRemarks = existing.remarks
            ? `${existing.remarks} | ${labourNote}`
            : labourNote;

          updatedDailyEntries[existingIndex] = {
            ...existing,
            normalSale: newNormalSale,
            totalSale: newTotalSale,
            netAmount: newNet,
            remarks: updatedRemarks,
          };
        } else {
          // Create a new daily entry record for this date
          const newEntry: DailyEntry = {
            id: `entry-${Date.now()}`,
            date: entryDate,
            canteenId: targetCanteenId,
            canteenName: paymentData.canteenName,
            normalSale: paymentData.amount,
            tokenSale: 0,
            totalSale: paymentData.amount,
            purchase: 0,
            expenses: 0,
            netAmount: paymentData.amount,
            remarks: `Labour Token Cash Collection (${paymentData.labourName})`,
            createdAt: new Date().toISOString(),
          };
          updatedDailyEntries = [newEntry, ...updatedDailyEntries];
        }
      }

      return {
        ...prev,
        dailyEntries: updatedDailyEntries,
        labourTokenPayments: [newPayment, ...(prev.labourTokenPayments || [])],
      };
    });
  };

  const handleDeleteLabourTokenPayment = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => {
      const paymentToDelete = (prev.labourTokenPayments || []).find((p) => p.id === id);
      let updatedDailyEntries = prev.dailyEntries;

      if (paymentToDelete && paymentToDelete.depositedToDailySale) {
        const entryDate = paymentToDelete.date;
        const targetCanteenId = paymentToDelete.canteenId;
        const existingIndex = prev.dailyEntries.findIndex(
          (e) => e.date === entryDate && e.canteenId === targetCanteenId
        );

        if (existingIndex >= 0) {
          const existing = prev.dailyEntries[existingIndex];
          const newNormalSale = Math.max(0, existing.normalSale - paymentToDelete.amount);
          const newTotalSale = newNormalSale + existing.tokenSale;
          const newNet = newTotalSale - existing.purchase - existing.expenses;
          updatedDailyEntries = [...prev.dailyEntries];
          updatedDailyEntries[existingIndex] = {
            ...existing,
            normalSale: newNormalSale,
            totalSale: newTotalSale,
            netAmount: newNet,
          };
        }
      }

      return {
        ...prev,
        dailyEntries: updatedDailyEntries,
        labourTokenPayments: (prev.labourTokenPayments || []).filter((p) => p.id !== id),
      };
    });
  };

  // Petty Cash Handlers (Tracked isolated from Dashboard total expenses)
  const handleAddPettyExpense = (
    expenseData: Omit<PettyCashExpense, 'id' | 'createdAt'>
  ) => {
    const newExpense: PettyCashExpense = {
      ...expenseData,
      id: `pce-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      pettyCashExpenses: [newExpense, ...(prev.pettyCashExpenses || [])],
    }));
  };

  const handleEditPettyExpense = (
    id: string,
    updated: Partial<PettyCashExpense>
  ) => {
    setState((prev) => ({
      ...prev,
      pettyCashExpenses: (prev.pettyCashExpenses || []).map((exp) =>
        exp.id === id ? { ...exp, ...updated } : exp
      ),
    }));
  };

  const handleDeletePettyExpense = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      pettyCashExpenses: (prev.pettyCashExpenses || []).filter((exp) => exp.id !== id),
    }));
  };

  const handleAddPettyFund = (
    fundData: Omit<PettyCashFund, 'id' | 'createdAt'>
  ) => {
    const newFund: PettyCashFund = {
      ...fundData,
      id: `pcf-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      pettyCashFunds: [newFund, ...(prev.pettyCashFunds || [])],
    }));
  };

  const handleDeletePettyFund = (id: string) => {
    recordDeletedId(id);
    applyStateWithImmediateSync((prev) => ({
      ...prev,
      pettyCashFunds: (prev.pettyCashFunds || []).filter((f) => f.id !== id),
    }));
  };

  // Settings Actions
  const handleUpdateCurrency = (symbol: string) => {
    setState((prev) => ({
      ...prev,
      currencySymbol: symbol,
    }));
  };

  const handleUpdatePin = (newPin: string) => {
    setState((prev) => ({
      ...prev,
      pinCode: newPin,
      isLocked: newPin ? false : false,
    }));
  };

  const handleLockApp = () => {
    if (state.pinCode) {
      setState((prev) => ({
        ...prev,
        isLocked: true,
      }));
    }
  };

  const handleUnlockApp = () => {
    setState((prev) => ({
      ...prev,
      isLocked: false,
    }));
  };

  const handleUpdateLockedCanteen = (canteenId: string) => {
    setState((prev) => ({
      ...prev,
      lockedCanteenId: canteenId,
    }));
    if (canteenId) {
      setSelectedCanteenId(canteenId);
    }
  };

  const handleRestoreState = (newState: AppState) => {
    const dedupe = <T extends { id: string }>(arr?: T[]): T[] => {
      if (!Array.isArray(arr)) return [];
      const map = new Map<string, T>();
      arr.forEach((item) => {
        if (item && item.id) map.set(item.id, item);
      });
      return Array.from(map.values());
    };

    const sanitizedState: AppState = {
      ...newState,
      canteens: dedupe(newState.canteens),
      dailyEntries: dedupe(newState.dailyEntries),
      canteenCashDeposits: dedupe(newState.canteenCashDeposits),
      staffList: dedupe(newState.staffList),
      attendanceRecords: dedupe(newState.attendanceRecords),
      staffFinancials: dedupe(newState.staffFinancials),
      invoices: dedupe(newState.invoices).map((inv) => ({
        ...inv,
        buyerAddress: resolveBuyerAddress(inv.buyerAddress),
        poDate: '',
      })),
      invoiceChequePayments: dedupe(newState.invoiceChequePayments),
      parties: dedupe(newState.parties),
      partyTransactions: dedupe(newState.partyTransactions),
      windowShiftSales: dedupe(newState.windowShiftSales),
      labourWorkers: dedupe(newState.labourWorkers),
      labourTokenIssues: dedupe(newState.labourTokenIssues),
      labourTokenPayments: dedupe(newState.labourTokenPayments),
      pettyCashExpenses: dedupe(newState.pettyCashExpenses),
      pettyCashFunds: dedupe(newState.pettyCashFunds),
      currencySymbol: newState.currencySymbol || 'Rs.',
      pinCode: newState.pinCode || '',
      isLocked: newState.isLocked || false,
      lockedCanteenId: newState.lockedCanteenId || '',
    };
    setState(sanitizedState);
    saveStateToStorage(sanitizedState);
    saveStateToCloud(sanitizedState, true);
  };

  const handleResetDemoData = () => {
    const freshState = clearAllAppData();
    setState(freshState);
    saveStateToCloud(freshState);
  };

  const triggerQuickAddEntry = () => {
    setActiveTab('daily_entry');
    setQuickAddEntryOpen(true);
  };

  const tabTitles: Record<NavTab, { title: string; subtitle: string }> = {
    dashboard: { title: 'Executive Dashboard', subtitle: 'Overview of sales, expenses, and branch performance' },
    daily_entry: { title: 'Daily Sales & Expenses', subtitle: 'Record and manage day-wise canteen counter entries' },
    petty_cash: { title: 'Daily Petty Cash Register', subtitle: 'Day-wise minor operational expenses tracked separately from dashboard totals' },
    window_sales: { title: 'Window & Shift Sales', subtitle: 'Detailed counter & window shift logs (Window 1-2, 3-4, Taba, 6-7)' },
    labour_tokens: { title: 'Labour Monthly Tokens', subtitle: 'Sadaqat Canteen monthly worker token accounts, due bills & cash deposits' },
    invoices: { title: 'Invoices & Cheque Payments', subtitle: 'Generate FBR sales tax invoices and track incoming bank cheques & clearing' },
    parties: { title: 'Parties & Khata Ledger', subtitle: 'Manage supplier stock, installments & customer accounts' },
    financials: { title: 'Staff Advances & Ledger', subtitle: 'Track advance payments, loans, and penalties' },
    staff: { title: 'Staff Directory', subtitle: 'Employee records and salaries across canteens' },
    attendance: { title: 'Daily Attendance', subtitle: 'Track employee presence, leaves, and overtime' },
    reports: { title: 'Reports & Analytics', subtitle: 'Export Excel reports and comparative analytics' },
    canteens: { title: 'Branches & Canteens', subtitle: 'Manage operational branches and locations' },
    settings: { title: 'Settings & Cloud Backup', subtitle: 'Configure PIN, currency, long-term cloud safety, and data reset' },
  };

  const currentCanteen = state.canteens.find((c) => c.id === (state.lockedCanteenId || selectedCanteenId));
  const currentCanteenName = currentCanteen ? currentCanteen.name : 'All Active Canteens';

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 font-sans antialiased flex flex-col lg:flex-row selection:bg-emerald-200 selection:text-emerald-900">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        canteens={state.canteens}
        selectedCanteenId={selectedCanteenId}
        setSelectedCanteenId={setSelectedCanteenId}
        onQuickAddEntry={triggerQuickAddEntry}
        hasPin={Boolean(state.pinCode)}
        onLockApp={handleLockApp}
        lockedCanteenId={state.lockedCanteenId}
        cloudStatus={cloudStatus}
        mobileOpen={mobileSidebarOpen}
        setMobileOpen={setMobileSidebarOpen}
        isCollapsed={sidebarCollapsed}
        setIsCollapsed={setSidebarCollapsed}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-x-hidden min-h-screen">
        {/* Update Available Banner */}
        {updateAvailable && (
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white px-4 py-2.5 text-xs font-bold flex items-center justify-between shadow-md z-[60] animate-in slide-in-from-top duration-300">
            <div className="flex items-center gap-2 mx-auto sm:mx-0">
              <Sparkles className="w-4 h-4 text-amber-300 animate-pulse shrink-0" />
              <span>⚡ New App Version & Features Available! Tap to update and load latest code.</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleApplyUpdate}
                className="bg-white hover:bg-emerald-50 text-emerald-900 px-3 py-1 rounded-lg font-black text-xs transition-transform active:scale-95 shadow-2xs cursor-pointer flex items-center gap-1 shrink-0"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Update Now</span>
              </button>
              <button
                onClick={() => setUpdateAvailable(false)}
                className="p-1 hover:bg-white/20 rounded-md transition-colors cursor-pointer text-white/80"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Companion Top App Bar */}
        <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 py-2.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl cursor-pointer"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight truncate">
                  {tabTitles[activeTab]?.title || 'SKEM Canteens'}
                </h1>
                <span className="hidden md:inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200/80 px-2 py-0.5 rounded-full">
                  <Store className="w-3 h-3 text-emerald-600" />
                  <span>{currentCanteenName}</span>
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block truncate">
                {tabTitles[activeTab]?.subtitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            {/* Live Real-time Clock */}
            {currentTime && (
              <div className="hidden xl:flex flex-col items-end px-3 py-1 bg-slate-50 border border-slate-200/80 rounded-xl text-right">
                <span className="font-mono font-bold text-xs text-slate-800 tracking-tight tabular-nums">
                  {currentTime}
                </span>
                <span className="text-[10px] text-slate-400 font-medium leading-none">
                  {currentDateStr}
                </span>
              </div>
            )}

            <button
              onClick={triggerQuickAddEntry}
              className="flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-black px-3.5 py-2 rounded-xl transition-all shadow-xs cursor-pointer transform active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Add Daily Entry</span>
              <span className="sm:hidden">Entry</span>
            </button>

            {Boolean(state.pinCode) && (
              <button
                onClick={handleLockApp}
                className="p-2 text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl text-xs font-bold cursor-pointer transition-colors"
                title="Lock Application"
              >
                <Lock className="w-4 h-4" />
              </button>
            )}
          </div>
        </header>

        {/* Main View Area */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'dashboard' && (
          <Dashboard
            state={state}
            selectedCanteenId={selectedCanteenId}
            setSelectedCanteenId={setSelectedCanteenId}
            onNavigate={setActiveTab}
            onQuickAddEntry={triggerQuickAddEntry}
            onAddCashDeposit={handleAddCashDeposit}
            onRestoreBackup={handleRestoreState}
          />
        )}

        {activeTab === 'daily_entry' && (
          <DailyEntryView
            entries={state.dailyEntries}
            cashDeposits={state.canteenCashDeposits || []}
            canteens={state.canteens}
            selectedCanteenId={selectedCanteenId}
            currencySymbol={state.currencySymbol || 'Rs.'}
            isOpenModalImmediately={quickAddEntryOpen}
            onAddEntry={handleAddDailyEntry}
            onEditEntry={handleEditDailyEntry}
            onDeleteEntry={handleDeleteDailyEntry}
            onAddCashDeposit={handleAddCashDeposit}
            onEditCashDeposit={handleEditCashDeposit}
            onDeleteCashDeposit={handleDeleteCashDeposit}
            onCloseQuickModal={() => setQuickAddEntryOpen(false)}
          />
        )}

        {activeTab === 'petty_cash' && (
          <PettyCashView
            pettyCashExpenses={state.pettyCashExpenses || []}
            pettyCashFunds={state.pettyCashFunds || []}
            canteens={state.canteens}
            selectedCanteenId={selectedCanteenId}
            currencySymbol={state.currencySymbol || 'Rs.'}
            onAddExpense={handleAddPettyExpense}
            onEditExpense={handleEditPettyExpense}
            onDeleteExpense={handleDeletePettyExpense}
            onAddFund={handleAddPettyFund}
            onDeleteFund={handleDeletePettyFund}
          />
        )}

        {activeTab === 'invoices' && (
          <InvoicesView
            invoices={state.invoices || []}
            invoiceChequePayments={state.invoiceChequePayments || []}
            canteens={state.canteens}
            selectedCanteenId={selectedCanteenId}
            onAddInvoice={handleAddInvoice}
            onUpdateInvoice={handleUpdateInvoice}
            onDeleteInvoice={handleDeleteInvoice}
            onAddChequePayment={handleAddInvoiceChequePayment}
            onUpdateChequePayment={handleUpdateInvoiceChequePayment}
            onDeleteChequePayment={handleDeleteInvoiceChequePayment}
            currencySymbol={state.currencySymbol || 'Rs.'}
          />
        )}

        {activeTab === 'parties' && (
          <PartiesView
            parties={state.parties || []}
            transactions={state.partyTransactions || []}
            currencySymbol={state.currencySymbol || 'Rs.'}
            onAddParty={handleAddParty}
            onEditParty={handleEditParty}
            onDeleteParty={handleDeleteParty}
            onAddTransaction={handleAddPartyTransaction}
            onDeleteTransaction={handleDeletePartyTransaction}
          />
        )}

        {activeTab === 'window_sales' && (
          <WindowSalesView
            windowSales={state.windowShiftSales || []}
            canteens={state.canteens}
            currencySymbol={state.currencySymbol || 'Rs.'}
            onAddWindowSale={handleAddWindowSale}
            onEditWindowSale={handleEditWindowSale}
            onDeleteWindowSale={handleDeleteWindowSale}
          />
        )}

        {activeTab === 'labour_tokens' && (
          <LabourTokensView
            labourWorkers={state.labourWorkers || []}
            labourTokenIssues={state.labourTokenIssues || []}
            labourTokenPayments={state.labourTokenPayments || []}
            canteens={state.canteens}
            selectedCanteenId={selectedCanteenId}
            currencySymbol={state.currencySymbol || 'Rs.'}
            onAddWorker={handleAddLabourWorker}
            onEditWorker={handleEditLabourWorker}
            onDeleteWorker={handleDeleteLabourWorker}
            onIssueTokens={handleAddLabourTokenIssue}
            onDeleteTokenIssue={handleDeleteLabourTokenIssue}
            onCollectCash={handleRecordLabourTokenPayment}
            onDeletePayment={handleDeleteLabourTokenPayment}
          />
        )}

        {activeTab === 'attendance' && (
          <AttendanceView
            attendanceRecords={state.attendanceRecords}
            staffList={state.staffList}
            canteens={state.canteens}
            selectedCanteenId={selectedCanteenId}
            onAddAttendance={handleAddAttendance}
            onEditAttendance={handleEditAttendance}
            onDeleteAttendance={handleDeleteAttendance}
          />
        )}

        {activeTab === 'staff' && (
          <StaffView
            staffList={state.staffList}
            canteens={state.canteens}
            selectedCanteenId={selectedCanteenId}
            currencySymbol={state.currencySymbol || 'Rs.'}
            attendanceRecords={state.attendanceRecords}
            staffFinancials={state.staffFinancials}
            onAddStaff={handleAddStaff}
            onEditStaff={handleEditStaff}
            onDeleteStaff={handleDeleteStaff}
          />
        )}

        {activeTab === 'financials' && (
          <StaffFinancialsView
            staffFinancials={state.staffFinancials}
            staffList={state.staffList}
            canteens={state.canteens}
            selectedCanteenId={selectedCanteenId}
            currencySymbol={state.currencySymbol || 'Rs.'}
            attendanceRecords={state.attendanceRecords}
            onAddFinancialRecord={handleAddFinancialRecord}
            onEditFinancialRecord={handleEditFinancialRecord}
            onDeleteFinancialRecord={handleDeleteFinancialRecord}
          />
        )}

        {activeTab === 'reports' && (
          <ReportsView
            state={state}
            selectedCanteenId={selectedCanteenId}
            setSelectedCanteenId={setSelectedCanteenId}
          />
        )}

        {activeTab === 'canteens' && (
          <CanteensView
            canteens={state.canteens}
            onAddCanteen={handleAddCanteen}
            onEditCanteen={handleEditCanteen}
            onDeleteCanteen={handleDeleteCanteen}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            state={state}
            onUpdateCurrency={handleUpdateCurrency}
            onRestoreState={handleRestoreState}
            onResetDemoData={handleResetDemoData}
            onUpdatePin={handleUpdatePin}
            onLockApp={handleLockApp}
            onUpdateLockedCanteen={handleUpdateLockedCanteen}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            <strong>SKEM Canteens Management</strong> — Multi-Canteen Daily Sales, Expenses & Staff Management System
          </span>
          <span>Currency: {state.currencySymbol || 'Rs.'} | 🔒 Persistent Cloud & Local Database</span>
        </div>
      </footer>
    </div>

    {/* Security Lock Screen Modal */}
    <LockScreenModal
      isOpen={Boolean(state.pinCode && state.isLocked)}
      pinCode={state.pinCode || ''}
      onUnlock={handleUnlockApp}
    />
  </div>
);
}

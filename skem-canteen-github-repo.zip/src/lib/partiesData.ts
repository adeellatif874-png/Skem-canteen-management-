import { Party, PartyTransaction } from '../types';
import * as XLSX from 'xlsx';
import { formatCurrency, formatDisplayDate } from './storage';

export const initialParties: Party[] = [];

export const initialPartyTransactions: PartyTransaction[] = [];

// Recompute party balance based on opening balance and all transactions
export function calculatePartyBalance(
  party: Party,
  transactions: PartyTransaction[]
): number {
  const partyTx = transactions.filter((t) => t.partyId === party.id);
  partyTx.sort((a, b) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt));

  let bal = party.openingBalance || 0;

  for (const t of partyTx) {
    if (party.type === 'supplier') {
      // For Supplier: Stock bill increases what we owe (+), Installment payment reduces what we owe (-)
      if (t.type === 'stock_bill') {
        bal += t.amount;
      } else if (t.type === 'installment_payment') {
        bal -= t.amount;
      }
    } else {
      // For Customer (e.g. MK Son's): Stock bill increases what they owe (+), Installment payment reduces what they owe (-)
      if (t.type === 'stock_bill') {
        bal += t.amount;
      } else if (t.type === 'installment_payment') {
        bal -= t.amount;
      }
    }
  }

  return bal;
}

// Export Party Ledger to Excel
export function exportPartyLedgerExcel(
  party: Party,
  transactions: PartyTransaction[],
  currencySymbol: string = 'Rs.'
) {
  const partyTx = transactions.filter((t) => t.partyId === party.id);
  partyTx.sort((a, b) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt));

  let runningBal = party.openingBalance || 0;

  const rows: any[] = [];

  // Initial Opening row
  rows.push({
    Date: formatDisplayDate(party.createdAt.split('T')[0]),
    'Bill / Ref #': '-',
    Type: 'Opening Balance',
    Description: 'Initial Balance',
    'Payment Mode': '-',
    'Bill / Stock (Rs.)': party.openingBalance > 0 ? party.openingBalance : 0,
    'Payment / Installment (Rs.)': 0,
    'Balance (Rs.)': runningBal,
  });

  partyTx.forEach((tx) => {
    let billAmt = 0;
    let paymentAmt = 0;

    if (tx.type === 'stock_bill') {
      billAmt = tx.amount;
      runningBal += tx.amount;
    } else {
      paymentAmt = tx.amount;
      runningBal -= tx.amount;
    }

    rows.push({
      Date: formatDisplayDate(tx.date),
      'Bill / Ref #': tx.invoiceOrBillNo || '-',
      Type: tx.type === 'stock_bill' ? (party.type === 'supplier' ? 'Stock Received' : 'Stock Delivered') : 'Installment Payment',
      Description: tx.description,
      'Payment Mode': tx.paymentMethod || '-',
      'Bill / Stock (Rs.)': billAmt,
      'Payment / Installment (Rs.)': paymentAmt,
      'Balance (Rs.)': runningBal,
    });
  });

  const ws = XLSX.utils.json_to_sheet(rows);

  ws['!cols'] = [
    { wch: 14 }, // Date
    { wch: 15 }, // Ref
    { wch: 22 }, // Type
    { wch: 38 }, // Description
    { wch: 15 }, // Mode
    { wch: 20 }, // Bill
    { wch: 24 }, // Payment
    { wch: 18 }, // Balance
  ];

  const wb = XLSX.utils.book_new();
  const safeName = party.name.replace(/[^a-zA-Z0-9]/g, '_').slice(0, 25);
  XLSX.utils.book_append_sheet(wb, ws, safeName);

  const fileName = `Ledger_${safeName}_${new Date().toISOString().split('T')[0]}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

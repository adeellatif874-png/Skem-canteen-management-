import * as XLSX from 'xlsx';
import {
  AppState,
  Canteen,
  DailyEntry,
  Staff,
  AttendanceRecord,
  StaffFinancialRecord,
  Invoice,
  Party,
  PartyTransaction,
  WindowShiftSale,
  LabourWorker,
  LabourTokenIssue,
  LabourTokenPayment,
  PettyCashExpense,
  PettyCashFund,
  CanteenCashDeposit,
} from '../types';
import { resolveBuyerAddress } from './invoiceUtils';
import { initialLabourWorkers, initialLabourTokenIssues, initialLabourTokenPayments } from './labourData';
import { initialPettyCashFunds, initialPettyCashExpenses } from './pettyCashData';
import { RECOVERED_DATA } from './recoveredState';

export const STORAGE_KEY = 'canteen_management_app_data_v8_live';
export const BACKUP_KEY = 'canteen_app_backup_archive_v7';
export const DELETED_IDS_KEY = 'canteen_deleted_ids_registry_v1';

// Persistent registry of deleted IDs to guarantee deleted entries never resurrect upon reload or sync
export function getDeletedIds(): Set<string> {
  try {
    const raw = localStorage.getItem(DELETED_IDS_KEY);
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) return new Set(arr);
    }
  } catch (e) {
    // Ignore storage issues
  }
  return new Set();
}

export function recordDeletedId(id: string) {
  if (!id) return;
  try {
    const current = getDeletedIds();
    current.add(id);
    localStorage.setItem(DELETED_IDS_KEY, JSON.stringify(Array.from(current)));
  } catch (e) {
    // Ignore storage issues
  }
}

export const initialCanteens: Canteen[] = RECOVERED_DATA.canteens || [
  { id: 'cant-sadaqat', name: 'Sadaqat Canteen', code: 'SC-01', location: 'Main Branch', contactPerson: 'Sadaqat', phone: '', status: 'active', createdAt: '2026-08-01' },
  { id: 'cant-km', name: 'KM Canteen', code: 'KM-01', location: 'KM Branch', contactPerson: 'Adeel', phone: '', status: 'active', createdAt: '2026-07-21' },
  { id: 'cant-sts', name: 'Sadaqat Tuck Shop', code: 'STS-01', location: 'STS Branch', contactPerson: 'Sadaqat', phone: '', status: 'active', createdAt: '2026-08-01' },
  { id: 'cant-rnc', name: 'RNC Electric Store', code: 'RNC-01', location: 'Electric Store Branch', contactPerson: 'RNC Admin', phone: '', status: 'active', createdAt: '2026-08-01' },
  { id: 'cant-1787251769842', name: 'BEACON IMPEX', code: 'CAN-05', location: '35 km main Shekihupura road Faisalabad', contactPerson: '', phone: '25607219', status: 'active', createdAt: '2026-08-20T18:49:29.842Z' },
];

export function isCanteenMatch(
  item: { canteenId?: string; canteenName?: string },
  selectedCanteenId: string,
  canteens: Canteen[] = []
): boolean {
  if (!selectedCanteenId || selectedCanteenId === 'all') return true;
  if (!item) return false;
  if (item.canteenId === selectedCanteenId) return true;

  const selectedCanteen = (canteens || []).find((c) => c.id === selectedCanteenId);
  if (selectedCanteen) {
    const normItemName = (item.canteenName || '').trim().toLowerCase();
    const normSelectedName = (selectedCanteen.name || '').trim().toLowerCase();
    if (normItemName && normSelectedName && normItemName === normSelectedName) {
      return true;
    }
  }
  return false;
}

export const matchesCanteenFilter = isCanteenMatch;

export function formatCurrency(amount: number, symbol = 'Rs.'): string {
  const val = Math.round(amount || 0);
  return `${symbol} ${val.toLocaleString('en-PK')}`;
}

export function formatDisplayDate(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return `${parts[2]}-${parts[1]}-${parts[0]}`;
  }
  return dateStr;
}

export function getFreshCleanState(): AppState {
  return {
    canteens: (RECOVERED_DATA.canteens && RECOVERED_DATA.canteens.length > 0) ? RECOVERED_DATA.canteens : initialCanteens,
    dailyEntries: RECOVERED_DATA.dailyEntries || [],
    canteenCashDeposits: RECOVERED_DATA.canteenCashDeposits || [],
    staffList: RECOVERED_DATA.staffList || [],
    attendanceRecords: RECOVERED_DATA.attendanceRecords || [],
    staffFinancials: RECOVERED_DATA.staffFinancials || [],
    invoices: (RECOVERED_DATA.invoices || []).map((inv) => ({
      ...inv,
      buyerAddress: resolveBuyerAddress(inv.buyerAddress),
      poDate: '',
    })),
    invoiceChequePayments: RECOVERED_DATA.invoiceChequePayments || [],
    parties: RECOVERED_DATA.parties || [],
    partyTransactions: RECOVERED_DATA.partyTransactions || [],
    windowShiftSales: RECOVERED_DATA.windowShiftSales || [],
    labourWorkers: (RECOVERED_DATA.labourWorkers && RECOVERED_DATA.labourWorkers.length > 0) ? RECOVERED_DATA.labourWorkers : initialLabourWorkers,
    labourTokenIssues: (RECOVERED_DATA.labourTokenIssues && RECOVERED_DATA.labourTokenIssues.length > 0) ? RECOVERED_DATA.labourTokenIssues : initialLabourTokenIssues,
    labourTokenPayments: (RECOVERED_DATA.labourTokenPayments && RECOVERED_DATA.labourTokenPayments.length > 0) ? RECOVERED_DATA.labourTokenPayments : initialLabourTokenPayments,
    pettyCashExpenses: (RECOVERED_DATA.pettyCashExpenses && RECOVERED_DATA.pettyCashExpenses.length > 0) ? RECOVERED_DATA.pettyCashExpenses : initialPettyCashExpenses,
    pettyCashFunds: (RECOVERED_DATA.pettyCashFunds && RECOVERED_DATA.pettyCashFunds.length > 0) ? RECOVERED_DATA.pettyCashFunds : initialPettyCashFunds,
    currencySymbol: RECOVERED_DATA.currencySymbol || 'Rs.',
    pinCode: RECOVERED_DATA.pinCode || '',
    isLocked: RECOVERED_DATA.isLocked || false,
    lockedCanteenId: RECOVERED_DATA.lockedCanteenId || '',
  };
}

export function clearAllAppData(): AppState {
  try {
    localStorage.clear();
    const fresh = getFreshCleanState();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
    return fresh;
  } catch (e) {
    return getFreshCleanState();
  }
}

export function getInitialState(): AppState {
  const seed = getFreshCleanState();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        const deleted = getDeletedIds();
        const filterDeleted = <T extends { id?: string }>(arr: any[]): T[] => {
          if (!Array.isArray(arr)) return [];
          return arr.filter((item) => item && item.id && !deleted.has(item.id));
        };

        const localEntries = filterDeleted<DailyEntry>(parsed.dailyEntries);
        const effectiveEntries = localEntries.length >= (seed.dailyEntries?.length || 0)
          ? localEntries
          : (seed.dailyEntries || []);

        const localStaff = filterDeleted<Staff>(parsed.staffList);
        const effectiveStaff = localStaff.length >= (seed.staffList?.length || 0)
          ? localStaff
          : (seed.staffList || []);

        const localInvoices = filterDeleted<Invoice>(parsed.invoices);
        const invMap = new Map<string, Invoice>();
        (seed.invoices || []).forEach(inv => invMap.set(String(inv.invoiceNo || inv.id), inv));
        localInvoices.forEach(inv => invMap.set(String(inv.invoiceNo || inv.id), inv));
        const effectiveInvoices = Array.from(invMap.values());

        const localCanteens = filterDeleted<Canteen>(parsed.canteens);
        const effectiveCanteens = localCanteens.length >= (seed.canteens?.length || 0)
          ? localCanteens
          : (seed.canteens || []);

        const localFin = filterDeleted<StaffFinancialRecord>(parsed.staffFinancials);
        const effectiveFin = localFin.length >= (seed.staffFinancials?.length || 0)
          ? localFin
          : (seed.staffFinancials || []);

        return {
          canteens: effectiveCanteens && effectiveCanteens.length > 0 ? effectiveCanteens : seed.canteens,
          dailyEntries: effectiveEntries,
          canteenCashDeposits: filterDeleted(parsed.canteenCashDeposits),
          staffList: effectiveStaff,
          attendanceRecords: filterDeleted(parsed.attendanceRecords),
          staffFinancials: effectiveFin,
          invoices: effectiveInvoices.map((inv) => ({
            ...inv,
            buyerAddress: resolveBuyerAddress(inv.buyerAddress),
            poDate: '',
          })),
          invoiceChequePayments: filterDeleted(parsed.invoiceChequePayments),
          parties: filterDeleted(parsed.parties),
          partyTransactions: filterDeleted(parsed.partyTransactions),
          windowShiftSales: filterDeleted(parsed.windowShiftSales),
          labourWorkers: filterDeleted(parsed.labourWorkers).length > 0 ? filterDeleted(parsed.labourWorkers) : seed.labourWorkers,
          labourTokenIssues: filterDeleted(parsed.labourTokenIssues).length > 0 ? filterDeleted(parsed.labourTokenIssues) : seed.labourTokenIssues,
          labourTokenPayments: filterDeleted(parsed.labourTokenPayments).length > 0 ? filterDeleted(parsed.labourTokenPayments) : seed.labourTokenPayments,
          pettyCashExpenses: filterDeleted(parsed.pettyCashExpenses).length > 0 ? filterDeleted(parsed.pettyCashExpenses) : seed.pettyCashExpenses,
          pettyCashFunds: filterDeleted(parsed.pettyCashFunds).length > 0 ? filterDeleted(parsed.pettyCashFunds) : seed.pettyCashFunds,
          currencySymbol: typeof parsed.currencySymbol === 'string' ? parsed.currencySymbol : 'Rs.',
          pinCode: typeof parsed.pinCode === 'string' ? parsed.pinCode : '',
          isLocked: typeof parsed.isLocked === 'boolean' ? parsed.isLocked : false,
          lockedCanteenId: typeof parsed.lockedCanteenId === 'string' ? parsed.lockedCanteenId : '',
        };
      }
    }
  } catch (e) {
    console.error('Error reading localStorage:', e);
  }
  return seed;
}

export function saveStateToStorage(state: AppState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    const hasData =
      (state.dailyEntries && state.dailyEntries.length > 0) ||
      (state.canteenCashDeposits && state.canteenCashDeposits.length > 0) ||
      (state.staffList && state.staffList.length > 0) ||
      (state.attendanceRecords && state.attendanceRecords.length > 0) ||
      (state.staffFinancials && state.staffFinancials.length > 0) ||
      (state.invoices && state.invoices.length > 0) ||
      (state.invoiceChequePayments && state.invoiceChequePayments.length > 0) ||
      (state.parties && state.parties.length > 0) ||
      (state.windowShiftSales && state.windowShiftSales.length > 0) ||
      (state.labourWorkers && state.labourWorkers.length > 0) ||
      (state.labourTokenIssues && state.labourTokenIssues.length > 0) ||
      (state.pettyCashExpenses && state.pettyCashExpenses.length > 0);
    if (hasData) {
      localStorage.setItem(BACKUP_KEY, JSON.stringify(state));
    }
  } catch (e) {
    console.error('Failed to save to localStorage:', e);
  }
}

export function recoverBrowserBackups(): {
  recoveredEntries: number;
  recoveredStaff: number;
  recoveredAttendance: number;
  recoveredFinancials: number;
  mergedState: AppState;
} {
  const currentState = getInitialState();
  return {
    recoveredEntries: currentState.dailyEntries.length,
    recoveredStaff: currentState.staffList.length,
    recoveredAttendance: currentState.attendanceRecords.length,
    recoveredFinancials: currentState.staffFinancials.length,
    mergedState: currentState,
  };
}

export function downloadExcel(
  data: Record<string, any>[],
  filename: string,
  sheetName: string = 'Sheet1'
) {
  try {
    const worksheet = XLSX.utils.json_to_sheet(data);
    const keys = data.length > 0 ? Object.keys(data[0]) : [];
    const colWidths = keys.map(key => {
      let maxLen = key.toString().length;
      data.forEach(row => {
        const val = row[key] !== null && row[key] !== undefined ? row[key].toString() : '';
        if (val.length > maxLen) maxLen = val.length;
      });
      return { wch: Math.min(Math.max(maxLen + 4, 12), 40) };
    });
    worksheet['!cols'] = colWidths;
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
    XLSX.writeFile(workbook, `${filename}.xlsx`);
  } catch (error) {
    console.error('Error generating Excel file:', error);
  }
}

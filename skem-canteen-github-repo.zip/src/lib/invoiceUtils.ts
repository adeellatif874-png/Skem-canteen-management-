import * as XLSX from 'xlsx';
import { Invoice, InvoiceItem, InvoiceChequePayment } from '../types';

export function resolveBuyerAddress(address?: string): string {
  if (
    !address ||
    address.trim() === '' ||
    address.toLowerCase().includes('seikhupura') ||
    address.toLowerCase().includes('sheikhupura') ||
    address.toLowerCase().includes('35 k.m') ||
    address.toLowerCase().includes('35km') ||
    address.toLowerCase().includes('main seikhupura')
  ) {
    return 'P102 jail road Faisalabad';
  }
  return address;
}

// Convert number to words in Pakistani Rupees English representation
export function numberToWords(amount: number): string {
  const num = Math.round(Math.abs(amount));
  if (num === 0) return 'Rupees Zero Only';

  const ones = [
    '',
    'One',
    'Two',
    'Three',
    'Four',
    'Five',
    'Six',
    'Seven',
    'Eight',
    'Nine',
    'Ten',
    'Eleven',
    'Twelve',
    'Thirteen',
    'Fourteen',
    'Fifteen',
    'Sixteen',
    'Seventeen',
    'Eighteen',
    'Nineteen',
  ];

  const tens = [
    '',
    '',
    'Twenty',
    'Thirty',
    'Forty',
    'Fifty',
    'Sixty',
    'Seventy',
    'Eighty',
    'Ninety',
  ];

  function convertBelowThousand(n: number): string {
    let result = '';
    if (n >= 100) {
      result += ones[Math.floor(n / 100)] + ' Hundred ';
      n %= 100;
    }
    if (n >= 20) {
      result += tens[Math.floor(n / 10)] + ' ';
      n %= 10;
    }
    if (n > 0) {
      result += ones[n] + ' ';
    }
    return result.trim();
  }

  let words = '';
  let remaining = num;

  // Crore (10,000,000)
  if (remaining >= 10000000) {
    const crore = Math.floor(remaining / 10000000);
    words += convertBelowThousand(crore) + ' Crore ';
    remaining %= 10000000;
  }

  // Lakh (100,000)
  if (remaining >= 100000) {
    const lakh = Math.floor(remaining / 100000);
    words += convertBelowThousand(lakh) + ' Lakh ';
    remaining %= 100000;
  }

  // Thousand (1,000)
  if (remaining >= 1000) {
    const thousand = Math.floor(remaining / 1000);
    words += convertBelowThousand(thousand) + ' Thousand ';
    remaining %= 1000;
  }

  // Remaining below thousand
  if (remaining > 0) {
    words += convertBelowThousand(remaining);
  }

  return `Rupees ${words.trim()} Only`;
}

// Calculate totals for invoice line items
export function calculateInvoiceTotals(items: InvoiceItem[]) {
  let totalQty = 0;
  let totalAmountWithoutGst = 0;
  let totalGstAmount = 0;
  let totalNetAmount = 0;

  items.forEach((item) => {
    const qty = Number(item.qty) || 0;
    const rate = Number(item.rate) || 0;
    const amountWithoutGst = qty * rate;
    const gstRate = Number(item.gstRate) || 0;
    const gstAmount = Math.round((amountWithoutGst * gstRate) / 100);
    const netAmount = amountWithoutGst + gstAmount;

    totalQty += qty;
    totalAmountWithoutGst += amountWithoutGst;
    totalGstAmount += gstAmount;
    totalNetAmount += netAmount;
  });

  return {
    totalQty,
    totalAmountWithoutGst,
    totalGstAmount,
    totalNetAmount,
    amountInWords: numberToWords(totalNetAmount),
  };
}

// Generate full styled HTML for printing & exact Excel export
export function generateInvoiceHTML(invoice: Invoice): string {
  let compName1 = invoice.companyName || 'RNC';
  let compName2 = 'ENTERPRISES';
  if (compName1.includes(' ')) {
    const parts = compName1.split(' ');
    compName1 = parts[0];
    compName2 = parts.slice(1).join(' ');
  }

  const items = invoice.items || [];
  const emptyRowsNeeded = Math.max(0, 4 - items.length);

  return `
<!DOCTYPE html>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="UTF-8">
<title>Sales Tax Invoice #${invoice.invoiceNo}</title>
<!--[if gte mso 9]>
<xml>
 <x:ExcelWorkbook>
  <x:ExcelWorksheets>
   <x:ExcelWorksheet>
    <x:Name>Sales Tax Invoice</x:Name>
    <x:WorksheetOptions>
     <x:DisplayGridlines/>
    </x:WorksheetOptions>
   </x:ExcelWorksheet>
  </x:ExcelWorksheets>
 </x:ExcelWorkbook>
</xml>
<![endif]-->
<style>
  @page {
    size: A4 portrait;
    margin: 8mm;
  }
  * {
    box-sizing: border-box;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
  body {
    font-family: Arial, Calibri, 'Segoe UI', Helvetica, sans-serif;
    color: #000;
    background: #fff;
    margin: 0;
    padding: 10px;
    font-size: 11px;
    line-height: 1.3;
  }
  .invoice-container {
    width: 100%;
    max-width: 820px;
    margin: 0 auto;
    border: 2px solid #000;
    padding: 12px 14px;
    background: #fff;
  }
  .header-section {
    text-align: center;
    border-bottom: 2px solid #000;
    padding-bottom: 6px;
    margin-bottom: 8px;
  }
  .comp-title-1 {
    font-size: 24px;
    font-weight: 900;
    letter-spacing: 2px;
    margin: 0;
    text-decoration: underline;
    text-transform: uppercase;
  }
  .comp-title-2 {
    font-size: 20px;
    font-weight: 900;
    letter-spacing: 2px;
    margin: 0;
    text-transform: uppercase;
  }
  .header-address {
    font-size: 11px;
    font-weight: 600;
    margin: 3px 0 1px 0;
  }
  .header-ntn {
    font-size: 11px;
    font-weight: 700;
    margin: 1px 0;
  }
  .header-phone {
    font-size: 11px;
    font-weight: 700;
    margin: 1px 0 4px 0;
  }
  .invoice-title {
    font-size: 15px;
    font-weight: 900;
    letter-spacing: 1px;
    text-transform: uppercase;
    margin-top: 4px;
    display: inline-block;
    padding: 2px 10px;
    border: 1px solid #000;
  }
  .meta-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 8px;
  }
  .meta-table td {
    border: 1px solid #000;
    padding: 4px 6px;
    vertical-align: middle;
    font-size: 11px;
  }
  .meta-label {
    font-weight: 800;
    background-color: #f8f8f8;
  }
  .meta-val {
    font-weight: 600;
  }
  .items-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 8px;
  }
  .items-table th, .items-table td {
    border: 1px solid #000;
    padding: 5px 4px;
    font-size: 10.5px;
  }
  .items-table th {
    background-color: #f0f0f0;
    font-weight: 800;
    text-align: center;
    text-transform: uppercase;
  }
  .text-center { text-align: center; }
  .text-right { text-align: right; }
  .text-left { text-align: left; }
  .bold { font-weight: 800; }
  .words-box {
    border: 1px solid #000;
    padding: 6px 8px;
    font-size: 11px;
    font-weight: 800;
    margin-bottom: 30px;
    background-color: #fafafa;
  }
  .signatures-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 25px;
  }
  .signatures-table td {
    border: none;
    padding: 10px 4px 0 4px;
    text-align: center;
    font-weight: 800;
    font-size: 11px;
    vertical-align: top;
    width: 33.33%;
  }
  .sig-line {
    border-top: 1.5px solid #000;
    width: 80%;
    margin: 0 auto 4px auto;
  }
  .system-generated-footer {
    text-align: center;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: #333;
    border-top: 1px dashed #666;
    margin-top: 22px;
    padding-top: 7px;
  }
</style>
</head>
<body>

<div class="invoice-container">
  <!-- Header -->
  <div class="header-section">
    <div class="comp-title-1">${compName1}</div>
    <div class="comp-title-2">${compName2}</div>
    <div class="header-address">${invoice.companyAddress || 'Second floor near zaika hotel jarranwala road, Khurrianwala'}</div>
    <div class="header-ntn">NTN#  ${invoice.companyNtn || '121541-5'}, STRN# ${invoice.companyStrn || '2400690400146'}</div>
    <div class="header-phone">PHONE NO: ${invoice.companyPhone || '041-5489876 : 0300-8653676'}</div>
    <div><span class="invoice-title">${invoice.invoiceTitle || 'SALES TAX INVOICE'}</span></div>
  </div>

  <!-- Buyer & PO Details Box -->
  <table class="meta-table">
    <tr>
      <td class="meta-label" style="width: 15%;">BUYER NAME</td>
      <td class="meta-val bold" style="width: 50%;">${invoice.buyerName || ''}</td>
      <td class="meta-label text-center" style="width: 15%;">INV. NO.</td>
      <td class="meta-val bold text-center" style="width: 20%;">${invoice.invoiceNo || ''}</td>
    </tr>
    <tr>
      <td class="meta-label">NTN#</td>
      <td class="meta-val">${invoice.buyerNtn || '-'}</td>
      <td class="meta-label text-center">INVOICE DATE</td>
      <td class="meta-val text-center">${invoice.invoiceDate || invoice.poDate || '-'}</td>
    </tr>
    <tr>
      <td class="meta-label">STRN#</td>
      <td class="meta-val">${invoice.buyerStrn || '-'}</td>
      <td class="meta-label text-center">PO NO.</td>
      <td class="meta-val text-center">${invoice.poNo || '-'}</td>
    </tr>
    <tr>
      <td colspan="4" class="meta-val" style="padding: 5px 6px;">
        <strong>Address:</strong> ${resolveBuyerAddress(invoice.buyerAddress)}
      </td>
    </tr>
  </table>

  <!-- Items Table -->
  <table class="items-table">
    <thead>
      <tr>
        <th style="width: 5%;">S/NO.</th>
        <th style="width: 6%;">UM</th>
        <th style="width: 12%;">GRN DATE</th>
        <th style="width: 9%;">GRN#</th>
        <th style="width: 28%;">PARTICULARS</th>
        <th style="width: 6%;">QTY</th>
        <th style="width: 10%;">RATE</th>
        <th style="width: 12%;">AMOUNT W/O GST</th>
        <th style="width: 10%;">GST 18%</th>
        <th style="width: 12%;">NET AMOUNT</th>
      </tr>
    </thead>
    <tbody>
      ${items
        .map(
          (it, idx) => `
        <tr>
          <td class="text-center bold">${it.sNo || idx + 1}</td>
          <td class="text-center">${it.um || 'CF'}</td>
          <td class="text-center">${it.grnDate || invoice.invoiceDate}</td>
          <td class="text-center">${it.grnNo || '-'}</td>
          <td class="text-left bold">${it.particulars}</td>
          <td class="text-center bold">${it.qty}</td>
          <td class="text-right">${Number(it.rate).toLocaleString()}</td>
          <td class="text-right bold">${Number(it.amountWithoutGst).toLocaleString()}</td>
          <td class="text-right">${Number(it.gstAmount).toLocaleString()}</td>
          <td class="text-right bold">${Number(it.netAmount).toLocaleString()}</td>
        </tr>
      `
        )
        .join('')}
      ${Array.from({ length: emptyRowsNeeded })
        .map(
          () => `
        <tr style="height: 22px;">
          <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
          <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
        </tr>
      `
        )
        .join('')}
      <tr style="background-color: #f7f7f7; font-size: 11px;">
        <td colspan="5" class="text-center bold" style="letter-spacing: 1px;">TOTAL</td>
        <td class="text-center bold">${invoice.totalQty || 0}</td>
        <td></td>
        <td class="text-right bold">${Number(invoice.totalAmountWithoutGst || 0).toLocaleString()}</td>
        <td class="text-right bold">${Number(invoice.totalGstAmount || 0).toLocaleString()}</td>
        <td class="text-right bold" style="font-size: 12px;">${Number(invoice.totalNetAmount || 0).toLocaleString()}</td>
      </tr>
    </tbody>
  </table>

  <!-- Amount In Words -->
  <div class="words-box">
    <span>AMOUNT IN WORDS: </span>
    <span>${invoice.amountInWords || numberToWords(invoice.totalNetAmount || 0)}</span>
  </div>

  <!-- Signatures -->
  <table class="signatures-table">
    <tr>
      <td>
        <div class="sig-line"></div>
        PREPARED BY
      </td>
      <td>
        <div class="sig-line"></div>
        CHECKED BY
      </td>
      <td>
        <div class="sig-line"></div>
        AUTHORIZED SIGNATURE
      </td>
    </tr>
  </table>

  <!-- System Generated Invoice Footer -->
  <div class="system-generated-footer">
    This is a system generated invoice - No signature required
  </div>
</div>

</body>
</html>
`;
}

// Direct Print Invoice through dedicated isolated iframe
export function printInvoiceDocument(invoice: Invoice): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      const html = generateInvoiceHTML(invoice);

      // Remove existing print iframe if any
      const existing = document.getElementById('rnc-invoice-print-frame');
      if (existing) {
        existing.remove();
      }

      // Create hidden iframe
      const iframe = document.createElement('iframe');
      iframe.id = 'rnc-invoice-print-frame';
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      iframe.style.visibility = 'hidden';

      document.body.appendChild(iframe);

      const doc = iframe.contentWindow?.document || iframe.contentDocument;
      if (!doc) {
        // Fallback: open in window or trigger direct print
        window.print();
        resolve(true);
        return;
      }

      doc.open();
      doc.write(html);
      doc.close();

      setTimeout(() => {
        try {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
          resolve(true);
        } catch (e) {
          console.warn('Iframe print error, falling back to standard print:', e);
          window.print();
          resolve(true);
        }
      }, 350);
    } catch (err) {
      console.error('Print failure:', err);
      window.print();
      resolve(false);
    }
  });
}

// Export single invoice to EXACT Formatted Excel (.xls / .xlsx styled spreadsheet)
export function exportInvoiceToExactExcel(invoice: Invoice) {
  const html = generateInvoiceHTML(invoice);
  const blob = new Blob([html], {
    type: 'application/vnd.ms-excel;charset=utf-8',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const fileName = `Sales_Tax_Invoice_${invoice.invoiceNo || 'Doc'}_${
    (invoice.buyerName || 'Client').replace(/[^a-zA-Z0-9]/g, '_')
  }.xls`;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Export multiple invoices into formatted Excel with individual sheets + Master Summary
export function exportAllInvoicesFormattedExcel(invoices: Invoice[]) {
  if (!invoices || invoices.length === 0) return;

  const wb = XLSX.utils.book_new();

  // 1. Summary Sheet
  const summaryAoa: any[][] = [
    ['SALES TAX INVOICES - MASTER SUMMARY REPORT'],
    [`Generated Date: ${new Date().toISOString().split('T')[0]}`],
    [''],
    [
      'Inv #',
      'Invoice Date',
      'Buyer Name',
      'Buyer NTN',
      'Buyer STRN',
      'PO #',
      'Total Qty',
      'Amount W/O GST',
      'GST 18%',
      'Net Amount',
    ],
  ];

  let sumQty = 0;
  let sumAmountWithoutGst = 0;
  let sumGst = 0;
  let sumNet = 0;

  invoices.forEach((inv) => {
    sumQty += inv.totalQty || 0;
    sumAmountWithoutGst += inv.totalAmountWithoutGst || 0;
    sumGst += inv.totalGstAmount || 0;
    sumNet += inv.totalNetAmount || 0;

    summaryAoa.push([
      inv.invoiceNo,
      inv.invoiceDate,
      inv.buyerName,
      inv.buyerNtn || '-',
      inv.buyerStrn || '-',
      inv.poNo || '-',
      inv.totalQty,
      inv.totalAmountWithoutGst,
      inv.totalGstAmount,
      inv.totalNetAmount,
    ]);
  });

  summaryAoa.push([
    'TOTAL',
    '',
    '',
    '',
    '',
    '',
    '',
    sumQty,
    sumAmountWithoutGst,
    sumGst,
    sumNet,
  ]);

  const summaryWs = XLSX.utils.aoa_to_sheet(summaryAoa);
  summaryWs['!cols'] = [
    { wch: 10 },
    { wch: 12 },
    { wch: 32 },
    { wch: 16 },
    { wch: 18 },
    { wch: 12 },
    { wch: 12 },
    { wch: 10 },
    { wch: 16 },
    { wch: 14 },
    { wch: 18 },
  ];
  XLSX.utils.book_append_sheet(wb, summaryWs, 'Summary');

  // 2. Add individual formatted sheet for each invoice (up to 30 sheets)
  invoices.slice(0, 30).forEach((invoice) => {
    const aoa: any[][] = [];
    const merges: XLSX.Range[] = [];

    let compName1 = invoice.companyName || 'RNC';
    let compName2 = 'ENTERPRISES';
    if (compName1.includes(' ')) {
      const parts = compName1.split(' ');
      compName1 = parts[0];
      compName2 = parts.slice(1).join(' ');
    }

    aoa.push([compName1, '', '', '', '', '', '', '', '', '']);
    merges.push({ s: { r: 0, c: 0 }, e: { r: 0, c: 9 } });

    aoa.push([compName2, '', '', '', '', '', '', '', '', '']);
    merges.push({ s: { r: 1, c: 0 }, e: { r: 1, c: 9 } });

    aoa.push([
      invoice.companyAddress ||
        'Second floor near zaika hotel jarranwala road, Khurrianwala',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
    ]);
    merges.push({ s: { r: 2, c: 0 }, e: { r: 2, c: 9 } });

    aoa.push([
      `NTN#  ${invoice.companyNtn || '121541-5'}, STRN# ${
        invoice.companyStrn || '2400690400146'
      }`,
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
    ]);
    merges.push({ s: { r: 3, c: 0 }, e: { r: 3, c: 9 } });

    aoa.push([
      `PHONE NO: ${invoice.companyPhone || '041-5489876 : 0300-8653676'}`,
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
    ]);
    merges.push({ s: { r: 4, c: 0 }, e: { r: 4, c: 9 } });

    aoa.push([
      invoice.invoiceTitle || 'SALES TAX INVOICE',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
    ]);
    merges.push({ s: { r: 5, c: 0 }, e: { r: 5, c: 9 } });

    aoa.push([
      'BUYER NAME',
      invoice.buyerName || '',
      '',
      '',
      '',
      '',
      'INV. NO.',
      invoice.invoiceNo || '',
      '',
      '',
    ]);
    merges.push({ s: { r: 6, c: 1 }, e: { r: 6, c: 5 } });
    merges.push({ s: { r: 6, c: 7 }, e: { r: 6, c: 9 } });

    aoa.push([
      '',
      'NTN#',
      invoice.buyerNtn || '',
      '',
      '',
      '',
      'INVOICE DATE',
      invoice.invoiceDate || invoice.poDate || '',
      '',
      '',
    ]);
    merges.push({ s: { r: 7, c: 2 }, e: { r: 7, c: 5 } });
    merges.push({ s: { r: 7, c: 7 }, e: { r: 7, c: 9 } });

    aoa.push([
      '',
      'STRN#',
      invoice.buyerStrn || '',
      '',
      '',
      '',
      'PO NO.',
      invoice.poNo || '',
      '',
      '',
    ]);
    merges.push({ s: { r: 8, c: 2 }, e: { r: 8, c: 5 } });
    merges.push({ s: { r: 8, c: 7 }, e: { r: 8, c: 9 } });

    aoa.push([
      resolveBuyerAddress(invoice.buyerAddress),
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
    ]);
    merges.push({ s: { r: 9, c: 0 }, e: { r: 9, c: 9 } });

    aoa.push([
      'S/NO.',
      'UM',
      'GRN DATE',
      'GRN#',
      'PARTICULARS',
      'QTY',
      'RATE',
      'AMOUNT W/O GST',
      'GST 18%',
      'NET AMOUNT',
    ]);

    let currentRow = 11;
    invoice.items.forEach((item, idx) => {
      aoa.push([
        item.sNo || idx + 1,
        item.um || 'CF',
        item.grnDate || invoice.invoiceDate,
        item.grnNo || '',
        item.particulars,
        Number(item.qty) || 0,
        Number(item.rate) || 0,
        Number(item.amountWithoutGst) || 0,
        Number(item.gstAmount) || 0,
        Number(item.netAmount) || 0,
      ]);
      currentRow++;
    });

    for (let s = 0; s < 3; s++) {
      aoa.push(['', '', '', '', '', '', '', '', '', '']);
      currentRow++;
    }

    aoa.push([
      'TOTAL',
      '',
      '',
      '',
      '',
      invoice.totalQty || 0,
      '',
      invoice.totalAmountWithoutGst || 0,
      invoice.totalGstAmount || 0,
      invoice.totalNetAmount || 0,
    ]);
    merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 4 } });
    currentRow++;

    aoa.push(['', '', '', '', '', '', '', '', '', '']);
    currentRow++;

    aoa.push([
      `AMOUNT IN WORDS: ${
        invoice.amountInWords || numberToWords(invoice.totalNetAmount || 0)
      }`,
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
    ]);
    merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 9 } });
    currentRow++;

    aoa.push(['', '', '', '', '', '', '', '', '', '']);
    currentRow++;

    aoa.push([
      'PREPARED BY',
      '',
      '',
      'CHECKED BY',
      '',
      '',
      '',
      'AUTHORIZED SIGNATURE',
      '',
      '',
    ]);
    merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 2 } });
    merges.push({ s: { r: currentRow, c: 3 }, e: { r: currentRow, c: 5 } });
    merges.push({ s: { r: currentRow, c: 7 }, e: { r: currentRow, c: 9 } });
    currentRow++;

    aoa.push(['', '', '', '', '', '', '', '', '', '']);
    currentRow++;

    aoa.push([
      'THIS IS A SYSTEM GENERATED INVOICE - NO SIGNATURE REQUIRED',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
    ]);
    merges.push({ s: { r: currentRow, c: 0 }, e: { r: currentRow, c: 9 } });
    currentRow++;

    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!merges'] = merges;
    ws['!cols'] = [
      { wch: 8 },
      { wch: 8 },
      { wch: 14 },
      { wch: 12 },
      { wch: 34 },
      { wch: 10 },
      { wch: 14 },
      { wch: 18 },
      { wch: 14 },
      { wch: 18 },
    ];

    const safeSheetName = `Inv_${(invoice.invoiceNo || '1').slice(0, 20)}`;
    XLSX.utils.book_append_sheet(wb, ws, safeSheetName);
  });

  const fileName = `Sales_Tax_Invoices_Complete_Report_${
    new Date().toISOString().split('T')[0]
  }.xlsx`;
  XLSX.writeFile(wb, fileName);
}

// Initial clean state for invoices
export const initialInvoices: Invoice[] = [];

// Export Cheque Payments to formatted Excel
export function exportChequesToExcel(
  cheques: InvoiceChequePayment[],
  currencySymbol: string = 'Rs.'
) {
  if (!cheques || cheques.length === 0) {
    alert('No cheque records to export.');
    return;
  }

  const rows = cheques.map((chq, index) => ({
    'Sr #': index + 1,
    'Receipt Date': chq.receivedDate || '',
    'Cheque Number': chq.chequeNo || '',
    'Bank Name': chq.bankName || '',
    'Cheque Date': chq.chequeDate || '',
    'Invoice Number': chq.invoiceNo || 'General',
    'Client / Buyer': chq.buyerName || '',
    [`Cheque Amount (${currencySymbol})`]: chq.amount || 0,
    [`WHT Deduction (${currencySymbol})`]: chq.whtDeduction || 0,
    [`GST Deduction (${currencySymbol})`]: chq.gstDeduction || 0,
    [`Total Settled (${currencySymbol})`]: chq.settledAmount || chq.amount || 0,
    'Cheque Status': chq.status || 'In Hand',
    'Deposit Account': chq.depositAccount || '',
    'Deposit Date': chq.depositDate || '',
    'Clearance Date': chq.clearedDate || '',
    'Receipt Voucher #': chq.receiptVoucherNo || '',
    'Notes / Remarks': chq.notes || '',
  }));

  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Cheques Register');

  // Set column widths
  ws['!cols'] = [
    { wch: 6 },
    { wch: 14 },
    { wch: 18 },
    { wch: 20 },
    { wch: 14 },
    { wch: 16 },
    { wch: 28 },
    { wch: 18 },
    { wch: 16 },
    { wch: 16 },
    { wch: 18 },
    { wch: 14 },
    { wch: 22 },
    { wch: 14 },
    { wch: 14 },
    { wch: 18 },
    { wch: 28 },
  ];

  const fileName = `Invoice_Cheque_Payments_Register_${new Date().toISOString().split('T')[0]}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

// Print Cheque Receipt Voucher / Acknowledgement Slip
export function printChequeReceiptVoucher(
  cheque: InvoiceChequePayment,
  currencySymbol: string = 'Rs.'
) {
  const printWindow = window.open('', '_blank', 'width=850,height=750');
  if (!printWindow) {
    alert('Please allow popups to print cheque voucher.');
    return;
  }

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <title>Cheque Receipt Voucher - ${cheque.chequeNo}</title>
        <style>
          @page { size: A5 landscape; margin: 12mm; }
          * { box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
          body { margin: 0; padding: 20px; color: #1e293b; font-size: 13px; line-height: 1.5; background: #fff; }
          .voucher-box { border: 2px solid #0f172a; border-radius: 8px; padding: 20px; }
          .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 15px; }
          .company-title { font-size: 20px; font-weight: 800; color: #0f172a; text-transform: uppercase; margin: 0; }
          .company-sub { font-size: 11px; color: #64748b; margin-top: 3px; }
          .voucher-badge { text-align: right; }
          .voucher-title { font-size: 16px; font-weight: 800; color: #0f172a; letter-spacing: 0.5px; }
          .voucher-no { font-size: 12px; font-weight: 700; color: #2563eb; margin-top: 2px; }
          .meta-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 18px; background: #f8fafc; padding: 12px; border-radius: 6px; border: 1px solid #e2e8f0; }
          .meta-item { display: flex; font-size: 12px; }
          .meta-label { width: 140px; font-weight: 700; color: #475569; }
          .meta-value { font-weight: 600; color: #0f172a; }
          .cheque-details { width: 100%; border-collapse: collapse; margin-bottom: 18px; }
          .cheque-details th { background: #0f172a; color: #fff; padding: 8px 12px; text-align: left; font-size: 12px; }
          .cheque-details td { padding: 10px 12px; border-bottom: 1px solid #e2e8f0; font-size: 13px; }
          .amount-box { text-align: right; background: #f0fdf4; border: 1px solid #86efac; border-radius: 6px; padding: 10px 14px; margin-bottom: 20px; }
          .amount-words { font-size: 12px; font-style: italic; color: #166534; font-weight: 600; margin-top: 4px; }
          .signatures { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-top: 40px; padding-top: 10px; }
          .sig-line { border-top: 1px dashed #64748b; text-align: center; font-size: 11px; font-weight: 700; color: #475569; padding-top: 5px; }
          @media print {
            body { padding: 0; }
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="voucher-box">
          <div class="header">
            <div>
              <h1 class="company-title">RNC ENTERPRISES</h1>
              <div class="company-sub">Canteen & Corporate Catering Management • Faisalabad</div>
            </div>
            <div class="voucher-badge">
              <div class="voucher-title">CHEQUE RECEIPT VOUCHER</div>
              <div class="voucher-no">Voucher Ref: ${cheque.receiptVoucherNo || `CRV-${cheque.chequeNo}`}</div>
            </div>
          </div>

          <div class="meta-grid">
            <div class="meta-item"><span class="meta-label">Client / Buyer:</span><span class="meta-value">${cheque.buyerName || 'N/A'}</span></div>
            <div class="meta-item"><span class="meta-label">Receipt Date:</span><span class="meta-value">${cheque.receivedDate || new Date().toISOString().split('T')[0]}</span></div>
            <div class="meta-item"><span class="meta-label">Linked Invoice #:</span><span class="meta-value">Invoice #${cheque.invoiceNo || 'General'}</span></div>
            <div class="meta-item"><span class="meta-label">Current Status:</span><span class="meta-value">${cheque.status}</span></div>
          </div>

          <table class="cheque-details">
            <thead>
              <tr>
                <th>Bank Name</th>
                <th>Cheque Number</th>
                <th>Cheque Date</th>
                <th>Deposit Account</th>
                <th style="text-align: right;">Cheque Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>${cheque.bankName}</strong></td>
                <td><strong>${cheque.chequeNo}</strong></td>
                <td>${cheque.chequeDate}</td>
                <td>${cheque.depositAccount || 'Default Company Account'}</td>
                <td style="text-align: right; font-weight: 800; font-size: 15px; color: #0f172a;">
                  ${currencySymbol} ${(cheque.amount || 0).toLocaleString()}
                </td>
              </tr>
            </tbody>
          </table>

          ${(cheque.whtDeduction || cheque.gstDeduction) ? `
            <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 6px; padding: 8px 12px; margin-bottom: 12px; font-size: 11px; display: flex; justify-content: space-between;">
              <span><strong>Tax Deductions:</strong> WHT: ${currencySymbol} ${(cheque.whtDeduction || 0).toLocaleString()} | GST: ${currencySymbol} ${(cheque.gstDeduction || 0).toLocaleString()}</span>
              <span><strong>Total Settled Invoice Credit:</strong> ${currencySymbol} ${(cheque.settledAmount || cheque.amount).toLocaleString()}</span>
            </div>
          ` : ''}

          <div class="amount-box">
            <div style="font-size: 14px; font-weight: 800; color: #166534;">
              Net Amount Received: ${currencySymbol} ${(cheque.amount || 0).toLocaleString()}
            </div>
            <div class="amount-words">Amount in words: ${numberToWords(cheque.amount || 0)}</div>
          </div>

          ${cheque.notes ? `<div style="font-size: 11px; color: #64748b; margin-bottom: 15px;"><strong>Remarks:</strong> ${cheque.notes}</div>` : ''}

          <div class="signatures">
            <div class="sig-line">RECEIVED BY</div>
            <div class="sig-line">ACCOUNTANT / VERIFIED</div>
            <div class="sig-line">AUTHORIZED SIGNATURE</div>
          </div>
        </div>

        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 300);
          };
        </script>
      </body>
    </html>
  `;

  printWindow.document.write(html);
  printWindow.document.close();
}



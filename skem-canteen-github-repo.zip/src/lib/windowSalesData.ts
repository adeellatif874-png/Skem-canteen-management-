import { WindowShiftSale, PRESET_WINDOWS, PRESET_SHIFTS } from '../types';
import * as XLSX from 'xlsx';
import { formatDisplayDate } from './storage';

export { PRESET_WINDOWS, PRESET_SHIFTS };

export function getDayOfWeek(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  return days[date.getDay()];
}

// Clean initial empty state for real canteen operations
export const initialWindowShiftSales: WindowShiftSale[] = [];

// Helper to export Shift & Window sales report to Excel
export function exportWindowSalesExcel(sales: WindowShiftSale[], currencySymbol: string = 'Rs.') {
  const rows = sales.map((s, index) => ({
    '#': index + 1,
    Date: formatDisplayDate(s.date),
    Day: s.dayOfWeek || getDayOfWeek(s.date),
    Canteen: s.canteenName,
    Shift: s.shift,
    'Window / Counter': s.windowName,
    [`Sale Amount (${currencySymbol})`]: s.totalSale ?? s.amount,
    'Cash Sales': s.cashSales ?? s.amount,
    'Token Sales': s.tokenSales ?? 0,
    'Token Count': s.tokens || '-',
    Cashier: s.operatorName || '-',
    Remarks: s.remarks || s.notes || '',
  }));

  const ws = XLSX.utils.json_to_sheet(rows);

  ws['!cols'] = [
    { wch: 6 },
    { wch: 14 },
    { wch: 12 },
    { wch: 22 },
    { wch: 14 },
    { wch: 18 },
    { wch: 18 },
    { wch: 14 },
    { wch: 14 },
    { wch: 14 },
    { wch: 16 },
    { wch: 30 },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Window_Shift_Sales');

  const fileName = `Window_Shift_Sales_Report_${new Date().toISOString().split('T')[0]}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

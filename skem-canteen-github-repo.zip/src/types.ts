export type CanteenStatus = 'active' | 'inactive';

export interface Canteen {
  id: string;
  name: string;
  code: string;
  location?: string;
  contactPerson?: string;
  phone?: string;
  status: CanteenStatus;
  createdAt: string;
}

export interface DailyEntry {
  id: string;
  date: string; // YYYY-MM-DD
  canteenId: string;
  canteenName: string;
  normalSale: number;
  tokenSale: number;
  totalSale: number; // calculated: normalSale + tokenSale
  purchase: number;
  expenses: number;
  expenseNote?: string;
  remarks?: string;
  netAmount: number; // calculated: totalSale - purchase - expenses
  createdAt: string;
}

export type StaffStatus = 'active' | 'inactive';

export interface Staff {
  id: string;
  name: string;
  canteenId: string;
  canteenName: string;
  phone?: string;
  designation: string;
  monthlySalary?: number; // Total monthly fixed salary
  joiningDate: string; // YYYY-MM-DD
  status: StaffStatus;
  createdAt: string;
}

export type AttendanceStatus = 'Present' | 'Leave' | 'Absent';

export interface AttendanceRecord {
  id: string;
  staffId: string;
  staffName: string;
  canteenId: string;
  canteenName: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  inTime?: string; // HH:mm
  outTime?: string; // HH:mm
  leaveReason?: string;
  remarks?: string;
  createdAt: string;
}

export type FinancialRecordType = 'Advance' | 'Penalty';

export interface StaffFinancialRecord {
  id: string;
  staffId: string;
  staffName: string;
  canteenId: string;
  canteenName: string;
  date: string; // YYYY-MM-DD
  type: FinancialRecordType;
  amount: number;
  note: string;
  createdAt: string;
}

export type DateFilterType = 'today' | 'yesterday' | 'this_week' | 'this_month' | 'last_month' | 'all_time' | 'custom';

export interface DashboardFilters {
  dateFilter: DateFilterType;
  startDate?: string;
  endDate?: string;
  canteenId: string; // 'all' or specific id
}

export interface InvoiceItem {
  id: string;
  sNo: number;
  um: string; // Unit of Measure (e.g. CF, PCS, KG, NOS, PKT, BOX, LTR, MTR)
  grnDate?: string; // YYYY-MM-DD
  grnNo?: string;
  particulars: string;
  qty: number;
  rate: number;
  amountWithoutGst: number;
  gstRate: number; // e.g. 18 (for 18%)
  gstAmount: number;
  netAmount: number;
}

export interface Invoice {
  id: string;
  invoiceNo: string; // e.g. "11" or "INV-2026-001"
  invoiceDate: string; // YYYY-MM-DD
  canteenId?: string; // Associated canteen / branch
  canteenName?: string;
  
  // Seller / Company Info
  companyName: string; // e.g. "RNC ENTERPRISES"
  companyAddress: string; // e.g. "Second floor near zaika hotel jarranwala road, Khurrianwala"
  companyNtn: string; // e.g. "121541-5"
  companyStrn: string; // e.g. "2400690400146"
  companyPhone: string; // e.g. "041-5489876 : 0300-8653676"
  invoiceTitle: string; // e.g. "SALES TAX INVOICE"
  
  // Buyer Info
  buyerName: string; // e.g. "BEACON IMPEX (BEACON GENERAL)"
  buyerNtn: string; // e.g. "2560721-9"
  buyerStrn: string; // e.g. "08-01-3200-019-37"
  buyerAddress: string; // e.g. "P102 jail road Faisalabad"
  
  // Order Info
  poNo?: string; // e.g. "3398"
  poDate?: string;
  
  // Line Items
  items: InvoiceItem[];
  
  // Totals
  totalQty: number;
  totalAmountWithoutGst: number;
  totalGstAmount: number;
  totalNetAmount: number;
  amountInWords?: string;
  
  // Notes / Signatures
  notes?: string;
  terms?: string;
  createdAt: string;
}

export type ChequeStatus = 'In Hand' | 'Deposited' | 'Cleared' | 'Bounced' | 'Cancelled';

export interface InvoiceChequePayment {
  id: string;
  invoiceId: string; // Associated Invoice ID (or 'general')
  invoiceNo: string; // e.g. "11" or "INV-2026-001"
  buyerName: string; // e.g. "BEACON IMPEX (BEACON GENERAL)"
  canteenId?: string;
  canteenName?: string;
  
  // Cheque Details
  chequeNo: string; // Cheque number e.g. "CHQ-894102"
  bankName: string; // Bank name (e.g. Meezan Bank, HBL, MCB, etc.)
  chequeDate: string; // Date printed on cheque (YYYY-MM-DD)
  receivedDate: string; // Date physically received (YYYY-MM-DD)
  depositDate?: string; // Date deposited in bank account (YYYY-MM-DD)
  clearedDate?: string; // Date cleared / funds credited (YYYY-MM-DD)
  
  // Amounts
  amount: number; // Cheque amount
  whtDeduction?: number; // Income tax / WHT withheld by client
  gstDeduction?: number; // Sales tax withheld by client
  settledAmount: number; // Total credited towards invoice (amount + wht + gst)
  
  depositAccount?: string; // Company bank account deposited to
  status: ChequeStatus; // 'In Hand' | 'Deposited' | 'Cleared' | 'Bounced' | 'Cancelled'
  bouncedReason?: string;
  receiptVoucherNo?: string; // Internal Receipt Voucher #
  notes?: string;
  createdAt: string;
}

export type PartyType = 'supplier' | 'customer';

export interface Party {
  id: string;
  name: string; // e.g. "MK Son's" or "Al-Madina Stock Supplies"
  type: PartyType; // 'supplier' (Stock hum letay hain, installments dytay hain) or 'customer' (Stock hum dytay hain, installments wo dytay hain)
  phone?: string;
  address?: string;
  openingBalance: number;
  currentBalance: number;
  canteenId?: string; // Optional canteen association
  notes?: string;
  createdAt: string;
}

export type PartyTransactionType = 'stock_bill' | 'installment_payment';

export interface PartyTransaction {
  id: string;
  partyId: string;
  partyName: string;
  partyType: PartyType;
  date: string; // YYYY-MM-DD
  type: PartyTransactionType;
  // For Supplier:
  // - stock_bill: Stock / Bill received (We owe more)
  // - installment_payment: Installment payment made (We owe less)
  // For Customer (e.g. MK Son's):
  // - stock_bill: Stock supplied / Bill issued (They owe more)
  // - installment_payment: Installment payment received (They owe less)
  amount: number;
  paymentMethod?: 'Cash' | 'Bank Transfer' | 'Cheque' | 'Slip' | 'Other';
  invoiceOrBillNo?: string;
  description: string;
  balanceAfter?: number;
  createdAt: string;
}

export const PRESET_WINDOWS = ['Window 1 & 2', 'Window 3 - 4', 'Taba', 'Window 6 - 7'] as const;
export const PRESET_SHIFTS = ['Morning', 'Evening', 'Night'] as const;

export interface WindowShiftSale {
  id: string;
  date: string; // YYYY-MM-DD
  dayOfWeek?: string; // e.g. "Monday", "Tuesday", etc.
  canteenId: string;
  canteenName: string;
  shift: 'Morning' | 'Evening' | 'Night' | string;
  windowName: 'Window 1 & 2' | 'Window 3 - 4' | 'Taba' | 'Window 6 - 7' | string;
  amount: number;
  cashSales?: number;
  tokens?: number;
  tokenSales?: number;
  totalSale: number;
  operatorName?: string;
  remarks?: string;
  notes?: string;
  createdAt: string;
}

export interface LabourWorker {
  id: string;
  name: string;
  labourNo?: string; // e.g. "L-101"
  canteenId: string; // e.g. Sadaqat Canteen
  canteenName: string;
  department?: string; // e.g. "Weaving", "Spinning", "Contractor Aslam"
  phone?: string;
  defaultTokenRate?: number; // default per token rate e.g. 100 (optional)
  status: 'active' | 'inactive';
  notes?: string;
  createdAt: string;
}

export interface LabourTokenIssue {
  id: string;
  labourId: string;
  labourName: string;
  canteenId: string;
  canteenName: string;
  date: string; // YYYY-MM-DD
  month: string; // YYYY-MM (e.g. "2026-09")
  tokenQty?: number; // optional (can write amount directly)
  tokenRate?: number; // optional
  totalAmount: number; // custom amount or tokenQty * tokenRate
  mealType?: string; // 'Breakfast' | 'Lunch' | 'Dinner' | 'General'
  remarks?: string;
  createdAt: string;
}

export interface LabourTokenPayment {
  id: string;
  labourId: string;
  labourName: string;
  canteenId: string;
  canteenName: string;
  date: string; // YYYY-MM-DD
  month: string; // YYYY-MM (the month settled)
  amount: number;
  paymentMethod: 'Cash' | 'Online / Bank' | 'Salary Deduction' | 'Other';
  depositedToDailySale: boolean; // if true, credited to DailyEntry normalSale
  dailyEntryDate?: string;
  notes?: string;
  createdAt: string;
}

export type PettyExpenseCategory =
  | 'Chai & Refreshment'
  | 'Cleaning & Detergents'
  | 'Transport & Rickshaw'
  | 'Ice & Cooling'
  | 'Repairs & Electric'
  | 'Stationery & Printing'
  | 'Packaging & Shoppers'
  | 'Kitchen Misc'
  | 'Staff Meal / Tea'
  | 'Other Misc';

export interface PettyCashExpense {
  id: string;
  date: string; // YYYY-MM-DD
  canteenId: string;
  canteenName: string;
  category: PettyExpenseCategory | string;
  itemTitle: string; // Detail of what was purchased/spent
  amount: number;
  paidTo?: string; // Shop / Vendor / Person paid
  paidBy?: string; // Staff member who paid or authorized
  voucherNo?: string; // Optional voucher / receipt number
  remarks?: string;
  createdAt: string;
}

export interface PettyCashFund {
  id: string;
  date: string; // YYYY-MM-DD
  canteenId: string;
  canteenName: string;
  amount: number;
  source: string; // e.g. "Main Cash Draw", "Owner Cash", "Bank"
  receivedBy?: string;
  notes?: string;
  createdAt: string;
}

export interface CanteenCashDeposit {
  id: string;
  date: string; // YYYY-MM-DD
  canteenId: string;
  canteenName: string;
  amount: number;
  depositTo: 'Bank Account' | 'Head Office / Owner' | 'Cashier' | 'Other' | string;
  bankName?: string; // e.g. "Habib Bank Limited", "Meezan Bank", "Cash to Owner"
  slipNumber?: string; // e.g. "Deposit Slip # 4920", "Online Ref 839"
  depositedBy?: string; // staff or incharge who made the deposit
  receivedBy?: string; // person or bank teller
  remarks?: string;
  createdAt: string;
}

export interface AppState {
  canteens: Canteen[];
  dailyEntries: DailyEntry[];
  canteenCashDeposits?: CanteenCashDeposit[];
  staffList: Staff[];
  attendanceRecords: AttendanceRecord[];
  staffFinancials: StaffFinancialRecord[];
  invoices?: Invoice[];
  invoiceChequePayments?: InvoiceChequePayment[];
  parties?: Party[];
  partyTransactions?: PartyTransaction[];
  windowShiftSales?: WindowShiftSale[];
  labourWorkers?: LabourWorker[];
  labourTokenIssues?: LabourTokenIssue[];
  labourTokenPayments?: LabourTokenPayment[];
  pettyCashExpenses?: PettyCashExpense[];
  pettyCashFunds?: PettyCashFund[];
  currencySymbol: string;
  pinCode?: string; // App Lock PIN code (e.g. "1234")
  isLocked?: boolean;
  lockedCanteenId?: string; // Branch Isolation: Lock app to a specific canteen ID
}

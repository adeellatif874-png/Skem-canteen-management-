import React, { useState, useMemo } from 'react';
import {
  Coins,
  PlusCircle,
  Calendar,
  Search,
  Download,
  Trash2,
  Edit2,
  Building2,
  Receipt,
  X,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import {
  Canteen,
  PettyCashExpense,
  PettyCashFund,
  PettyExpenseCategory,
} from '../types';
import { formatCurrency, formatDisplayDate, isCanteenMatch } from '../lib/storage';

interface PettyCashViewProps {
  pettyCashExpenses: PettyCashExpense[];
  pettyCashFunds: PettyCashFund[];
  canteens: Canteen[];
  selectedCanteenId: string;
  currencySymbol: string;
  onAddExpense: (expense: Omit<PettyCashExpense, 'id' | 'createdAt'>) => void;
  onEditExpense: (id: string, updated: Partial<PettyCashExpense>) => void;
  onDeleteExpense: (id: string) => void;
  onAddFund: (fund: Omit<PettyCashFund, 'id' | 'createdAt'>) => void;
  onDeleteFund: (id: string) => void;
}

const CATEGORIES: { label: PettyExpenseCategory; icon: string }[] = [
  { label: 'Chai & Refreshment', icon: '☕' },
  { label: 'Cleaning & Detergents', icon: '🧹' },
  { label: 'Transport & Rickshaw', icon: '🛵' },
  { label: 'Ice & Cooling', icon: '🧊' },
  { label: 'Repairs & Electric', icon: '🔧' },
  { label: 'Stationery & Printing', icon: '📝' },
  { label: 'Packaging & Shoppers', icon: '📦' },
  { label: 'Kitchen Misc', icon: '🍳' },
  { label: 'Staff Meal / Tea', icon: '👨‍🍳' },
  { label: 'Other Misc', icon: '💡' },
];

export const PettyCashView: React.FC<PettyCashViewProps> = ({
  pettyCashExpenses = [],
  pettyCashFunds = [],
  canteens = [],
  selectedCanteenId,
  currencySymbol = 'Rs.',
  onAddExpense,
  onEditExpense,
  onDeleteExpense,
  onAddFund,
  onDeleteFund,
}) => {
  // Active Tab: Expenses vs Float
  const [activeTab, setActiveTab] = useState<'expenses' | 'funds'>('expenses');

  // Filters
  const [branchFilter, setBranchFilter] = useState<string>(
    selectedCanteenId === 'all' ? 'cant-sadaqat' : selectedCanteenId
  );
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'yesterday' | 'this_week' | 'this_month' | 'custom'>('this_month');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Modals state
  const [isAddExpenseModalOpen, setIsAddExpenseModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<PettyCashExpense | null>(null);
  const [isAddFundModalOpen, setIsAddFundModalOpen] = useState(false);

  // In-app inline delete confirmation state (prevents iframe alert/confirm blocking)
  const [deleteConfirmExpenseId, setDeleteConfirmExpenseId] = useState<string | null>(null);
  const [deleteConfirmFundId, setDeleteConfirmFundId] = useState<string | null>(null);

  // Form error states
  const [expenseFormError, setExpenseFormError] = useState<string>('');
  const [fundFormError, setFundFormError] = useState<string>('');

  // Expense form data
  const [expenseForm, setExpenseForm] = useState({
    date: new Date().toISOString().split('T')[0],
    canteenId: branchFilter !== 'all' ? branchFilter : canteens[0]?.id || 'cant-sadaqat',
    category: 'Chai & Refreshment' as PettyExpenseCategory,
    itemTitle: '',
    amount: '',
    paidTo: '',
    paidBy: '',
    voucherNo: '',
    remarks: '',
  });

  // Fund form data
  const [fundForm, setFundForm] = useState({
    date: new Date().toISOString().split('T')[0],
    canteenId: branchFilter !== 'all' ? branchFilter : canteens[0]?.id || 'cant-sadaqat',
    amount: '',
    source: 'Branch Cash Float',
    receivedBy: '',
    notes: '',
  });

  const todayStr = new Date().toISOString().split('T')[0];

  // Helper date checker
  const isDateInFilter = (dateStr: string): boolean => {
    if (dateFilter === 'all') return true;
    if (dateFilter === 'today') return dateStr === todayStr;

    if (dateFilter === 'yesterday') {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      return dateStr === yesterday.toISOString().split('T')[0];
    }

    const now = new Date();
    if (dateFilter === 'this_week') {
      const startOfWeek = new Date(now);
      const day = startOfWeek.getDay() || 7;
      startOfWeek.setDate(startOfWeek.getDate() - day + 1);
      startOfWeek.setHours(0, 0, 0, 0);
      const d = new Date(dateStr + 'T00:00:00');
      return d >= startOfWeek;
    }

    if (dateFilter === 'this_month') {
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
      const d = new Date(dateStr + 'T00:00:00');
      return d >= firstDay;
    }

    if (dateFilter === 'custom') {
      if (!customStartDate || !customEndDate) return true;
      const start = new Date(customStartDate + 'T00:00:00');
      const end = new Date(customEndDate + 'T23:59:59');
      const d = new Date(dateStr + 'T00:00:00');
      return d >= start && d <= end;
    }

    return true;
  };

  // Filtered Expenses
  const filteredExpenses = useMemo(() => {
    return pettyCashExpenses.filter((exp) => {
      const branchMatch =
        branchFilter === 'all' ||
        exp.canteenId === branchFilter ||
        isCanteenMatch(exp, branchFilter, canteens);

      const dateMatch = isDateInFilter(exp.date);
      const catMatch = categoryFilter === 'all' || exp.category === categoryFilter;

      const q = searchQuery.toLowerCase().trim();
      const searchMatch =
        !q ||
        exp.itemTitle.toLowerCase().includes(q) ||
        (exp.paidTo && exp.paidTo.toLowerCase().includes(q)) ||
        (exp.paidBy && exp.paidBy.toLowerCase().includes(q)) ||
        (exp.voucherNo && exp.voucherNo.toLowerCase().includes(q)) ||
        exp.category.toLowerCase().includes(q) ||
        (exp.remarks && exp.remarks.toLowerCase().includes(q));

      return branchMatch && dateMatch && catMatch && searchMatch;
    });
  }, [
    pettyCashExpenses,
    branchFilter,
    dateFilter,
    customStartDate,
    customEndDate,
    categoryFilter,
    searchQuery,
    canteens,
  ]);

  // Filtered Funds
  const filteredFunds = useMemo(() => {
    return pettyCashFunds.filter((f) => {
      const branchMatch =
        branchFilter === 'all' ||
        f.canteenId === branchFilter ||
        isCanteenMatch(f, branchFilter, canteens);
      return branchMatch;
    });
  }, [pettyCashFunds, branchFilter, canteens]);

  // Totals
  const totalFunds = useMemo(() => {
    return filteredFunds.reduce((sum, f) => sum + (Number(f.amount) || 0), 0);
  }, [filteredFunds]);

  const totalExpenses = useMemo(() => {
    return filteredExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  }, [filteredExpenses]);

  // All time branch expenses for real cash-in-hand calculation
  const branchAllExpenses = useMemo(() => {
    return pettyCashExpenses
      .filter(
        (e) =>
          branchFilter === 'all' ||
          e.canteenId === branchFilter ||
          isCanteenMatch(e, branchFilter, canteens)
      )
      .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  }, [pettyCashExpenses, branchFilter, canteens]);

  const branchAllFunds = useMemo(() => {
    return pettyCashFunds
      .filter(
        (f) =>
          branchFilter === 'all' ||
          f.canteenId === branchFilter ||
          isCanteenMatch(f, branchFilter, canteens)
      )
      .reduce((sum, f) => sum + (Number(f.amount) || 0), 0);
  }, [pettyCashFunds, branchFilter, canteens]);

  const cashInHandBalance = branchAllFunds - branchAllExpenses;

  const todayExpenses = useMemo(() => {
    return pettyCashExpenses
      .filter(
        (e) =>
          (branchFilter === 'all' ||
            e.canteenId === branchFilter ||
            isCanteenMatch(e, branchFilter, canteens)) &&
          e.date === todayStr
      )
      .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  }, [pettyCashExpenses, branchFilter, todayStr, canteens]);

  // Open Add Modal
  const handleOpenAddExpense = () => {
    setEditingExpense(null);
    setExpenseFormError('');
    setExpenseForm({
      date: todayStr,
      canteenId: branchFilter !== 'all' ? branchFilter : canteens[0]?.id || 'cant-sadaqat',
      category: 'Chai & Refreshment',
      itemTitle: '',
      amount: '',
      paidTo: '',
      paidBy: '',
      voucherNo: '',
      remarks: '',
    });
    setIsAddExpenseModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEditExpense = (exp: PettyCashExpense) => {
    setEditingExpense(exp);
    setExpenseFormError('');
    setExpenseForm({
      date: exp.date,
      canteenId: exp.canteenId,
      category: (exp.category as PettyExpenseCategory) || 'Other Misc',
      itemTitle: exp.itemTitle,
      amount: exp.amount.toString(),
      paidTo: exp.paidTo || '',
      paidBy: exp.paidBy || '',
      voucherNo: exp.voucherNo || '',
      remarks: exp.remarks || '',
    });
    setIsAddExpenseModalOpen(true);
  };

  // Submit Expense (Add or Edit)
  const handleSubmitExpense = (e: React.FormEvent) => {
    e.preventDefault();

    if (!expenseForm.itemTitle.trim()) {
      setExpenseFormError('Please enter the expense purpose or item name.');
      return;
    }

    const numAmount = parseFloat(expenseForm.amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setExpenseFormError('Please enter a valid positive expense amount.');
      return;
    }

    setExpenseFormError('');
    const canteenObj = canteens.find((c) => c.id === expenseForm.canteenId);
    const canteenName = canteenObj ? canteenObj.name : 'Branch';

    if (editingExpense) {
      onEditExpense(editingExpense.id, {
        date: expenseForm.date,
        canteenId: expenseForm.canteenId,
        canteenName,
        category: expenseForm.category,
        itemTitle: expenseForm.itemTitle.trim(),
        amount: numAmount,
        paidTo: expenseForm.paidTo.trim() || undefined,
        paidBy: expenseForm.paidBy.trim() || undefined,
        voucherNo: expenseForm.voucherNo.trim() || undefined,
        remarks: expenseForm.remarks.trim() || undefined,
      });
    } else {
      onAddExpense({
        date: expenseForm.date,
        canteenId: expenseForm.canteenId,
        canteenName,
        category: expenseForm.category,
        itemTitle: expenseForm.itemTitle.trim(),
        amount: numAmount,
        paidTo: expenseForm.paidTo.trim() || undefined,
        paidBy: expenseForm.paidBy.trim() || undefined,
        voucherNo: expenseForm.voucherNo.trim() || undefined,
        remarks: expenseForm.remarks.trim() || undefined,
      });
    }

    setIsAddExpenseModalOpen(false);
    setEditingExpense(null);
  };

  // Open Add Fund Modal
  const handleOpenAddFund = () => {
    setFundFormError('');
    setFundForm({
      date: todayStr,
      canteenId: branchFilter !== 'all' ? branchFilter : canteens[0]?.id || 'cant-sadaqat',
      amount: '',
      source: 'Branch Cash Float',
      receivedBy: '',
      notes: '',
    });
    setIsAddFundModalOpen(true);
  };

  // Submit Fund
  const handleSubmitFund = (e: React.FormEvent) => {
    e.preventDefault();

    const numAmount = parseFloat(fundForm.amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setFundFormError('Please enter a valid cash float amount.');
      return;
    }

    setFundFormError('');
    const canteenObj = canteens.find((c) => c.id === fundForm.canteenId);
    const canteenName = canteenObj ? canteenObj.name : 'Branch';

    onAddFund({
      date: fundForm.date,
      canteenId: fundForm.canteenId,
      canteenName,
      amount: numAmount,
      source: fundForm.source.trim() || 'Petty Cash Top-up',
      receivedBy: fundForm.receivedBy.trim() || undefined,
      notes: fundForm.notes.trim() || undefined,
    });

    setIsAddFundModalOpen(false);
  };

  // Export to Excel
  const handleExportExcel = () => {
    const exportData = filteredExpenses.map((e, idx) => ({
      'Sr #': idx + 1,
      'Date': e.date,
      'Branch': e.canteenName,
      'Category': e.category,
      'Item / Purpose': e.itemTitle,
      'Amount': e.amount,
      'Paid To': e.paidTo || '-',
      'Paid By': e.paidBy || '-',
      'Remarks': e.remarks || '-',
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Petty Cash');
    XLSX.writeFile(wb, `Petty_Cash_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  return (
    <div className="space-y-5 pb-16">
      {/* 1. Header & Primary Actions */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/10 text-amber-700">
              <Coins className="w-5 h-5" />
            </span>
            <div>
              <h1 className="text-xl font-bold text-slate-900">Daily Petty Cash Register</h1>
              <p className="text-xs text-slate-500">
                Track day-wise minor expenses separately from regular counter sales
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleOpenAddExpense}
            className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Record Expense</span>
          </button>

          <button
            onClick={handleOpenAddFund}
            className="inline-flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs px-4 py-2.5 rounded-xl shadow-xs transition cursor-pointer"
          >
            <Wallet className="w-4 h-4 text-amber-400" />
            <span>Add Float / Cash In</span>
          </button>

          <button
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs px-3.5 py-2.5 rounded-xl transition cursor-pointer"
            title="Download Excel"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Excel</span>
          </button>
        </div>
      </div>

      {/* 2. Key Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Cash in Hand (Balance)
          </span>
          <p
            className={`text-2xl font-black mt-1 ${
              cashInHandBalance >= 0 ? 'text-emerald-700' : 'text-rose-700'
            }`}
          >
            {formatCurrency(cashInHandBalance, currencySymbol)}
          </p>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Float minus total expenses</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Today's Petty Cash
          </span>
          <p className="text-2xl font-black text-slate-900 mt-1">
            {formatCurrency(todayExpenses, currencySymbol)}
          </p>
          <span className="text-[10px] text-slate-400 mt-0.5 block">Spent today</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Filtered Expenses
          </span>
          <p className="text-2xl font-black text-rose-600 mt-1">
            {formatCurrency(totalExpenses, currencySymbol)}
          </p>
          <span className="text-[10px] text-slate-400 mt-0.5 block">
            {filteredExpenses.length} entries in view
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Float Received
          </span>
          <p className="text-2xl font-black text-indigo-700 mt-1">
            {formatCurrency(totalFunds, currencySymbol)}
          </p>
          <span className="text-[10px] text-slate-400 mt-0.5 block">
            {filteredFunds.length} top-up records
          </span>
        </div>
      </div>

      {/* 3. Navigation Tabs (Expenses vs Float) */}
      <div className="flex border-b border-slate-200 gap-6 text-sm font-semibold">
        <button
          onClick={() => setActiveTab('expenses')}
          className={`pb-3 border-b-2 transition cursor-pointer flex items-center gap-2 ${
            activeTab === 'expenses'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>Daily Expenses ({filteredExpenses.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('funds')}
          className={`pb-3 border-b-2 transition cursor-pointer flex items-center gap-2 ${
            activeTab === 'funds'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>Float Received / Top-ups ({filteredFunds.length})</span>
        </button>
      </div>

      {/* 4. Controls: Branch, Date, Search & Category Filter */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs space-y-3">
        <div className="flex flex-wrap items-center gap-3">
          {/* Branch Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-600 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-slate-500" />
              Branch:
            </span>
            <select
              value={branchFilter}
              onChange={(e) => setBranchFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-800 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            >
              <option value="all">All Branches</option>
              {canteens.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Date Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-600 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-500" />
              Period:
            </span>
            <select
              value={dateFilter}
              onChange={(e) =>
                setDateFilter(e.target.value as 'all' | 'today' | 'yesterday' | 'this_week' | 'this_month' | 'custom')
              }
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-800 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            >
              <option value="today">Today</option>
              <option value="yesterday">Yesterday</option>
              <option value="this_week">This Week</option>
              <option value="this_month">This Month</option>
              <option value="all">All Time</option>
              <option value="custom">Custom Date Range</option>
            </select>
          </div>

          {/* Custom Date Inputs */}
          {dateFilter === 'custom' && (
            <div className="flex items-center gap-2 text-xs">
              <input
                type="date"
                value={customStartDate}
                onChange={(e) => setCustomStartDate(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1 text-xs text-slate-800"
              />
              <span className="text-slate-400">to</span>
              <input
                type="date"
                value={customEndDate}
                onChange={(e) => setCustomEndDate(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1 text-xs text-slate-800"
              />
            </div>
          )}

          {/* Category Filter */}
          {activeTab === 'expenses' && (
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-600">Category:</span>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-800 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              >
                <option value="all">All Categories</option>
                {CATEGORIES.map((cat) => (
                  <option key={cat.label} value={cat.label}>
                    {cat.icon} {cat.label}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Search Box */}
          <div className="flex-1 min-w-[200px] relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search expenses, vendor, paid to..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            />
          </div>
        </div>
      </div>

      {/* 5. TAB CONTENT: Expenses Table */}
      {activeTab === 'expenses' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold text-[11px] uppercase tracking-wider">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Branch</th>
                  <th className="py-3 px-4">Expense Description / Purpose</th>
                  <th className="py-3 px-3">Category</th>
                  <th className="py-3 px-3">Paid To</th>
                  <th className="py-3 px-3">Paid By</th>
                  <th className="py-3 px-4 text-right">Amount</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredExpenses.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400 text-xs">
                      No petty cash expenses found for the selected filter.
                    </td>
                  </tr>
                ) : (
                  filteredExpenses.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-3 px-4 text-slate-700 whitespace-nowrap font-medium">
                        {formatDisplayDate(item.date)}
                      </td>
                      <td className="py-3 px-4 text-slate-800 font-medium whitespace-nowrap">
                        {item.canteenName}
                      </td>
                      <td className="py-3 px-4 max-w-sm">
                        <p className="font-semibold text-slate-900 leading-snug">{item.itemTitle}</p>
                        {item.remarks && (
                          <p className="text-[11px] text-slate-400 italic mt-0.5">{item.remarks}</p>
                        )}
                      </td>
                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                          {item.category}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-600 whitespace-nowrap">
                        {item.paidTo || '-'}
                      </td>
                      <td className="py-3 px-3 text-slate-600 whitespace-nowrap">
                        {item.paidBy || '-'}
                      </td>
                      <td className="py-3 px-4 text-right font-extrabold text-slate-900 text-sm whitespace-nowrap">
                        {formatCurrency(item.amount, currencySymbol)}
                      </td>
                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        {deleteConfirmExpenseId === item.id ? (
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => {
                                onDeleteExpense(item.id);
                                setDeleteConfirmExpenseId(null);
                              }}
                              className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] rounded transition cursor-pointer shadow-xs"
                            >
                              Delete
                            </button>
                            <button
                              onClick={() => setDeleteConfirmExpenseId(null)}
                              className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] rounded transition cursor-pointer"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleOpenEditExpense(item)}
                              className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition cursor-pointer"
                              title="Edit expense"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setDeleteConfirmExpenseId(item.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                              title="Delete expense"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              {filteredExpenses.length > 0 && (
                <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                  <tr>
                    <td colSpan={6} className="py-3 px-4 text-slate-700 text-xs">
                      Total ({filteredExpenses.length} Records)
                    </td>
                    <td className="py-3 px-4 text-right text-rose-600 text-sm font-black">
                      {formatCurrency(totalExpenses, currencySymbol)}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      )}

      {/* 6. TAB CONTENT: Funds / Float Received Table */}
      {activeTab === 'funds' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold text-[11px] uppercase tracking-wider">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Branch</th>
                  <th className="py-3 px-4">Source / Fund Description</th>
                  <th className="py-3 px-4">Received By</th>
                  <th className="py-3 px-4">Notes</th>
                  <th className="py-3 px-4 text-right">Amount Received</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredFunds.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400 text-xs">
                      No cash float or top-up entries found.
                    </td>
                  </tr>
                ) : (
                  filteredFunds.map((fund) => (
                    <tr key={fund.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-3 px-4 text-slate-700 font-medium whitespace-nowrap">
                        {formatDisplayDate(fund.date)}
                      </td>
                      <td className="py-3 px-4 text-slate-800 font-medium whitespace-nowrap">
                        {fund.canteenName}
                      </td>
                      <td className="py-3 px-4 font-bold text-slate-900">{fund.source}</td>
                      <td className="py-3 px-4 text-slate-600">{fund.receivedBy || '-'}</td>
                      <td className="py-3 px-4 text-slate-500 italic">{fund.notes || '-'}</td>
                      <td className="py-3 px-4 text-right font-black text-emerald-700 text-sm whitespace-nowrap">
                        +{formatCurrency(fund.amount, currencySymbol)}
                      </td>
                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        {deleteConfirmFundId === fund.id ? (
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => {
                                onDeleteFund(fund.id);
                                setDeleteConfirmFundId(null);
                              }}
                              className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] rounded transition cursor-pointer shadow-xs"
                            >
                              Delete
                            </button>
                            <button
                              onClick={() => setDeleteConfirmFundId(null)}
                              className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] rounded transition cursor-pointer"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirmFundId(fund.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                            title="Delete float entry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              {filteredFunds.length > 0 && (
                <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                  <tr>
                    <td colSpan={5} className="py-3 px-4 text-slate-700 text-xs">
                      Total Float Received ({filteredFunds.length} Entries)
                    </td>
                    <td className="py-3 px-4 text-right text-emerald-700 text-sm font-black">
                      +{formatCurrency(totalFunds, currencySymbol)}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      )}

      {/* 7. MODAL: Add / Edit Expense */}
      {isAddExpenseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
                  {editingExpense ? <Edit2 className="w-5 h-5" /> : <PlusCircle className="w-5 h-5" />}
                </span>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {editingExpense ? 'Edit Petty Cash Expense' : 'Record Petty Cash Expense'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {editingExpense
                      ? 'Update this minor operational cash expense'
                      : 'Record minor day-to-day cash expenses paid from float'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsAddExpenseModalOpen(false);
                  setEditingExpense(null);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {expenseFormError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
                {expenseFormError}
              </div>
            )}

            <form onSubmit={handleSubmitExpense} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={expenseForm.date}
                    onChange={(e) => setExpenseForm({ ...expenseForm, date: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Branch / Canteen *
                  </label>
                  <select
                    value={expenseForm.canteenId}
                    onChange={(e) => setExpenseForm({ ...expenseForm, canteenId: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none cursor-pointer"
                  >
                    {canteens.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Category *</label>
                <select
                  value={expenseForm.category}
                  onChange={(e) =>
                    setExpenseForm({
                      ...expenseForm,
                      category: e.target.value as PettyExpenseCategory,
                    })
                  }
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none cursor-pointer"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat.label} value={cat.label}>
                      {cat.icon} {cat.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Expense Purpose / Item *
                </label>
                <input
                  type="text"
                  required
                  value={expenseForm.itemTitle}
                  onChange={(e) => setExpenseForm({ ...expenseForm, itemTitle: e.target.value })}
                  placeholder="e.g. Chai for guests, surf & wiper, rickshaw fare, light bulb"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Amount ({currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={expenseForm.amount}
                    onChange={(e) => setExpenseForm({ ...expenseForm, amount: e.target.value })}
                    placeholder="e.g. 350"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Paid To (Vendor)</label>
                  <input
                    type="text"
                    value={expenseForm.paidTo}
                    onChange={(e) => setExpenseForm({ ...expenseForm, paidTo: e.target.value })}
                    placeholder="e.g. Tea stall, General store"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Paid By (Staff)</label>
                  <input
                    type="text"
                    value={expenseForm.paidBy}
                    onChange={(e) => setExpenseForm({ ...expenseForm, paidBy: e.target.value })}
                    placeholder="e.g. Cashier, Manager"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Remarks (Optional)</label>
                  <input
                    type="text"
                    value={expenseForm.remarks}
                    onChange={(e) => setExpenseForm({ ...expenseForm, remarks: e.target.value })}
                    placeholder="Additional note"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2.5 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddExpenseModalOpen(false);
                    setEditingExpense(null);
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-xs cursor-pointer transition"
                >
                  {editingExpense ? 'Update Expense' : 'Save Expense'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 8. MODAL: Add Float / Cash In */}
      {isAddFundModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-amber-50 text-amber-700">
                  <Wallet className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Add Cash Float / Top-up</h3>
                  <p className="text-xs text-slate-500">Record cash given to the petty cash float</p>
                </div>
              </div>
              <button
                onClick={() => setIsAddFundModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {fundFormError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
                {fundFormError}
              </div>
            )}

            <form onSubmit={handleSubmitFund} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Date *</label>
                <input
                  type="date"
                  required
                  value={fundForm.date}
                  onChange={(e) => setFundForm({ ...fundForm, date: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Branch / Canteen *</label>
                <select
                  value={fundForm.canteenId}
                  onChange={(e) => setFundForm({ ...fundForm, canteenId: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none cursor-pointer"
                >
                  {canteens.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Cash Float Amount ({currencySymbol}) *
                </label>
                <input
                  type="number"
                  min="1"
                  step="any"
                  required
                  value={fundForm.amount}
                  onChange={(e) => setFundForm({ ...fundForm, amount: e.target.value })}
                  placeholder="e.g. 5000"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Source / Description
                </label>
                <input
                  type="text"
                  value={fundForm.source}
                  onChange={(e) => setFundForm({ ...fundForm, source: e.target.value })}
                  placeholder="e.g. Branch Cash Float, Cash Top-up"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Received By</label>
                <input
                  type="text"
                  value={fundForm.receivedBy}
                  onChange={(e) => setFundForm({ ...fundForm, receivedBy: e.target.value })}
                  placeholder="e.g. Cashier Kashif, Manager"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Notes (Optional)</label>
                <input
                  type="text"
                  value={fundForm.notes}
                  onChange={(e) => setFundForm({ ...fundForm, notes: e.target.value })}
                  placeholder="e.g. Weekly replenishment from main counter"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-emerald-500/20 focus:outline-none"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2.5 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddFundModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-xs cursor-pointer transition"
                >
                  Add Float
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

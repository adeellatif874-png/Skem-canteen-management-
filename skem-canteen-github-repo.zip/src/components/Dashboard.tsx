import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  Upload,
  Receipt,
  PiggyBank,
  Wallet,
  Landmark,
  Building2,
  Calendar,
  PlusCircle,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Users,
  Percent,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  BarChart3,
  PieChart,
  ShieldCheck,
  CreditCard,
  Ticket,
  Store,
  ChevronRight,
  Activity,
  Layers,
  ShoppingBag,
  Clock,
  X,
} from 'lucide-react';
import {
  AppState,
  DateFilterType,
  DailyEntry,
  CanteenCashDeposit,
} from '../types';
import { formatCurrency, isCanteenMatch, formatDisplayDate } from '../lib/storage';

interface DashboardProps {
  state: AppState;
  selectedCanteenId: string;
  setSelectedCanteenId: (id: string) => void;
  onNavigate: (tab: any) => void;
  onQuickAddEntry: () => void;
  onAddCashDeposit?: (deposit: Omit<CanteenCashDeposit, 'id' | 'createdAt'>) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  state,
  selectedCanteenId,
  setSelectedCanteenId,
  onNavigate,
  onQuickAddEntry,
  onAddCashDeposit,
  onRestoreBackup,
}) => {
  const [dateFilter, setDateFilter] = useState<DateFilterType>('all_time');
  const [customStartDate, setCustomStartDate] = useState<string>(
    new Date(new Date().setDate(new Date().getDate() - 30))
      .toISOString()
      .split('T')[0]
  );
  const [customEndDate, setCustomEndDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  // Quick Deposit modal state
  const [depositModalOpen, setDepositModalOpen] = useState(false);
  const [depositAmount, setDepositAmount] = useState('');
  const [depositTo, setDepositTo] = useState('Bank Account');
  const [bankName, setBankName] = useState('');
  const [slipNumber, setSlipNumber] = useState('');
  const [depositDate, setDepositDate] = useState(new Date().toISOString().split('T')[0]);
  const [depositCanteenId, setDepositCanteenId] = useState(
    selectedCanteenId !== 'all' ? selectedCanteenId : state.canteens[0]?.id || ''
  );
  const [depositRemarks, setDepositRemarks] = useState('');

  // Active chart metric view: 'revenue' | 'net'
  const [chartView, setChartView] = useState<'revenue' | 'net'>('revenue');
  const [hoveredPointIndex, setHoveredPointIndex] = useState<number | null>(null);

  const activeCanteens = useMemo(
    () => (state.canteens || []).filter((c) => c.status === 'active'),
    [state.canteens]
  );

  const currency = state.currencySymbol || 'Rs.';

  // Helper date boundary matcher
  const isDateInFilter = (dateStr: string) => {
    if (!dateStr) return false;
    const d = new Date(dateStr + 'T00:00:00');
    if (isNaN(d.getTime())) return false;
    const now = new Date();
    now.setHours(0, 0, 0, 0);

    if (dateFilter === 'today') {
      const todayStr = new Date().toISOString().split('T')[0];
      return dateStr === todayStr;
    } else if (dateFilter === 'yesterday') {
      const y = new Date();
      y.setDate(y.getDate() - 1);
      const yStr = y.toISOString().split('T')[0];
      return dateStr === yStr;
    } else if (dateFilter === 'this_week') {
      const startOfWeek = new Date(now);
      const day = now.getDay();
      const diff = now.getDate() - day + (day === 0 ? -6 : 1);
      startOfWeek.setDate(diff);
      return d >= startOfWeek;
    } else if (dateFilter === 'this_month') {
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
      return d >= firstDay;
    } else if (dateFilter === 'last_month') {
      const firstDayLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const lastDayLastMonth = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59);
      return d >= firstDayLastMonth && d <= lastDayLastMonth;
    } else if (dateFilter === 'custom') {
      if (!customStartDate || !customEndDate) return true;
      const start = new Date(customStartDate + 'T00:00:00');
      const end = new Date(customEndDate + 'T23:59:59');
      return d >= start && d <= end;
    }
    return true;
  };

  // Filtered Daily Entries
  const filteredEntries = useMemo(() => {
    return (state.dailyEntries || []).filter((entry) => {
      const matchesCanteen = isCanteenMatch(entry, selectedCanteenId, state.canteens);
      const matchesDate = isDateInFilter(entry.date);
      return matchesCanteen && matchesDate;
    });
  }, [state.dailyEntries, selectedCanteenId, state.canteens, dateFilter, customStartDate, customEndDate]);

  // Filtered Cash Deposits
  const filteredDeposits = useMemo(() => {
    return (state.canteenCashDeposits || []).filter((d) => {
      const matchCanteen = isCanteenMatch(d, selectedCanteenId, state.canteens);
      const matchDate = isDateInFilter(d.date);
      return matchCanteen && matchDate;
    });
  }, [state.canteenCashDeposits, selectedCanteenId, state.canteens, dateFilter, customStartDate, customEndDate]);

  // Financial Aggregates
  const metrics = useMemo(() => {
    let normalSale = 0;
    let tokenSale = 0;
    let purchase = 0;
    let expenses = 0;

    filteredEntries.forEach((e) => {
      normalSale += Number(e.normalSale) || 0;
      tokenSale += Number(e.tokenSale) || 0;
      purchase += Number(e.purchase) || 0;
      expenses += Number(e.expenses) || 0;
    });

    const totalSale = normalSale + tokenSale;
    const totalOutflows = purchase + expenses;
    const baqiCashSale = normalSale - totalOutflows;
    const netProfit = totalSale - totalOutflows;
    const profitMargin = totalSale > 0 ? (netProfit / totalSale) * 100 : 0;

    const totalDeposits = filteredDeposits.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);
    const cashInHand = baqiCashSale - totalDeposits;

    const expenseRatio = totalSale > 0 ? (totalOutflows / totalSale) * 100 : 0;
    const depositRate = baqiCashSale > 0 ? (totalDeposits / baqiCashSale) * 100 : 0;

    return {
      normalSale,
      tokenSale,
      totalSale,
      purchase,
      expenses,
      totalOutflows,
      baqiCashSale,
      netProfit,
      profitMargin,
      totalDeposits,
      cashInHand,
      depositCount: filteredDeposits.length,
      expenseRatio,
      depositRate,
      entryCount: filteredEntries.length,
    };
  }, [filteredEntries, filteredDeposits]);

  // Branch Performance Summaries
  const branchSummaries = useMemo(() => {
    const map: Record<
      string,
      {
        id: string;
        name: string;
        normalSale: number;
        tokenSale: number;
        totalSale: number;
        expenses: number;
        purchase: number;
        baqiCashSale: number;
        deposited: number;
        cashInHand: number;
        entriesCount: number;
        shareOfNetwork: number;
      }
    > = {};

    activeCanteens.forEach((c) => {
      map[c.id] = {
        id: c.id,
        name: c.name,
        normalSale: 0,
        tokenSale: 0,
        totalSale: 0,
        expenses: 0,
        purchase: 0,
        baqiCashSale: 0,
        deposited: 0,
        cashInHand: 0,
        entriesCount: 0,
        shareOfNetwork: 0,
      };
    });

    filteredEntries.forEach((e) => {
      if (map[e.canteenId]) {
        map[e.canteenId].normalSale += Number(e.normalSale) || 0;
        map[e.canteenId].tokenSale += Number(e.tokenSale) || 0;
        map[e.canteenId].totalSale += Number(e.totalSale) || 0;
        map[e.canteenId].expenses += Number(e.expenses) || 0;
        map[e.canteenId].purchase += Number(e.purchase) || 0;
        map[e.canteenId].entriesCount += 1;
      }
    });

    filteredDeposits.forEach((d) => {
      if (map[d.canteenId]) {
        map[d.canteenId].deposited += Number(d.amount) || 0;
      }
    });

    const totalNetworkSales = Object.values(map).reduce((sum, b) => sum + b.totalSale, 0);

    Object.values(map).forEach((b) => {
      b.baqiCashSale = b.normalSale - (b.expenses + b.purchase);
      b.cashInHand = b.baqiCashSale - b.deposited;
      b.shareOfNetwork = totalNetworkSales > 0 ? (b.totalSale / totalNetworkSales) * 100 : 0;
    });

    return Object.values(map).sort((a, b) => b.totalSale - a.totalSale);
  }, [activeCanteens, filteredEntries, filteredDeposits]);

  // Daily Timeline Aggregation for the SVG Trend Visualizer (last 10 unique active days)
  const timelinePoints = useMemo(() => {
    const dayMap: Record<string, { date: string; cashSale: number; tokenSale: number; expenses: number; netCash: number }> = {};

    filteredEntries.forEach((e) => {
      if (!dayMap[e.date]) {
        dayMap[e.date] = { date: e.date, cashSale: 0, tokenSale: 0, expenses: 0, netCash: 0 };
      }
      dayMap[e.date].cashSale += Number(e.normalSale) || 0;
      dayMap[e.date].tokenSale += Number(e.tokenSale) || 0;
      dayMap[e.date].expenses += (Number(e.expenses) || 0) + (Number(e.purchase) || 0);
      dayMap[e.date].netCash += (Number(e.normalSale) || 0) - ((Number(e.expenses) || 0) + (Number(e.purchase) || 0));
    });

    // Sort ascending by date
    const sorted = Object.values(dayMap).sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    // Pick at most the last 12 active dates for clean visual presentation
    return sorted.slice(-12);
  }, [filteredEntries]);

  // SVG Chart Dimensions & Computations
  const chartMaxVal = useMemo(() => {
    if (timelinePoints.length === 0) return 1000;
    const max = Math.max(
      ...timelinePoints.map((p) => Math.max(p.cashSale, p.expenses, Math.abs(p.netCash)))
    );
    return max > 0 ? max * 1.15 : 1000;
  }, [timelinePoints]);

  // Sadaqat Canteen Labour Token System status
  const currentMonthStr = new Date().toISOString().slice(0, 7);
  const labourStatus = useMemo(() => {
    const workers = (state.labourWorkers || []).filter(
      (w) => selectedCanteenId === 'all' || w.canteenId === selectedCanteenId
    );
    const issues = (state.labourTokenIssues || []).filter(
      (i) => (selectedCanteenId === 'all' || i.canteenId === selectedCanteenId) && i.month === currentMonthStr
    );
    const payments = (state.labourTokenPayments || []).filter(
      (p) => (selectedCanteenId === 'all' || p.canteenId === selectedCanteenId) && p.month === currentMonthStr
    );

    const totalTokensIssued = issues.reduce((sum, i) => sum + (Number(i.tokenQty) || 0), 0);
    const totalTokenValue = issues.reduce((sum, i) => sum + (Number(i.totalAmount) || 0), 0);
    const totalCashCollected = payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const pendingBalance = totalTokenValue - totalCashCollected;

    return {
      workerCount: workers.length,
      totalTokensIssued,
      totalCashCollected,
      pendingBalance,
    };
  }, [state.labourWorkers, state.labourTokenIssues, state.labourTokenPayments, selectedCanteenId, currentMonthStr]);

  // Combined Recent Activity Stream (Entries & Deposits interleaved chronologically)
  const recentActivities = useMemo(() => {
    const list: Array<{
      id: string;
      date: string;
      branch: string;
      type: 'sale' | 'expense' | 'deposit';
      title: string;
      amount: number;
      subtitle: string;
    }> = [];

    // Add entries
    filteredEntries.forEach((e) => {
      const grossSale = (Number(e.normalSale) || 0) + (Number(e.tokenSale) || 0);
      const totalExp = (Number(e.expenses) || 0) + (Number(e.purchase) || 0);

      if (grossSale > 0) {
        list.push({
          id: `sale-${e.id}`,
          date: e.date,
          branch: e.canteenName || 'Branch',
          type: 'sale',
          title: `Cash Sale Recorded`,
          amount: e.normalSale,
          subtitle: e.tokenSale > 0 ? `+ ${formatCurrency(e.tokenSale, currency)} Tokens` : 'Counter cash collection',
        });
      }

      if (totalExp > 0) {
        list.push({
          id: `exp-${e.id}`,
          date: e.date,
          branch: e.canteenName || 'Branch',
          type: 'expense',
          title: `Operating Expense & Stock`,
          amount: totalExp,
          subtitle: e.expenseNote || e.remarks || 'Daily outflow',
        });
      }
    });

    // Add deposits
    filteredDeposits.forEach((d) => {
      list.push({
        id: `dep-${d.id}`,
        date: d.date,
        branch: d.canteenName || 'Branch',
        type: 'deposit',
        title: `Bank / HQ Deposit`,
        amount: d.amount,
        subtitle: `${d.depositTo || 'Bank'} ${d.bankName ? `• ${d.bankName}` : ''}`,
      });
    });

    // Sort newest first
    list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return list.slice(0, 8);
  }, [filteredEntries, filteredDeposits, currency]);

  // Quick Deposit Submit
  const handleQuickDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(depositAmount);
    if (isNaN(num) || num <= 0) return;

    const canteen = state.canteens.find((c) => c.id === depositCanteenId);
    const canteenName = canteen ? canteen.name : 'Branch';

    if (onAddCashDeposit) {
      onAddCashDeposit({
        date: depositDate,
        canteenId: depositCanteenId,
        canteenName,
        amount: num,
        depositTo,
        bankName: bankName.trim() || undefined,
        slipNumber: slipNumber.trim() || undefined,
        remarks: depositRemarks.trim() || undefined,
      });
    }

    setDepositModalOpen(false);
    setDepositAmount('');
    setBankName('');
    setSlipNumber('');
    setDepositRemarks('');
  };

  const selectedCanteenObj = activeCanteens.find((c) => c.id === selectedCanteenId);

  return (
    <div className="space-y-6 pb-16 max-w-7xl mx-auto">
      {/* Restore Banner if not full dataset */}
      {(state.dailyEntries || []).length < 200 && (
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 rounded-2xl p-4 text-slate-950 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg border border-amber-400">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/30 flex items-center justify-center shrink-0 font-bold text-lg">
              📁
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-950">Old Vercel App Ka Pura Data (304 Records) Restore Karein</h3>
              <p className="text-xs font-semibold text-slate-900/80">
                Jo backup file (.json) aap ne Vercel se download ki hai, usay yahan 1 click mein upload karein taake tamam 304 din ka hisab load ho jaye.
              </p>
            </div>
          </div>
          <label className="bg-slate-950 hover:bg-slate-900 text-amber-300 font-black text-xs px-5 py-2.5 rounded-xl shadow-md cursor-pointer shrink-0 transition flex items-center gap-2">
            <Upload className="w-4 h-4" />
            <span>Select Backup File (.json)</span>
            <input
              type="file"
              accept=".json"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = (ev) => {
                  try {
                    const parsed = JSON.parse(ev.target?.result);
                    if (parsed && Array.isArray(parsed.dailyEntries)) {
                      onRestoreBackup && onRestoreBackup(parsed);
                      alert('Backup successfully restored! ' + parsed.dailyEntries.length + ' entries loaded.');
                    } else {
                      alert('Invalid backup JSON file.');
                    }
                  } catch (err) {
                    alert('Error parsing JSON.');
                  }
                };
                reader.readAsText(file);
              }}
              className="hidden"
            />
          </label>
        </div>
      )}
      {/* 1. EXECUTIVE COMMAND HEADER (SLATE-900 / GOLDEN AMBER HIGHLIGHTS) */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white p-6 sm:p-8 shadow-xl border border-slate-700/60">
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-16 w-60 h-60 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          {/* Left Block: Identity & Filter Pickers */}
          <div className="space-y-4 max-w-xl">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>Executive Command Center</span>
              </span>
              <span className="text-xs text-slate-400 font-medium">
                {activeCanteens.length} Active Canteen Branches
              </span>
            </div>

            <div>
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
                <span>{selectedCanteenId === 'all' ? 'Consolidated Business Pulse' : selectedCanteenObj?.name}</span>
              </h1>
              <p className="text-slate-400 text-xs sm:text-sm mt-1">
                Real-time liquidity, counter collections, operating expenses, and bank settlement tracking.
              </p>
            </div>

            {/* Branch and Timeframe Selectors */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              {/* Branch Selector Pill */}
              <div className="flex items-center gap-1.5 bg-slate-800/90 border border-slate-700/80 px-3 py-1.5 rounded-xl text-xs shadow-inner">
                <Store className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-slate-400 font-semibold">Branch:</span>
                <select
                  value={selectedCanteenId}
                  onChange={(e) => setSelectedCanteenId(e.target.value)}
                  className="bg-transparent text-white font-bold focus:outline-none cursor-pointer text-xs"
                >
                  <option value="all" className="bg-slate-800 text-white">
                    All Branches ({activeCanteens.length})
                  </option>
                  {activeCanteens.map((c) => (
                    <option key={c.id} value={c.id} className="bg-slate-800 text-white">
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Timeframe Buttons */}
              <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/80 overflow-x-auto text-xs">
                {[
                  { id: 'today', label: 'Today' },
                  { id: 'yesterday', label: 'Yesterday' },
                  { id: 'this_week', label: 'This Week' },
                  { id: 'this_month', label: 'This Month' },
                  { id: 'all_time', label: 'All Time' },
                  { id: 'custom', label: 'Custom' },
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setDateFilter(t.id as DateFilterType)}
                    className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer whitespace-nowrap text-[11px] ${
                      dateFilter === t.id
                        ? 'bg-emerald-500 text-slate-950 shadow-xs'
                        : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom range date inputs if selected */}
            {dateFilter === 'custom' && (
              <div className="flex items-center gap-2 bg-slate-800/60 border border-slate-700/80 p-2 rounded-xl text-xs">
                <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-slate-400">From:</span>
                <input
                  type="date"
                  value={customStartDate}
                  onChange={(e) => setCustomStartDate(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-0.5 text-white"
                />
                <span className="text-slate-400">To:</span>
                <input
                  type="date"
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-0.5 text-white"
                />
              </div>
            )}
          </div>

          {/* Right Block: Hero Cash in Hand Card & Direct Execution */}
          <div className="flex flex-col sm:flex-row lg:flex-col items-stretch lg:items-end justify-between gap-4 bg-slate-800/60 border border-slate-700/70 p-5 rounded-2xl backdrop-blur-md">
            <div className="lg:text-right">
              <span className="text-[11px] font-black uppercase tracking-wider text-amber-400 flex items-center lg:justify-end gap-1.5">
                <PiggyBank className="w-4 h-4 text-amber-400" />
                <span>Physical Cash in Hand</span>
              </span>
              <p
                className={`text-3xl sm:text-4xl font-black font-mono tracking-tight mt-1 ${
                  metrics.cashInHand >= 0 ? 'text-amber-300' : 'text-rose-400'
                }`}
              >
                {formatCurrency(metrics.cashInHand, currency)}
              </p>
              <span className="text-xs text-slate-400 block mt-0.5">
                Net Cash ({formatCurrency(metrics.baqiCashSale, currency)}) − Deposited (
                {formatCurrency(metrics.totalDeposits, currency)})
              </span>
            </div>

            {/* Fast Action Buttons */}
            <div className="flex items-center gap-2.5 pt-2 border-t border-slate-700/60 w-full justify-start sm:justify-end">
              <button
                onClick={() => {
                  setDepositCanteenId(
                    selectedCanteenId !== 'all' ? selectedCanteenId : activeCanteens[0]?.id || ''
                  );
                  setDepositModalOpen(true);
                }}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Landmark className="w-3.5 h-3.5" />
                <span>+ Bank Deposit</span>
              </button>

              <label className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 shadow-md cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                <span>Restore Backup (.json)</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = (ev) => {
                      try {
                        const parsed = JSON.parse(ev.target?.result);
                        if (parsed && Array.isArray(parsed.dailyEntries)) {
                          onRestoreBackup && onRestoreBackup(parsed);
                          alert('Backup successfully restored! ' + parsed.dailyEntries.length + ' entries loaded.');
                        } else {
                          alert('Invalid backup JSON structure.');
                        }
                      } catch (err) {
                        alert('Failed to parse JSON file.');
                      }
                    };
                    reader.readAsText(file);
                  }}
                  className="hidden"
                />
              </label>
              <button
                onClick={onQuickAddEntry}
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs px-4 py-2 rounded-xl transition flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <PlusCircle className="w-4 h-4" />
                <span>+ Daily Entry</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 2. THE 5 CORE FINANCIAL PILLARS (DISTINCT ARCHETYPES & RATIO PROGRESS) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Pillar 1: Counter Cash Collections */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs hover:border-emerald-300 transition-all flex flex-col justify-between group">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Cash Sales (Counter)
              </span>
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
                <Receipt className="w-5 h-5" />
              </div>
            </div>
            <p className="text-2xl font-black text-slate-900 font-mono tracking-tight mt-2">
              {formatCurrency(metrics.normalSale, currency)}
            </p>
            <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500 font-medium">
              <span>Gross Turnover:</span>
              <span className="font-bold text-slate-800">{formatCurrency(metrics.totalSale, currency)}</span>
            </div>
            {/* Progress bar of cash share */}
            <div className="w-full bg-slate-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                style={{
                  width: `${metrics.totalSale > 0 ? (metrics.normalSale / metrics.totalSale) * 100 : 0}%`,
                }}
              />
            </div>
          </div>
          <p className="text-[11px] text-emerald-700 font-bold mt-4 pt-2.5 border-t border-slate-100 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Counter Cash Collected</span>
          </p>
        </div>

        {/* Pillar 2: Operating Outflows (Expenses + Purchases) */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs hover:border-rose-300 transition-all flex flex-col justify-between group">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-rose-600">
                Expenses & Stock (−)
              </span>
              <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
                <ShoppingBag className="w-5 h-5" />
              </div>
            </div>
            <p className="text-2xl font-black text-rose-700 font-mono tracking-tight mt-2">
              −{formatCurrency(metrics.totalOutflows, currency)}
            </p>
            <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500 font-medium">
              <span>Expenses:</span>
              <span className="font-bold text-slate-800">{formatCurrency(metrics.expenses, currency)}</span>
            </div>
            <div className="mt-0.5 flex items-center justify-between text-[11px] text-slate-500 font-medium">
              <span>Stock Purchases:</span>
              <span className="font-bold text-slate-800">{formatCurrency(metrics.purchase, currency)}</span>
            </div>
          </div>
          <p className="text-[11px] text-rose-600 font-semibold mt-4 pt-2.5 border-t border-slate-100 truncate">
            {metrics.expenseRatio.toFixed(1)}% of total sales revenue
          </p>
        </div>

        {/* Pillar 3: Net Cash Balance */}
        <div className="bg-emerald-50/50 rounded-2xl p-5 border-2 border-emerald-500/40 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-wider text-emerald-950">
                Net Cash Balance (=)
              </span>
              <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
                <Wallet className="w-5 h-5" />
              </div>
            </div>
            <p className="text-2xl font-black text-emerald-950 font-mono tracking-tight mt-2">
              {formatCurrency(metrics.baqiCashSale, currency)}
            </p>
            <div className="mt-3 flex items-center justify-between text-[11px] text-emerald-900 font-medium">
              <span>Counter Cash Retention:</span>
              <span className="font-black text-emerald-800">
                {metrics.normalSale > 0
                  ? `${Math.max(0, (metrics.baqiCashSale / metrics.normalSale) * 100).toFixed(1)}%`
                  : '0%'}
              </span>
            </div>
            <div className="w-full bg-emerald-200/80 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div
                className="bg-emerald-600 h-full rounded-full"
                style={{
                  width: `${metrics.normalSale > 0 ? Math.min(100, Math.max(0, (metrics.baqiCashSale / metrics.normalSale) * 100)) : 0}%`,
                }}
              />
            </div>
          </div>
          <p className="text-[11px] text-emerald-900 font-bold mt-4 pt-2.5 border-t border-emerald-200/70">
            Cash Sales − Operational Costs
          </p>
        </div>

        {/* Pillar 4: Bank Deposits Remitted */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs hover:border-indigo-300 transition-all flex flex-col justify-between group">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-700">
                Bank Remittance (−)
              </span>
              <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
                <Landmark className="w-5 h-5" />
              </div>
            </div>
            <p className="text-2xl font-black text-indigo-950 font-mono tracking-tight mt-2">
              {formatCurrency(metrics.totalDeposits, currency)}
            </p>
            <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500 font-medium">
              <span>Deposits Count:</span>
              <span className="font-bold text-slate-800">{metrics.depositCount} Slips</span>
            </div>
            <div className="mt-0.5 flex items-center justify-between text-[11px] text-slate-500 font-medium">
              <span>Deposited Ratio:</span>
              <span className="font-bold text-indigo-700">{metrics.depositRate.toFixed(1)}%</span>
            </div>
          </div>
          <p className="text-[11px] text-indigo-700 font-semibold mt-4 pt-2.5 border-t border-slate-100 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Remitted to Bank / HQ</span>
          </p>
        </div>

        {/* Pillar 5: Token Khata (Monthly) */}
        <div className="bg-purple-50/50 rounded-2xl p-5 border border-purple-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-800">
                Monthly Tokens (Khata)
              </span>
              <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center font-bold">
                <Ticket className="w-5 h-5" />
              </div>
            </div>
            <p className="text-2xl font-black text-purple-950 font-mono tracking-tight mt-2">
              {formatCurrency(metrics.tokenSale, currency)}
            </p>
            <div className="mt-3 flex items-center justify-between text-[11px] text-purple-900 font-medium">
              <span>Gross Profit Margin:</span>
              <span className="font-black text-purple-900">{metrics.profitMargin.toFixed(1)}%</span>
            </div>
            <div className="w-full bg-purple-200/70 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div
                className="bg-purple-600 h-full rounded-full"
                style={{
                  width: `${metrics.totalSale > 0 ? (metrics.tokenSale / metrics.totalSale) * 100 : 0}%`,
                }}
              />
            </div>
          </div>
          <p className="text-[11px] text-purple-800 font-semibold mt-4 pt-2.5 border-t border-purple-200/60 truncate">
            Separate Khata • Clears monthly
          </p>
        </div>
      </div>

      {/* 3. VISUAL ANALYTICS HUB: DUAL-METRIC TIMELINE CHART & CASH DISTRIBUTION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive SVG Cash Flow & Revenue Trendline */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">
                  Financial Trajectory & Daily Movement
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Daily counter collections versus outflows over the active date range
              </p>
            </div>

            {/* View Mode Toggle & Legend */}
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-3 text-xs font-semibold">
                <span className="flex items-center gap-1 text-emerald-700">
                  <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500"></span>
                  <span>Cash Sales</span>
                </span>
                <span className="flex items-center gap-1 text-rose-600">
                  <span className="w-2.5 h-2.5 rounded-sm bg-rose-500"></span>
                  <span>Expenses</span>
                </span>
              </div>

              <div className="bg-slate-100 p-0.5 rounded-lg flex items-center text-xs">
                <button
                  onClick={() => setChartView('revenue')}
                  className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                    chartView === 'revenue' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
                  }`}
                >
                  Sales vs Outflow
                </button>
                <button
                  onClick={() => setChartView('net')}
                  className={`px-2.5 py-1 rounded-md font-bold transition cursor-pointer ${
                    chartView === 'net' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
                  }`}
                >
                  Net Balance
                </button>
              </div>
            </div>
          </div>

          {/* SVG Visualizer Area */}
          {timelinePoints.length === 0 ? (
            <div className="py-16 text-center border-2 border-dashed border-slate-100 rounded-2xl">
              <Activity className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="font-bold text-slate-700 text-sm">No Entry Points for Selected Timeframe</p>
              <p className="text-xs text-slate-400 mt-1">
                Record daily sales entries to view visual trendlines and revenue movements.
              </p>
            </div>
          ) : (
            <div className="relative">
              {/* Responsive SVG Bar/Line Chart */}
              <div className="h-64 w-full pt-4">
                <svg
                  viewBox="0 0 700 220"
                  className="w-full h-full overflow-visible select-none"
                  preserveAspectRatio="none"
                >
                  {/* Background Grid Lines */}
                  {[0, 0.25, 0.5, 0.75, 1].map((ratio, idx) => {
                    const y = 180 - ratio * 150;
                    return (
                      <g key={idx}>
                        <line
                          x1="40"
                          y1={y}
                          x2="680"
                          y2={y}
                          stroke="#f1f5f9"
                          strokeWidth="1"
                          strokeDasharray="3 3"
                        />
                        <text
                          x="35"
                          y={y + 4}
                          fill="#94a3b8"
                          fontSize="9"
                          textAnchor="end"
                          fontFamily="monospace"
                        >
                          {Math.round((chartMaxVal * ratio) / 1000)}k
                        </text>
                      </g>
                    );
                  })}

                  {/* Bars for Each Day */}
                  {timelinePoints.map((point, idx) => {
                    const step = 640 / timelinePoints.length;
                    const xCenter = 40 + idx * step + step / 2;
                    const barW = Math.min(22, step * 0.38);

                    const cashHeight = Math.max(2, (point.cashSale / chartMaxVal) * 150);
                    const expHeight = Math.max(2, (point.expenses / chartMaxVal) * 150);
                    const netHeight = Math.max(2, (Math.abs(point.netCash) / chartMaxVal) * 150);

                    const isHovered = hoveredPointIndex === idx;

                    return (
                      <g
                        key={point.date}
                        className="cursor-pointer transition-opacity"
                        onMouseEnter={() => setHoveredPointIndex(idx)}
                        onMouseLeave={() => setHoveredPointIndex(null)}
                      >
                        {/* Hover overlay pill behind the bar */}
                        {isHovered && (
                          <rect
                            x={xCenter - step * 0.45}
                            y="15"
                            width={step * 0.9}
                            height="185"
                            fill="#f8fafc"
                            rx="8"
                            opacity="0.9"
                          />
                        )}

                        {chartView === 'revenue' ? (
                          <>
                            {/* Cash Sale Bar */}
                            <rect
                              x={xCenter - barW - 1.5}
                              y={180 - cashHeight}
                              width={barW}
                              height={cashHeight}
                              fill={isHovered ? '#059669' : '#10b981'}
                              rx="3"
                            />
                            {/* Expense Bar */}
                            <rect
                              x={xCenter + 1.5}
                              y={180 - expHeight}
                              width={barW}
                              height={expHeight}
                              fill={isHovered ? '#e11d48' : '#f43f5e'}
                              rx="3"
                            />
                          </>
                        ) : (
                          /* Net Cash Balance Bar */
                          <rect
                            x={xCenter - barW}
                            y={180 - netHeight}
                            width={barW * 2}
                            height={netHeight}
                            fill={point.netCash >= 0 ? '#10b981' : '#f43f5e'}
                            rx="4"
                          />
                        )}

                        {/* Date Label on X Axis */}
                        <text
                          x={xCenter}
                          y="202"
                          fill={isHovered ? '#0f172a' : '#64748b'}
                          fontSize="9"
                          fontWeight={isHovered ? 'bold' : 'normal'}
                          textAnchor="middle"
                        >
                          {point.date.slice(5)}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>

              {/* Hover Inspection Tooltip */}
              {hoveredPointIndex !== null && timelinePoints[hoveredPointIndex] && (
                <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-4 py-2 rounded-xl text-xs shadow-xl border border-slate-700 flex items-center gap-4 z-20 pointer-events-none">
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">
                      Date: {formatDisplayDate(timelinePoints[hoveredPointIndex].date)}
                    </span>
                    <span className="font-extrabold text-emerald-400">
                      Cash Sale: {formatCurrency(timelinePoints[hoveredPointIndex].cashSale, currency)}
                    </span>
                  </div>
                  <div className="border-l border-slate-700 pl-3">
                    <span className="text-[10px] text-rose-400 block font-bold">
                      Expenses: {formatCurrency(timelinePoints[hoveredPointIndex].expenses, currency)}
                    </span>
                    <span className="text-[10px] text-amber-300 block font-bold">
                      Net: {formatCurrency(timelinePoints[hoveredPointIndex].netCash, currency)}
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right 1 Col: Cash Distribution & Efficiency Breakdown */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <PieChart className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-base">Capital Allocation</h3>
              </div>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                {metrics.profitMargin.toFixed(1)}% Margin
              </span>
            </div>

            <p className="text-xs text-slate-500 mt-2">
              Proportional breakdown of where canteen revenues were retained or consumed.
            </p>

            {/* Visual Distribution Progress Meters */}
            <div className="space-y-3.5 mt-5">
              {/* Counter Cash Retention */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-slate-700">Net Cash Retained</span>
                  <span className="text-emerald-700 font-mono">
                    {formatCurrency(metrics.baqiCashSale, currency)}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${
                        metrics.normalSale > 0
                          ? Math.min(100, Math.max(0, (metrics.baqiCashSale / metrics.normalSale) * 100))
                          : 0
                      }%`,
                    }}
                  />
                </div>
              </div>

              {/* Operating Expenses */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-slate-700">Daily Running Expenses</span>
                  <span className="text-rose-700 font-mono">
                    {formatCurrency(metrics.expenses, currency)}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-rose-500 h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${
                        metrics.totalSale > 0 ? (metrics.expenses / metrics.totalSale) * 100 : 0
                      }%`,
                    }}
                  />
                </div>
              </div>

              {/* Stock Purchases */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-slate-700">Raw Materials & Stock</span>
                  <span className="text-amber-700 font-mono">
                    {formatCurrency(metrics.purchase, currency)}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-500 h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${
                        metrics.totalSale > 0 ? (metrics.purchase / metrics.totalSale) * 100 : 0
                      }%`,
                    }}
                  />
                </div>
              </div>

              {/* Bank Remittance */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-slate-700">Bank / HQ Remitted</span>
                  <span className="text-indigo-700 font-mono">
                    {formatCurrency(metrics.totalDeposits, currency)}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${
                        metrics.baqiCashSale > 0
                          ? Math.min(100, (metrics.totalDeposits / metrics.baqiCashSale) * 100)
                          : 0
                      }%`,
                    }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Quick Ledger Deep-Dive Link */}
          <button
            onClick={() => onNavigate('daily_entry')}
            className="w-full bg-slate-50 hover:bg-slate-100 text-slate-800 font-bold text-xs py-3 px-4 rounded-xl border border-slate-200 transition flex items-center justify-between cursor-pointer"
          >
            <span className="flex items-center gap-1.5">
              <Receipt className="w-4 h-4 text-emerald-600" />
              <span>Open Unified Ledger & Filter by Type</span>
            </span>
            <ArrowRight className="w-4 h-4 text-slate-400" />
          </button>
        </div>
      </div>

      {/* 4. MULTI-BRANCH PERFORMANCE CARDS & SHARE OF NETWORK */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-slate-800" />
              <h3 className="font-bold text-slate-900 text-base">
                Branch Performance & Network Share
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Comparative sales, operational deductions, and physical cash held across all locations
            </p>
          </div>
          <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1 rounded-full self-start sm:self-auto">
            {branchSummaries.length} Operating Branches
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-1">
          {branchSummaries.map((branch) => {
            const isSelected = selectedCanteenId === branch.id;
            return (
              <div
                key={branch.id}
                className={`rounded-2xl p-4 sm:p-5 border transition-all ${
                  isSelected
                    ? 'border-emerald-500 bg-emerald-50/30 ring-2 ring-emerald-500/20 shadow-sm'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-xs'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-100/60 px-2 py-0.5 rounded-md">
                      {branch.shareOfNetwork.toFixed(1)}% Share of Sales
                    </span>
                    <h4 className="text-base font-black text-slate-900 mt-1.5">{branch.name}</h4>
                  </div>
                  <button
                    onClick={() => setSelectedCanteenId(isSelected ? 'all' : branch.id)}
                    className={`text-[11px] font-bold px-2.5 py-1 rounded-lg transition cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    {isSelected ? 'Active Filter' : 'Filter Branch'}
                  </button>
                </div>

                {/* Progress bar of network share */}
                <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
                  <div
                    className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${branch.shareOfNetwork}%` }}
                  />
                </div>

                {/* Branch Key Metrics Grid */}
                <div className="grid grid-cols-2 gap-2.5 mt-4 pt-3 border-t border-slate-100 text-xs">
                  <div className="bg-slate-50 p-2 rounded-xl">
                    <span className="text-[10px] text-slate-500 font-semibold block">Cash Sales</span>
                    <span className="font-bold text-slate-900 font-mono mt-0.5 block">
                      {formatCurrency(branch.normalSale, currency)}
                    </span>
                  </div>

                  <div className="bg-rose-50/60 p-2 rounded-xl">
                    <span className="text-[10px] text-rose-600 font-semibold block">Expenses (−)</span>
                    <span className="font-bold text-rose-700 font-mono mt-0.5 block">
                      {formatCurrency(branch.expenses + branch.purchase, currency)}
                    </span>
                  </div>

                  <div className="bg-emerald-50/60 p-2 rounded-xl">
                    <span className="text-[10px] text-emerald-800 font-semibold block">Net Cash (=)</span>
                    <span className="font-bold text-emerald-900 font-mono mt-0.5 block">
                      {formatCurrency(branch.baqiCashSale, currency)}
                    </span>
                  </div>

                  <div className="bg-amber-50/70 p-2 rounded-xl border border-amber-200/60">
                    <span className="text-[10px] text-amber-900 font-bold block">Cash in Hand</span>
                    <span className="font-black text-amber-950 font-mono mt-0.5 block">
                      {formatCurrency(branch.cashInHand, currency)}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. RECENT FINANCIAL PULSE & LABOUR TOKEN KHATA WIDGET */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Live Financial Activity Feed (Recent Transactions Stream) */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-emerald-600" />
              <div>
                <h3 className="font-bold text-slate-900 text-base">Recent Financial Movements</h3>
                <p className="text-xs text-slate-500">Live stream of collections, outflows, and bank transfers</p>
              </div>
            </div>

            <button
              onClick={() => onNavigate('daily_entry')}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
            >
              <span>View Full Ledger</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {recentActivities.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              No transactions recorded for the selected timeframe.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentActivities.map((act) => (
                <div key={act.id} className="py-3 flex items-center justify-between gap-3 hover:bg-slate-50/60 px-2 rounded-xl transition">
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 font-bold ${
                        act.type === 'sale'
                          ? 'bg-emerald-100 text-emerald-700'
                          : act.type === 'deposit'
                          ? 'bg-indigo-100 text-indigo-700'
                          : 'bg-rose-100 text-rose-700'
                      }`}
                    >
                      {act.type === 'sale' && <ArrowUpRight className="w-4 h-4" />}
                      {act.type === 'deposit' && <Landmark className="w-4 h-4" />}
                      {act.type === 'expense' && <ArrowDownRight className="w-4 h-4" />}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-slate-900 text-xs sm:text-sm truncate">
                          {act.title}
                        </span>
                        <span className="text-[10px] font-semibold bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md">
                          {act.branch}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 truncate mt-0.5">
                        {formatDisplayDate(act.date)} • {act.subtitle}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`font-mono font-black text-sm ${
                        act.type === 'sale'
                          ? 'text-emerald-700'
                          : act.type === 'deposit'
                          ? 'text-indigo-700'
                          : 'text-rose-700'
                      }`}
                    >
                      {act.type === 'expense' ? '−' : ''}
                      {formatCurrency(act.amount, currency)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right 1 Col: Sadaqat Canteen Labour Token Widget & Core Shortcuts */}
        <div className="space-y-6">
          {/* Sadaqat Canteen Labour Token Ledger Widget */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Ticket className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                  Labour Token Khata
                </h3>
              </div>
              <button
                onClick={() => onNavigate('labour_tokens')}
                className="text-xs font-bold text-indigo-700 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                <span>Manage</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <p className="text-xs text-slate-500">
              Monthly meal token allocation & wage deductions for enrolled factory workers.
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                <span className="text-slate-500 block text-[11px]">Enrolled</span>
                <span className="text-base font-black text-slate-900 mt-0.5 block font-mono">
                  {labourStatus.workerCount} Workers
                </span>
              </div>

              <div className="bg-indigo-50/60 p-2.5 rounded-xl border border-indigo-100">
                <span className="text-indigo-800 block text-[11px]">Tokens Issued</span>
                <span className="text-base font-black text-indigo-950 mt-0.5 block font-mono">
                  {labourStatus.totalTokensIssued}
                </span>
              </div>

              <div className="bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-100">
                <span className="text-emerald-800 block text-[11px]">Collected</span>
                <span className="text-xs font-black text-emerald-950 mt-0.5 block font-mono">
                  {formatCurrency(labourStatus.totalCashCollected, currency)}
                </span>
              </div>

              <div className="bg-amber-50/60 p-2.5 rounded-xl border border-amber-100">
                <span className="text-amber-900 block text-[11px]">Pending Balance</span>
                <span className="text-xs font-black text-amber-950 mt-0.5 block font-mono">
                  {formatCurrency(labourStatus.pendingBalance, currency)}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Module Jump Pills */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-xs space-y-3">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-400 block">
              Quick Navigation
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onNavigate('window_sales')}
                className="p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50 hover:text-emerald-800 text-slate-700 text-left text-xs font-bold transition flex items-center justify-between cursor-pointer border border-slate-200/80"
              >
                <span>Window Shift</span>
                <ArrowRight className="w-3 h-3 text-slate-400" />
              </button>
              <button
                onClick={() => onNavigate('parties')}
                className="p-2.5 rounded-xl bg-slate-50 hover:bg-indigo-50 hover:text-indigo-800 text-slate-700 text-left text-xs font-bold transition flex items-center justify-between cursor-pointer border border-slate-200/80"
              >
                <span>Parties Khata</span>
                <ArrowRight className="w-3 h-3 text-slate-400" />
              </button>
              <button
                onClick={() => onNavigate('staff')}
                className="p-2.5 rounded-xl bg-slate-50 hover:bg-purple-50 hover:text-purple-800 text-slate-700 text-left text-xs font-bold transition flex items-center justify-between cursor-pointer border border-slate-200/80"
              >
                <span>Staff & Payroll</span>
                <ArrowRight className="w-3 h-3 text-slate-400" />
              </button>
              <button
                onClick={() => onNavigate('reports')}
                className="p-2.5 rounded-xl bg-slate-50 hover:bg-amber-50 hover:text-amber-800 text-slate-700 text-left text-xs font-bold transition flex items-center justify-between cursor-pointer border border-slate-200/80"
              >
                <span>Profit Reports</span>
                <ArrowRight className="w-3 h-3 text-slate-400" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 6. MODAL: QUICK BANK DEPOSIT (RECORD DIRECTLY FROM DASHBOARD) */}
      {depositModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold">
                  <Landmark className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Record Bank Deposit</h3>
                  <p className="text-xs text-slate-500">Transfer physical counter cash to bank account</p>
                </div>
              </div>
              <button
                onClick={() => setDepositModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleQuickDepositSubmit} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={depositDate}
                    onChange={(e) => setDepositDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Branch</label>
                  <select
                    value={depositCanteenId}
                    onChange={(e) => setDepositCanteenId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold focus:ring-2 focus:ring-indigo-500 focus:outline-none cursor-pointer"
                  >
                    {activeCanteens.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Deposit Amount ({currency})
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  placeholder="e.g. 50000"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-base font-black font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Deposit To</label>
                  <select
                    value={depositTo}
                    onChange={(e) => setDepositTo(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none cursor-pointer"
                  >
                    <option value="Bank Account">Bank Account</option>
                    <option value="Head Office Vault">Head Office Vault</option>
                    <option value="Online / Raast">Online / Raast</option>
                    <option value="Director Handover">Director Handover</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Bank Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Meezan / HBL"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Slip / Ref # (Optional)</label>
                <input
                  type="text"
                  placeholder="Deposit receipt number"
                  value={slipNumber}
                  onChange={(e) => setSlipNumber(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Remarks (Optional)</label>
                <input
                  type="text"
                  placeholder="Notes or depositor name"
                  value={depositRemarks}
                  onChange={(e) => setDepositRemarks(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setDepositModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition cursor-pointer flex items-center gap-1.5"
                >
                  <Landmark className="w-4 h-4" />
                  <span>Confirm Deposit</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

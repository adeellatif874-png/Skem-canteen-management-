import React, { useState, useMemo } from 'react';
import {
  CreditCard,
  Plus,
  Search,
  Filter,
  Printer,
  Edit,
  Trash2,
  FileSpreadsheet,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Building2,
  TrendingUp,
  ArrowUpRight,
  Receipt,
  FileText,
  Ban,
  Check,
  Calendar,
} from 'lucide-react';
import { Invoice, InvoiceChequePayment, ChequeStatus, Canteen } from '../types';
import { formatCurrency } from '../lib/storage';
import { exportChequesToExcel, printChequeReceiptVoucher } from '../lib/invoiceUtils';

interface InvoiceChequesSectionProps {
  invoices: Invoice[];
  cheques: InvoiceChequePayment[];
  canteens: Canteen[];
  currencySymbol: string;
  onOpenAddCheque: (invoiceId?: string) => void;
  onOpenEditCheque: (cheque: InvoiceChequePayment) => void;
  onDeleteCheque: (id: string) => void;
  onQuickUpdateStatus: (cheque: InvoiceChequePayment, newStatus: ChequeStatus) => void;
}

export const InvoiceChequesSection: React.FC<InvoiceChequesSectionProps> = ({
  invoices = [],
  cheques = [],
  canteens = [],
  currencySymbol = 'Rs.',
  onOpenAddCheque,
  onOpenEditCheque,
  onDeleteCheque,
  onQuickUpdateStatus,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | ChequeStatus>('all');
  const [buyerFilter, setBuyerFilter] = useState<string>('all');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Extract unique buyers from invoices and cheques
  const uniqueBuyers = useMemo(() => {
    const set = new Set<string>();
    invoices.forEach((i) => i.buyerName && set.add(i.buyerName));
    cheques.forEach((c) => c.buyerName && set.add(c.buyerName));
    return Array.from(set);
  }, [invoices, cheques]);

  // Invoice settlements mapping
  const invoiceSettlements = useMemo(() => {
    const map = new Map<string, { settled: number; cheques: InvoiceChequePayment[] }>();
    cheques.forEach((chq) => {
      if (chq.invoiceId && chq.status !== 'Bounced' && chq.status !== 'Cancelled') {
        const existing = map.get(chq.invoiceId) || { settled: 0, cheques: [] };
        existing.settled += chq.settledAmount || chq.amount || 0;
        existing.cheques.push(chq);
        map.set(chq.invoiceId, existing);
      }
    });
    return map;
  }, [cheques]);

  // Global Statistics
  const stats = useMemo(() => {
    const totalInvoiced = invoices.reduce((sum, i) => sum + (i.totalNetAmount || 0), 0);

    let totalChequesReceived = 0;
    let totalCleared = 0;
    let totalInHand = 0;
    let totalDeposited = 0;
    let totalBounced = 0;

    cheques.forEach((c) => {
      const amt = c.amount || 0;
      totalChequesReceived += amt;
      if (c.status === 'Cleared') totalCleared += amt;
      else if (c.status === 'In Hand') totalInHand += amt;
      else if (c.status === 'Deposited') totalDeposited += amt;
      else if (c.status === 'Bounced') totalBounced += amt;
    });

    const totalSettledCredit = cheques
      .filter((c) => c.status !== 'Bounced' && c.status !== 'Cancelled')
      .reduce((sum, c) => sum + (c.settledAmount || c.amount || 0), 0);

    const outstandingBalance = Math.max(0, totalInvoiced - totalSettledCredit);

    // Count of fully paid invoices
    let paidInvoicesCount = 0;
    let partialInvoicesCount = 0;
    let unpaidInvoicesCount = 0;

    invoices.forEach((inv) => {
      const settled = invoiceSettlements.get(inv.id)?.settled || 0;
      if (settled >= (inv.totalNetAmount || 0) && (inv.totalNetAmount || 0) > 0) {
        paidInvoicesCount++;
      } else if (settled > 0) {
        partialInvoicesCount++;
      } else {
        unpaidInvoicesCount++;
      }
    });

    return {
      totalInvoiced,
      totalChequesReceived,
      totalCleared,
      totalInHand,
      totalDeposited,
      totalBounced,
      outstandingBalance,
      paidInvoicesCount,
      partialInvoicesCount,
      unpaidInvoicesCount,
      totalInvoicesCount: invoices.length,
    };
  }, [invoices, cheques, invoiceSettlements]);

  // Filtered Cheques
  const filteredCheques = useMemo(() => {
    return cheques.filter((c) => {
      if (statusFilter !== 'all' && c.status !== statusFilter) return false;
      if (buyerFilter !== 'all' && c.buyerName !== buyerFilter) return false;

      if (searchTerm.trim() !== '') {
        const term = searchTerm.toLowerCase();
        const matchNo = c.chequeNo?.toLowerCase().includes(term);
        const matchBank = c.bankName?.toLowerCase().includes(term);
        const matchBuyer = c.buyerName?.toLowerCase().includes(term);
        const matchInv = c.invoiceNo?.toLowerCase().includes(term);
        const matchVoucher = c.receiptVoucherNo?.toLowerCase().includes(term);
        const matchNotes = c.notes?.toLowerCase().includes(term);
        if (!matchNo && !matchBank && !matchBuyer && !matchInv && !matchVoucher && !matchNotes) {
          return false;
        }
      }
      return true;
    });
  }, [cheques, statusFilter, buyerFilter, searchTerm]);

  return (
    <div className="space-y-6">
      {/* Top Banner & Fast Actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 rounded-2xl text-white shadow-lg border border-slate-800">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 flex items-center justify-center font-bold">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2.5">
                Cheque Payments & Recovery Ledger
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                  {cheques.length} Cheques Recorded
                </span>
              </h2>
              <p className="text-slate-300 text-xs sm:text-sm mt-0.5">
                Dedicated record-keeping for incoming client cheques, bank realization, and invoice settlement tracking
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            onClick={() => exportChequesToExcel(filteredCheques, currencySymbol)}
            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-semibold rounded-xl border border-slate-700 transition cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Export Excel</span>
          </button>

          <button
            onClick={() => onOpenAddCheque()}
            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold rounded-xl shadow-lg shadow-emerald-950/40 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Record Incoming Cheque</span>
          </button>
        </div>
      </div>

      {/* 5 High-Visibility Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Total Invoiced
          </span>
          <p className="text-xl font-black text-slate-900 mt-1">
            {formatCurrency(stats.totalInvoiced, currencySymbol)}
          </p>
          <span className="text-xs text-slate-500 mt-0.5 block font-medium">
            Across {stats.totalInvoicesCount} invoices
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-emerald-200 bg-emerald-50/20 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider block">
              Cleared & Realized
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-xl font-black text-emerald-700 mt-1">
            {formatCurrency(stats.totalCleared, currencySymbol)}
          </p>
          <span className="text-xs text-emerald-600 mt-0.5 block font-medium">
            Funds deposited in bank
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-amber-200 bg-amber-50/20 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider block">
              In Hand / Deposited
            </span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-xl font-black text-amber-700 mt-1">
            {formatCurrency(stats.totalInHand + stats.totalDeposited, currencySymbol)}
          </p>
          <span className="text-xs text-amber-600 mt-0.5 block font-medium">
            Under bank clearing
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-rose-200 bg-rose-50/20 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wider block">
              Unpaid Balance Due
            </span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <p className="text-xl font-black text-rose-700 mt-1">
            {formatCurrency(stats.outstandingBalance, currencySymbol)}
          </p>
          <span className="text-xs text-rose-600 mt-0.5 block font-medium">
            Awaiting cheque payment
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-indigo-200 bg-indigo-50/20 shadow-xs col-span-2 lg:col-span-1">
          <span className="text-[11px] font-bold text-indigo-700 uppercase tracking-wider block">
            Invoice Settlement
          </span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-xl font-black text-indigo-900">{stats.paidInvoicesCount}</span>
            <span className="text-xs font-semibold text-slate-500">of {stats.totalInvoicesCount} Paid</span>
          </div>
          <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mt-2">
            <div
              className="bg-indigo-600 h-full rounded-full"
              style={{
                width: `${stats.totalInvoicesCount > 0 ? (stats.paidInvoicesCount / stats.totalInvoicesCount) * 100 : 0}%`,
              }}
            />
          </div>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by Cheque #, Bank, Invoice #, or Client..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
            {(['all', 'In Hand', 'Deposited', 'Cleared', 'Bounced'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`text-xs px-3 py-1.5 rounded-lg font-semibold transition cursor-pointer ${
                  statusFilter === st
                    ? 'bg-white text-slate-900 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st === 'all' ? 'All Cheques' : st}
              </button>
            ))}
          </div>
        </div>

        {uniqueBuyers.length > 0 && (
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-500">Client:</span>
            <select
              value={buyerFilter}
              onChange={(e) => setBuyerFilter(e.target.value)}
              className="text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
            >
              <option value="all">All Clients ({uniqueBuyers.length})</option>
              {uniqueBuyers.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Cheques Register Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-indigo-600" />
              <span>Incoming Cheques Register ({filteredCheques.length})</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Comprehensive list of received cheques with linked invoices, amounts, and bank realization
            </p>
          </div>
        </div>

        {filteredCheques.length === 0 ? (
          <div className="py-16 text-center">
            <CreditCard className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No Cheque Payments Recorded</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Record incoming cheques from buyers (e.g. Beacon Impex) to track which invoices are settled.
            </p>
            <button
              onClick={() => onOpenAddCheque()}
              className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Record First Cheque Now</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4">Receipt Date</th>
                  <th className="py-3 px-4">Cheque # & Bank</th>
                  <th className="py-3 px-4">Cheque Date</th>
                  <th className="py-3 px-4">Linked Invoice & Client</th>
                  <th className="py-3 px-4 text-right">Cheque Amount</th>
                  <th className="py-3 px-4 text-right">Deductions</th>
                  <th className="py-3 px-4 text-right">Settled Credit</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-center">Quick Status</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredCheques.map((chq) => {
                  const hasDeductions = (chq.whtDeduction || 0) > 0 || (chq.gstDeduction || 0) > 0;

                  return (
                    <tr key={chq.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-slate-800 block">
                          {chq.receivedDate}
                        </span>
                        {chq.receiptVoucherNo && (
                          <span className="text-[10px] text-slate-400 block font-mono">
                            {chq.receiptVoucherNo}
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-black text-slate-900 bg-indigo-50 text-indigo-900 px-2 py-0.5 rounded-md border border-indigo-200">
                            {chq.chequeNo}
                          </span>
                        </div>
                        <span className="text-[11px] font-bold text-slate-700 block mt-0.5">
                          {chq.bankName}
                        </span>
                        {chq.depositAccount && (
                          <span className="text-[10px] text-slate-400 block truncate max-w-[150px]">
                            A/C: {chq.depositAccount}
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 font-medium text-slate-700">
                        {chq.chequeDate}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200 text-[11px]">
                            #{chq.invoiceNo || 'General'}
                          </span>
                        </div>
                        <span className="font-bold text-slate-800 block mt-0.5">
                          {chq.buyerName}
                        </span>
                        {chq.notes && (
                          <span className="text-[10px] text-slate-400 block truncate max-w-[170px] italic">
                            {chq.notes}
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right font-extrabold text-slate-900">
                        {formatCurrency(chq.amount, currencySymbol)}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        {hasDeductions ? (
                          <div>
                            {chq.whtDeduction ? (
                              <span className="text-[10px] text-amber-700 block">
                                WHT: {formatCurrency(chq.whtDeduction, currencySymbol)}
                              </span>
                            ) : null}
                            {chq.gstDeduction ? (
                              <span className="text-[10px] text-indigo-700 block">
                                GST: {formatCurrency(chq.gstDeduction, currencySymbol)}
                              </span>
                            ) : null}
                          </div>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right font-black text-emerald-700">
                        {formatCurrency(chq.settledAmount || chq.amount, currencySymbol)}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                            chq.status === 'Cleared'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : chq.status === 'Deposited'
                              ? 'bg-sky-100 text-sky-800 border border-sky-300'
                              : chq.status === 'In Hand'
                              ? 'bg-amber-100 text-amber-800 border border-amber-300'
                              : 'bg-rose-100 text-rose-800 border border-rose-300'
                          }`}
                        >
                          {chq.status === 'Cleared' && <CheckCircle2 className="w-3 h-3" />}
                          {chq.status === 'Deposited' && <ArrowUpRight className="w-3 h-3" />}
                          {chq.status === 'In Hand' && <Clock className="w-3 h-3" />}
                          {chq.status === 'Bounced' && <Ban className="w-3 h-3" />}
                          <span>{chq.status}</span>
                        </span>
                      </td>

                      {/* 1-Click Fast Status Transition */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {chq.status === 'In Hand' && (
                            <button
                              onClick={() => onQuickUpdateStatus(chq, 'Deposited')}
                              title="Mark Deposited to Bank"
                              className="px-2 py-1 bg-sky-50 hover:bg-sky-100 text-sky-700 font-bold text-[10px] rounded-lg border border-sky-200 transition cursor-pointer"
                            >
                              Deposit
                            </button>
                          )}
                          {chq.status === 'Deposited' && (
                            <button
                              onClick={() => onQuickUpdateStatus(chq, 'Cleared')}
                              title="Mark Cleared / Realized"
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-[10px] rounded-lg border border-emerald-200 transition cursor-pointer"
                            >
                              Clear
                            </button>
                          )}
                          {chq.status !== 'Cleared' && chq.status !== 'Bounced' && (
                            <button
                              onClick={() => onQuickUpdateStatus(chq, 'Bounced')}
                              title="Mark Bounced / Dishonored"
                              className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-[10px] rounded-lg border border-rose-200 transition cursor-pointer"
                            >
                              Bounce
                            </button>
                          )}
                          {chq.status === 'Cleared' && (
                            <span className="text-[10px] text-emerald-600 font-bold">Realized</span>
                          )}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => printChequeReceiptVoucher(chq, currencySymbol)}
                            title="Print Cheque Receipt Voucher"
                            className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition cursor-pointer"
                          >
                            <Printer className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => onOpenEditCheque(chq)}
                            title="Edit Cheque"
                            className="p-1.5 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition cursor-pointer"
                          >
                            <Edit className="w-4 h-4" />
                          </button>

                          {deleteConfirmId === chq.id ? (
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => {
                                  onDeleteCheque(chq.id);
                                  setDeleteConfirmId(null);
                                }}
                                className="px-2 py-1 bg-rose-600 text-white font-bold text-[10px] rounded transition cursor-pointer"
                              >
                                Confirm
                              </button>
                              <button
                                onClick={() => setDeleteConfirmId(null)}
                                className="px-1.5 py-1 bg-slate-200 text-slate-700 text-[10px] rounded transition cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setDeleteConfirmId(chq.id)}
                              title="Delete Cheque"
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Invoice Recovery Status Matrix: Clear view of which invoices are paid and which are pending */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
          <div>
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-600" />
              <span>Invoice Recovery & Reconciliation Matrix</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Live status of each created invoice: Total Bill, Cheques Received, Balance Outstanding, and Payment Status
            </p>
          </div>
          <span className="text-xs font-semibold text-slate-600 bg-slate-200/70 px-3 py-1 rounded-lg">
            {invoices.length} Total Invoices Tracked
          </span>
        </div>

        {invoices.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            No invoices created yet. Create invoices in the Tax Invoices tab.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4">Invoice # & Date</th>
                  <th className="py-3 px-4">Buyer / Customer</th>
                  <th className="py-3 px-4 text-right">Invoice Net Total</th>
                  <th className="py-3 px-4 text-right">Cheques Received</th>
                  <th className="py-3 px-4 text-right">Balance Due</th>
                  <th className="py-3 px-4">Associated Cheques</th>
                  <th className="py-3 px-4 text-center">Payment Status</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.map((inv) => {
                  const settlement = invoiceSettlements.get(inv.id) || { settled: 0, cheques: [] };
                  const settled = settlement.settled;
                  const total = inv.totalNetAmount || 0;
                  const balance = Math.max(0, total - settled);
                  const isPaid = settled >= total && total > 0;
                  const isPartial = settled > 0 && settled < total;

                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3 px-4">
                        <span className="font-black text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200 text-xs">
                          #{inv.invoiceNo}
                        </span>
                        <span className="text-[11px] text-slate-500 block mt-0.5">
                          {inv.invoiceDate}
                        </span>
                      </td>

                      <td className="py-3 px-4 font-bold text-slate-800">
                        {inv.buyerName}
                      </td>

                      <td className="py-3 px-4 text-right font-black text-slate-900">
                        {formatCurrency(total, currencySymbol)}
                      </td>

                      <td className="py-3 px-4 text-right font-bold text-emerald-700">
                        {formatCurrency(settled, currencySymbol)}
                      </td>

                      <td className="py-3 px-4 text-right font-black">
                        {balance > 0 ? (
                          <span className="text-rose-700">{formatCurrency(balance, currencySymbol)}</span>
                        ) : (
                          <span className="text-emerald-700">0.00 (Nil)</span>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        {settlement.cheques.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {settlement.cheques.map((c) => (
                              <span
                                key={c.id}
                                className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                                  c.status === 'Cleared'
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                    : 'bg-amber-50 text-amber-800 border-amber-200'
                                }`}
                              >
                                {c.chequeNo} ({c.status})
                              </span>
                            ))}
                          </div>
                        ) : (
                          <span className="text-[11px] text-slate-400 italic">No cheque yet</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                            isPaid
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : isPartial
                              ? 'bg-amber-100 text-amber-800 border border-amber-300'
                              : 'bg-rose-100 text-rose-800 border border-rose-300'
                          }`}
                        >
                          {isPaid ? (
                            <>
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Paid in Full</span>
                            </>
                          ) : isPartial ? (
                            <>
                              <Clock className="w-3 h-3" />
                              <span>Partially Paid</span>
                            </>
                          ) : (
                            <>
                              <AlertTriangle className="w-3 h-3" />
                              <span>Pending / Unpaid</span>
                            </>
                          )}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => onOpenAddCheque(inv.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-lg border border-indigo-200 transition cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                          <span>+ Cheque</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

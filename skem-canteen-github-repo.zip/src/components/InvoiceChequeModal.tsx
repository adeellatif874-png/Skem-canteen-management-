import React, { useState, useEffect } from 'react';
import { X, CreditCard, CheckCircle2, AlertCircle, Building2, Calendar, FileText } from 'lucide-react';
import { Invoice, InvoiceChequePayment, ChequeStatus } from '../types';
import { formatCurrency } from '../lib/storage';

interface InvoiceChequeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (chequeData: Omit<InvoiceChequePayment, 'id' | 'createdAt'>) => void;
  onUpdate?: (cheque: InvoiceChequePayment) => void;
  editingCheque: InvoiceChequePayment | null;
  preselectedInvoiceId?: string;
  invoices: Invoice[];
  existingCheques: InvoiceChequePayment[];
  currencySymbol: string;
}

const COMMON_BANKS = [
  'Meezan Bank',
  'Habib Bank (HBL)',
  'MCB Bank',
  'Bank Alfalah',
  'Allied Bank (ABL)',
  'United Bank (UBL)',
  'Askari Bank',
  'Faysal Bank',
  'Bank of Punjab (BOP)',
  'Standard Chartered',
];

export const InvoiceChequeModal: React.FC<InvoiceChequeModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onUpdate,
  editingCheque,
  preselectedInvoiceId,
  invoices = [],
  existingCheques = [],
  currencySymbol = 'Rs.',
}) => {
  const [invoiceId, setInvoiceId] = useState<string>('');
  const [chequeNo, setChequeNo] = useState('');
  const [bankName, setBankName] = useState('Meezan Bank');
  const [chequeDate, setChequeDate] = useState(new Date().toISOString().split('T')[0]);
  const [receivedDate, setReceivedDate] = useState(new Date().toISOString().split('T')[0]);
  const [amount, setAmount] = useState<number | ''>('');
  const [whtDeduction, setWhtDeduction] = useState<number | ''>('');
  const [gstDeduction, setGstDeduction] = useState<number | ''>('');
  const [status, setStatus] = useState<ChequeStatus>('In Hand');
  const [depositAccount, setDepositAccount] = useState('RNC Enterprises Bank Account');
  const [depositDate, setDepositDate] = useState('');
  const [clearedDate, setClearedDate] = useState('');
  const [bouncedReason, setBouncedReason] = useState('');
  const [receiptVoucherNo, setReceiptVoucherNo] = useState('');
  const [notes, setNotes] = useState('');

  // Calculate unpaid balance for an invoice
  const getInvoiceBalance = (inv: Invoice, currentChequeId?: string) => {
    const totalCheques = existingCheques
      .filter((c) => c.invoiceId === inv.id && c.id !== currentChequeId && c.status !== 'Bounced' && c.status !== 'Cancelled')
      .reduce((sum, c) => sum + (c.settledAmount || c.amount || 0), 0);
    return Math.max(0, (inv.totalNetAmount || 0) - totalCheques);
  };

  useEffect(() => {
    if (editingCheque) {
      setInvoiceId(editingCheque.invoiceId || '');
      setChequeNo(editingCheque.chequeNo || '');
      setBankName(editingCheque.bankName || 'Meezan Bank');
      setChequeDate(editingCheque.chequeDate || new Date().toISOString().split('T')[0]);
      setReceivedDate(editingCheque.receivedDate || new Date().toISOString().split('T')[0]);
      setAmount(editingCheque.amount || '');
      setWhtDeduction(editingCheque.whtDeduction || '');
      setGstDeduction(editingCheque.gstDeduction || '');
      setStatus(editingCheque.status || 'In Hand');
      setDepositAccount(editingCheque.depositAccount || 'RNC Enterprises Bank Account');
      setDepositDate(editingCheque.depositDate || '');
      setClearedDate(editingCheque.clearedDate || '');
      setBouncedReason(editingCheque.bouncedReason || '');
      setReceiptVoucherNo(editingCheque.receiptVoucherNo || '');
      setNotes(editingCheque.notes || '');
    } else {
      const targetInvId = preselectedInvoiceId || (invoices.length > 0 ? invoices[0].id : '');
      const selectedInv = invoices.find((i) => i.id === targetInvId);
      const remaining = selectedInv ? getInvoiceBalance(selectedInv) : '';

      setInvoiceId(targetInvId);
      setChequeNo('');
      setBankName('Meezan Bank');
      setChequeDate(new Date().toISOString().split('T')[0]);
      setReceivedDate(new Date().toISOString().split('T')[0]);
      setAmount(remaining || '');
      setWhtDeduction('');
      setGstDeduction('');
      setStatus('In Hand');
      setDepositAccount('RNC Enterprises Bank Account');
      setDepositDate('');
      setClearedDate('');
      setBouncedReason('');
      setReceiptVoucherNo(`CRV-${Math.floor(1000 + Math.random() * 9000)}`);
      setNotes('');
    }
  }, [editingCheque, preselectedInvoiceId, isOpen, invoices]);

  if (!isOpen) return null;

  const handleInvoiceSelect = (id: string) => {
    setInvoiceId(id);
    if (id && id !== 'general') {
      const inv = invoices.find((i) => i.id === id);
      if (inv) {
        const remaining = getInvoiceBalance(inv, editingCheque?.id);
        if (remaining > 0 && (!amount || amount === 0)) {
          setAmount(remaining);
        }
      }
    }
  };

  const numAmount = Number(amount) || 0;
  const numWht = Number(whtDeduction) || 0;
  const numGst = Number(gstDeduction) || 0;
  const calculatedSettledAmount = numAmount + numWht + numGst;

  const selectedInvoice = invoices.find((i) => i.id === invoiceId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chequeNo.trim()) {
      alert('Please enter a Cheque Number.');
      return;
    }
    if (numAmount <= 0) {
      alert('Please enter a valid Cheque Amount.');
      return;
    }

    const payload: Omit<InvoiceChequePayment, 'id' | 'createdAt'> = {
      invoiceId: invoiceId || 'general',
      invoiceNo: selectedInvoice ? selectedInvoice.invoiceNo : 'General',
      buyerName: selectedInvoice ? selectedInvoice.buyerName : 'Direct / General Client',
      canteenId: selectedInvoice?.canteenId,
      canteenName: selectedInvoice?.canteenName,
      chequeNo: chequeNo.trim(),
      bankName: bankName.trim(),
      chequeDate,
      receivedDate,
      depositDate: status === 'Deposited' || status === 'Cleared' ? (depositDate || receivedDate) : undefined,
      clearedDate: status === 'Cleared' ? (clearedDate || receivedDate) : undefined,
      amount: numAmount,
      whtDeduction: numWht > 0 ? numWht : undefined,
      gstDeduction: numGst > 0 ? numGst : undefined,
      settledAmount: calculatedSettledAmount,
      depositAccount: depositAccount.trim(),
      status,
      bouncedReason: status === 'Bounced' ? bouncedReason.trim() : undefined,
      receiptVoucherNo: receiptVoucherNo.trim() || undefined,
      notes: notes.trim() || undefined,
    };

    if (editingCheque && onUpdate) {
      onUpdate({
        ...editingCheque,
        ...payload,
      });
    } else {
      onSave(payload);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 my-8">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-700 flex items-center justify-center font-bold">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900">
                {editingCheque ? 'Edit Incoming Cheque' : 'Record Incoming Cheque'}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Track client cheque payments, withholding tax deductions, and invoice realization
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* Linked Invoice Selector */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Select Invoice to Settle *
            </label>
            <select
              value={invoiceId}
              onChange={(e) => handleInvoiceSelect(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            >
              <option value="general">Advance / General Cheque (No Invoice Linked)</option>
              {invoices.map((inv) => {
                const bal = getInvoiceBalance(inv, editingCheque?.id);
                const isPaid = bal <= 0;
                return (
                  <option key={inv.id} value={inv.id}>
                    Invoice #{inv.invoiceNo} — {inv.buyerName} — Total: {formatCurrency(inv.totalNetAmount, currencySymbol)} {isPaid ? '(Fully Paid)' : `(Due: ${formatCurrency(bal, currencySymbol)})`}
                  </option>
                );
              })}
            </select>

            {selectedInvoice && (
              <div className="mt-3 pt-3 border-t border-slate-200/60 flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="text-slate-600">
                  Buyer: <strong className="text-slate-900">{selectedInvoice.buyerName}</strong>
                </span>
                <span className="text-slate-600">
                  Invoice Date: <strong>{selectedInvoice.invoiceDate}</strong>
                </span>
                <span className="text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100 font-bold">
                  Remaining Unpaid: {formatCurrency(getInvoiceBalance(selectedInvoice, editingCheque?.id), currencySymbol)}
                </span>
              </div>
            )}
          </div>

          {/* Cheque Number & Bank Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Cheque Number *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. CHQ-894102 or 0089412"
                value={chequeNo}
                onChange={(e) => setChequeNo(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-xl font-bold tracking-wide text-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Bank Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Meezan Bank"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-xl font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Quick Bank Presets */}
          <div>
            <span className="text-[11px] font-semibold text-slate-400 block mb-1">Quick Select Bank:</span>
            <div className="flex flex-wrap gap-1.5">
              {COMMON_BANKS.map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => setBankName(b)}
                  className={`text-[11px] px-2.5 py-1 rounded-lg border transition cursor-pointer ${
                    bankName === b
                      ? 'bg-indigo-600 text-white border-indigo-600 font-bold'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          {/* Dates: Cheque Date & Received Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Cheque Date (Printed Date) *
              </label>
              <input
                type="date"
                required
                value={chequeDate}
                onChange={(e) => setChequeDate(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Received Date (In Hand) *
              </label>
              <input
                type="date"
                required
                value={receivedDate}
                onChange={(e) => setReceivedDate(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Cheque Amount and Tax Deductions */}
          <div className="bg-emerald-50/60 p-4 rounded-xl border border-emerald-200/80 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-emerald-950 mb-1">
                  Cheque Amount ({currencySymbol}) *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  placeholder="e.g. 500000"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-3 py-2 text-sm bg-white border border-emerald-300 rounded-xl font-extrabold text-emerald-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  WHT Deduction ({currencySymbol})
                </label>
                <input
                  type="number"
                  min="0"
                  placeholder="Income tax deduction"
                  value={whtDeduction}
                  onChange={(e) => setWhtDeduction(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-xl font-medium text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  GST Withholding ({currencySymbol})
                </label>
                <input
                  type="number"
                  min="0"
                  placeholder="Sales tax withheld"
                  value={gstDeduction}
                  onChange={(e) => setGstDeduction(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-xl font-medium text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Settled Amount Calculation Banner */}
            <div className="pt-2 border-t border-emerald-200/60 flex items-center justify-between text-xs">
              <span className="text-emerald-800 font-medium">
                Total Credit Credited to Invoice (Cheque + Deductions):
              </span>
              <span className="text-base font-black text-emerald-950">
                {formatCurrency(calculatedSettledAmount, currencySymbol)}
              </span>
            </div>
          </div>

          {/* Cheque Status & Bank Account */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Cheque Status *
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as ChequeStatus)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              >
                <option value="In Hand">In Hand (Physically Received)</option>
                <option value="Deposited">Deposited in Bank</option>
                <option value="Cleared">Cleared / Funds Credited</option>
                <option value="Bounced">Bounced / Dishonored</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Deposit Company Account
              </label>
              <input
                type="text"
                placeholder="e.g. Meezan Bank A/C 01029384"
                value={depositAccount}
                onChange={(e) => setDepositAccount(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Conditional Status Fields: Deposit / Clearance dates or Bounced Reason */}
          {status === 'Deposited' && (
            <div className="bg-sky-50 p-3 rounded-xl border border-sky-200 text-xs">
              <label className="block font-bold text-sky-900 mb-1">Deposit Date in Bank</label>
              <input
                type="date"
                value={depositDate || receivedDate}
                onChange={(e) => setDepositDate(e.target.value)}
                className="px-3 py-1.5 bg-white border border-sky-300 rounded-lg font-semibold"
              />
            </div>
          )}

          {status === 'Cleared' && (
            <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 text-xs grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-emerald-900 mb-1">Deposit Date</label>
                <input
                  type="date"
                  value={depositDate || receivedDate}
                  onChange={(e) => setDepositDate(e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-emerald-300 rounded-lg font-semibold"
                />
              </div>
              <div>
                <label className="block font-bold text-emerald-900 mb-1">Clearance / Realized Date</label>
                <input
                  type="date"
                  value={clearedDate || receivedDate}
                  onChange={(e) => setClearedDate(e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-emerald-300 rounded-lg font-semibold"
                />
              </div>
            </div>
          )}

          {status === 'Bounced' && (
            <div className="bg-rose-50 p-3 rounded-xl border border-rose-200 text-xs">
              <label className="block font-bold text-rose-900 mb-1">Reason for Bounce *</label>
              <input
                type="text"
                placeholder="e.g. Insufficient funds, signature difference, stale cheque"
                value={bouncedReason}
                onChange={(e) => setBouncedReason(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-rose-300 rounded-lg font-medium text-rose-900"
              />
            </div>
          )}

          {/* Receipt Voucher Reference & Notes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Receipt Voucher Ref #
              </label>
              <input
                type="text"
                placeholder="e.g. CRV-2026-01"
                value={receiptVoucherNo}
                onChange={(e) => setReceiptVoucherNo(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Remarks / Notes
              </label>
              <input
                type="text"
                placeholder="e.g. Received via courier, 50% advance for beacon"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Modal Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md transition cursor-pointer"
            >
              {editingCheque ? 'Update Cheque Record' : 'Save Cheque Record'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

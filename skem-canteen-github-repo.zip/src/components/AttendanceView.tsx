import React, { useState, useMemo } from 'react';
import {
  CalendarCheck,
  Plus,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  Building2,
  Edit2,
  Trash2,
  Calendar as CalendarIcon,
  UserCheck,
} from 'lucide-react';
import {
  AttendanceRecord,
  AttendanceStatus,
  Canteen,
  Staff,
} from '../types';
import { ConfirmModal } from './ConfirmModal';
import { isCanteenMatch, formatDisplayDate } from '../lib/storage';

interface AttendanceViewProps {
  attendanceRecords: AttendanceRecord[];
  staffList: Staff[];
  canteens: Canteen[];
  selectedCanteenId: string;
  onAddAttendance: (record: Omit<AttendanceRecord, 'id' | 'createdAt'>) => void;
  onEditAttendance: (id: string, record: Partial<AttendanceRecord>) => void;
  onDeleteAttendance: (id: string) => void;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  attendanceRecords,
  staffList,
  canteens,
  selectedCanteenId,
  onAddAttendance,
  onEditAttendance,
  onDeleteAttendance,
}) => {
  const activeCanteens = (canteens || []).filter((c) => c.status === 'active');
  
  // Filter active staff by canteen selection
  const activeStaff = useMemo(() => {
    return (staffList || []).filter((s) => {
      const isStaffActive = s.status === 'active';
      const matchesCanteen = isCanteenMatch(s, selectedCanteenId, canteens);
      return isStaffActive && matchesCanteen;
    });
  }, [staffList, selectedCanteenId, canteens]);

  const todayStr = new Date().toISOString().split('T')[0];
  const thirtyDaysAgoStr = new Date(
    new Date().setDate(new Date().getDate() - 30)
  )
    .toISOString()
    .split('T')[0];

  // From Date & To Date Filter Range
  const [startDate, setStartDate] = useState<string>(thirtyDaysAgoStr);
  const [endDate, setEndDate] = useState<string>(todayStr);
  const [searchTerm, setSearchTerm] = useState('');

  // Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<AttendanceRecord | null>(null);

  // Form State
  const [staffId, setStaffId] = useState('');
  const [date, setDate] = useState(todayStr);
  const [status, setStatus] = useState<AttendanceStatus>('Present');
  const [inTime, setInTime] = useState('08:00');
  const [outTime, setOutTime] = useState('17:00');
  const [leaveReason, setLeaveReason] = useState('');
  const [remarks, setRemarks] = useState('');

  // Delete modal
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  // Filter Attendance Records by Date Range, Canteen, and Search Query
  const filteredRecords = useMemo(() => {
    return attendanceRecords
      .filter((rec) => {
        const matchesCanteen = isCanteenMatch(rec, selectedCanteenId, canteens);
        const matchesStartDate = !startDate || rec.date >= startDate;
        const matchesEndDate = !endDate || rec.date <= endDate;
        const matchesSearch =
          (rec.staffName && rec.staffName.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (rec.canteenName && rec.canteenName.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (rec.leaveReason && rec.leaveReason.toLowerCase().includes(searchTerm.toLowerCase()));
        return matchesCanteen && matchesStartDate && matchesEndDate && matchesSearch;
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [attendanceRecords, selectedCanteenId, canteens, startDate, endDate, searchTerm]);

  const openAddModal = (preselectedStaffId?: string) => {
    setEditingRecord(null);
    const firstStaff = preselectedStaffId
      ? activeStaff.find((s) => s.id === preselectedStaffId)
      : activeStaff[0];
    setStaffId(firstStaff?.id || activeStaff[0]?.id || '');
    setDate(endDate || todayStr);
    setStatus('Present');
    setInTime('08:00');
    setOutTime('17:00');
    setLeaveReason('');
    setRemarks('');
    setModalOpen(true);
  };

  const openEditModal = (rec: AttendanceRecord) => {
    setEditingRecord(rec);
    setStaffId(rec.staffId);
    setDate(rec.date);
    setStatus(rec.status);
    setInTime(rec.inTime || '08:00');
    setOutTime(rec.outTime || '17:00');
    setLeaveReason(rec.leaveReason || '');
    setRemarks(rec.remarks || '');
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const targetStaff = staffList.find((s) => s.id === staffId);
    if (!targetStaff) return;

    const data = {
      staffId: targetStaff.id,
      staffName: targetStaff.name,
      canteenId: targetStaff.canteenId,
      canteenName: targetStaff.canteenName,
      date,
      status,
      inTime: status === 'Present' ? inTime : undefined,
      outTime: status === 'Present' ? outTime : undefined,
      leaveReason: status === 'Leave' ? leaveReason.trim() : undefined,
      remarks: remarks.trim(),
    };

    if (editingRecord) {
      onEditAttendance(editingRecord.id, data);
    } else {
      // Check if attendance already exists for this staff member on this date
      const existing = attendanceRecords.find(
        (r) => r.staffId === targetStaff.id && r.date === date
      );
      if (existing) {
        onEditAttendance(existing.id, data);
      } else {
        onAddAttendance(data);
      }
    }

    setModalOpen(false);
  };

  // Quick mark present for all staff on target date who haven't been marked yet
  const handleQuickMarkAllPresent = () => {
    const targetDate = endDate || todayStr;
    const existingStaffForDate = new Set(
      attendanceRecords
        .filter((r) => r.date === targetDate)
        .map((r) => r.staffId)
    );

    const unmarkedStaff = activeStaff.filter((s) => !existingStaffForDate.has(s.id));

    if (unmarkedStaff.length === 0) {
      alert(`All staff members already have attendance recorded for ${targetDate}`);
      return;
    }

    unmarkedStaff.forEach((s) => {
      onAddAttendance({
        staffId: s.id,
        staffName: s.name,
        canteenId: s.canteenId,
        canteenName: s.canteenName,
        date: targetDate,
        status: 'Present',
        inTime: '08:00',
        outTime: '17:00',
        remarks: 'Quick marked present',
      });
    });
  };

  // Quick inline status change directly from the table
  const handleInlineStatusChange = (rec: AttendanceRecord, newStatus: AttendanceStatus) => {
    if (rec.status === newStatus) return;
    onEditAttendance(rec.id, {
      status: newStatus,
      inTime: newStatus === 'Present' ? (rec.inTime || '08:00') : undefined,
      outTime: newStatus === 'Present' ? (rec.outTime || '17:00') : undefined,
      leaveReason: newStatus === 'Leave' ? (rec.leaveReason || 'Leave requested') : undefined,
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <CalendarCheck className="w-7 h-7 text-emerald-600" />
            <span>Staff Attendance</span>
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Track daily attendance, date ranges, leave reasons & staff status
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleQuickMarkAllPresent}
            className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-300 shadow-2xs"
            title={`Mark remaining active staff present for ${endDate || todayStr}`}
          >
            <UserCheck className="w-4 h-4 text-emerald-600" />
            <span>Quick Mark Unmarked ({endDate || todayStr})</span>
          </button>
          <button
            onClick={() => openAddModal()}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs sm:text-sm px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Log / Change Attendance</span>
          </button>
        </div>
      </div>

      {/* From Date & To Date Range Filter Toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="text-xs font-bold text-slate-700 uppercase">From Date:</span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700 uppercase">To Date:</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="flex items-center gap-1.5 pl-1">
            <button
              onClick={() => {
                setStartDate(todayStr);
                setEndDate(todayStr);
              }}
              className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold transition-colors cursor-pointer"
            >
              Today
            </button>

            <button
              onClick={() => {
                const firstOfMonth = new Date().toISOString().substring(0, 8) + '01';
                setStartDate(firstOfMonth);
                setEndDate(todayStr);
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
            >
              This Month
            </button>

            <button
              onClick={() => {
                setStartDate('');
                setEndDate('');
              }}
              className="px-2.5 py-1 rounded-lg text-slate-500 hover:text-slate-800 text-xs font-semibold hover:underline cursor-pointer"
            >
              All Time
            </button>
          </div>
        </div>

        <div className="relative md:w-64">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search staff or leave..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
          />
        </div>
      </div>

      {/* Attendance Records Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Date</th>
                <th className="py-3.5 px-4">Staff Name</th>
                <th className="py-3.5 px-4">Canteen</th>
                <th className="py-3.5 px-4">Status & Quick Change</th>
                <th className="py-3.5 px-4">Timing / Leave Reason</th>
                <th className="py-3.5 px-4">Out Time</th>
                <th className="py-3.5 px-4">Remarks</th>
                <th className="py-3.5 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <CalendarCheck className="w-10 h-10 mx-auto mb-2 opacity-30" />
                    <p className="font-semibold text-slate-600">No Attendance Records Found</p>
                    <p className="text-xs text-slate-400 mt-1">
                      Adjust "From" and "To" dates or click "Quick Mark Unmarked" / "Log Attendance".
                    </p>
                  </td>
                </tr>
              ) : (
                filteredRecords.map((rec) => (
                  <tr key={rec.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-900 whitespace-nowrap">
                      {formatDisplayDate(rec.date)}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-800">
                      {rec.staffName}
                    </td>
                    <td className="py-3.5 px-4 text-xs font-semibold text-slate-600">
                      <div className="flex items-center gap-1">
                        <Building2 className="w-3.5 h-3.5 text-slate-400" />
                        <span>{rec.canteenName}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      {/* Inline Quick Status Change Toggle */}
                      <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl w-fit border border-slate-200">
                        <button
                          onClick={() => handleInlineStatusChange(rec, 'Present')}
                          className={`px-2 py-0.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                            rec.status === 'Present'
                              ? 'bg-emerald-600 text-white shadow-2xs'
                              : 'text-slate-600 hover:bg-slate-200'
                          }`}
                          title="Mark Present"
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Present</span>
                        </button>

                        <button
                          onClick={() => handleInlineStatusChange(rec, 'Leave')}
                          className={`px-2 py-0.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                            rec.status === 'Leave'
                              ? 'bg-amber-500 text-white shadow-2xs'
                              : 'text-slate-600 hover:bg-slate-200'
                          }`}
                          title="Mark Leave"
                        >
                          <Clock className="w-3 h-3" />
                          <span>Leave</span>
                        </button>

                        <button
                          onClick={() => handleInlineStatusChange(rec, 'Absent')}
                          className={`px-2 py-0.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                            rec.status === 'Absent'
                              ? 'bg-rose-600 text-white shadow-2xs'
                              : 'text-slate-600 hover:bg-slate-200'
                          }`}
                          title="Mark Absent"
                        >
                          <XCircle className="w-3 h-3" />
                          <span>Absent</span>
                        </button>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-xs font-medium text-slate-700">
                      {rec.status === 'Present' ? (
                        <span className="font-bold text-slate-900">{rec.inTime || '08:00'}</span>
                      ) : rec.status === 'Leave' ? (
                        <span className="text-amber-800 font-semibold">{rec.leaveReason || 'Leave'}</span>
                      ) : (
                        <span className="text-rose-600 font-bold">Absent Day</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-xs font-medium text-slate-700">
                      {rec.status === 'Present' ? (
                        <span className="font-bold text-slate-900">{rec.outTime || '17:00'}</span>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-500 italic max-w-xs truncate">
                      {rec.remarks || '-'}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => openEditModal(rec)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-200 transition-colors cursor-pointer"
                          title="Edit Details / Timing"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setDeleteTargetId(rec.id)}
                          className="p-1.5 rounded-lg text-rose-600 hover:text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer"
                          title="Delete Record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Form for Logging or Modifying Attendance */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">
                {editingRecord ? 'Edit Attendance Record' : 'Record / Update Staff Attendance'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Select Staff Member *
                </label>
                <select
                  required
                  value={staffId}
                  onChange={(e) => setStaffId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {activeStaff.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.canteenName})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Status *
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as AttendanceStatus)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Present">Present</option>
                    <option value="Leave">Leave</option>
                    <option value="Absent">Absent</option>
                  </select>
                </div>
              </div>

              {/* Conditional Timing inputs if Present */}
              {status === 'Present' && (
                <div className="grid grid-cols-2 gap-4 bg-emerald-50/50 p-3 rounded-xl border border-emerald-200">
                  <div>
                    <label className="block text-xs font-bold text-emerald-800 mb-1">
                      In Time
                    </label>
                    <input
                      type="time"
                      value={inTime}
                      onChange={(e) => setInTime(e.target.value)}
                      className="w-full bg-white border border-emerald-300 rounded-lg p-2 text-xs font-bold text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-emerald-800 mb-1">
                      Out Time
                    </label>
                    <input
                      type="time"
                      value={outTime}
                      onChange={(e) => setOutTime(e.target.value)}
                      className="w-full bg-white border border-emerald-300 rounded-lg p-2 text-xs font-bold text-slate-900"
                    />
                  </div>
                </div>
              )}

              {/* Conditional Leave Reason input */}
              {status === 'Leave' && (
                <div>
                  <label className="block text-xs font-bold uppercase text-amber-800 mb-1">
                    Leave Reason / Type
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Sick leave, Family emergency, Sick"
                    value={leaveReason}
                    onChange={(e) => setLeaveReason(e.target.value)}
                    className="w-full bg-amber-50/50 border border-amber-300 rounded-xl p-2.5 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Remarks / Notes (Optional)
                </label>
                <input
                  type="text"
                  placeholder="Additional notes..."
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
                >
                  {editingRecord ? 'Update Record' : 'Save Attendance'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={!!deleteTargetId}
        title="Delete Attendance Record"
        message="Are you sure you want to delete this staff attendance log?"
        confirmLabel="Delete Log"
        onConfirm={() => {
          if (deleteTargetId) onDeleteAttendance(deleteTargetId);
          setDeleteTargetId(null);
        }}
        onClose={() => setDeleteTargetId(null)}
      />
    </div>
  );
};

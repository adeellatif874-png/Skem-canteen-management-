import React, { useState, useEffect, useMemo } from 'react';
import {
  Receipt,
  Plus,
  Search,
  Edit2,
  Trash2,
  Building2,
  FileSpreadsheet,
  Upload,
  Download,
  Wallet,
  Landmark,
  ArrowUpDown,
  CheckCircle2,
  AlertCircle,
  X,
  FileText,
  ShoppingBag,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Canteen, DailyEntry, CanteenCashDeposit } from '../types';
import { formatCurrency, isCanteenMatch, formatDisplayDate } from '../lib/storage';
import { ConfirmModal } from './ConfirmModal';

export type DailyRecordTab = 'all' | 'sales' | 'expenses' | 'purchases' | 'deposits';
export type EntryFormMode = 'full' | 'sales' | 'expense' | 'purchase';

interface DailyEntryViewProps {
  entries: DailyEntry[];
  cashDeposits?: CanteenCashDeposit[];
  canteens: Canteen[];
  selectedCanteenId: string;
  currencySymbol: string;
  isOpenModalImmediately?: boolean;
  onAddEntry: (entry: Omit<DailyEntry, 'id' | 'createdAt' | 'totalSale' | 'netAmount'>) => void;
  onEditEntry: (id: string, entry: Omit<DailyEntry, 'id' | 'createdAt' | 'totalSale' | 'netAmount'>) => void;
  onDeleteEntry: (id: string) => void;
  onAddCashDeposit?: (deposit: Omit<CanteenCashDeposit, 'id' | 'createdAt'>) => void;
  onEditCashDeposit?: (id: string, deposit: Partial<CanteenCashDeposit>) => void;
  onDeleteCashDeposit?: (id: string) => void;
  onCloseQuickModal?: () => void;
}

type SortColumn = 'date' | 'canteenName' | 'normalSale' | 'tokenSale' | 'totalSale' | 'purchase' | 'expenses' | 'netAmount' | 'amount';
type SortOrder = 'asc' | 'desc';

export const DailyEntryView: React.FC<DailyEntryViewProps> = ({
  entries = [],
  cashDeposits = [],
  canteens = [],
  selectedCanteenId,
  currencySymbol = 'Rs.',
  isOpenModalImmediately = false,
  onAddEntry,
  onEditEntry,
  onDeleteEntry,
  onAddCashDeposit,
  onEditCashDeposit,
  onDeleteCashDeposit,
  onCloseQuickModal,
}) => {
  const activeCanteens = useMemo(() => (canteens || []).filter((c) => c.status === 'active'), [canteens]);

  // Active view tab: Default to 'all' so all records and unified ledger are visible immediately
  const [activeTab, setActiveTab] = useState<DailyRecordTab>('all');

  const [searchTerm, setSearchTerm] = useState('');
  const [sortColumn, setSortColumn] = useState<SortColumn>('date');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  const [modalOpen, setModalOpen] = useState(isOpenModalImmediately);
  const [entryMode, setEntryMode] = useState<EntryFormMode>('full');
  const [importModalOpen, setImportModalOpen] = useState(false);
  const [pastedText, setPastedText] = useState('');
  const [editingEntry, setEditingEntry] = useState<DailyEntry | null>(null);

  // Daily Entry Form fields
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [canteenId, setCanteenId] = useState<string>(activeCanteens[0]?.id || '');
  const [normalSale, setNormalSale] = useState<number | ''>(0);
  const [tokenSale, setTokenSale] = useState<number | ''>(0);
  const [purchase, setPurchase] = useState<number | ''>(0);
  const [expenses, setExpenses] = useState<number | ''>(0);
  const [expenseNote, setExpenseNote] = useState('');
  const [remarks, setRemarks] = useState('');

  // Daily Entry Delete target ID
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  // Cash Deposit state
  const [depositModalOpen, setDepositModalOpen] = useState(false);
  const [editingDeposit, setEditingDeposit] = useState<CanteenCashDeposit | null>(null);
  const [depositConfirmDeleteId, setDepositConfirmDeleteId] = useState<string | null>(null);
  const [depositFormError, setDepositFormError] = useState('');

  const [depositForm, setDepositForm] = useState({
    date: new Date().toISOString().split('T')[0],
    canteenId: selectedCanteenId !== 'all' ? selectedCanteenId : activeCanteens[0]?.id || '',
    amount: '',
    depositTo: 'Bank Account',
    bankName: '',
    slipNumber: '',
    depositedBy: '',
    receivedBy: '',
    remarks: '',
  });

  useEffect(() => {
    if (isOpenModalImmediately) {
      openAddModal('full');
    }
  }, [isOpenModalImmediately]);

  // Preview calculations for Daily Entry modal
  const numNormalSale = typeof normalSale === 'number' ? normalSale : 0;
  const numTokenSale = typeof tokenSale === 'number' ? tokenSale : 0;
  const numPurchase = typeof purchase === 'number' ? purchase : 0;
  const numExpenses = typeof expenses === 'number' ? expenses : 0;
  const totalSalePreview = numNormalSale + numTokenSale;
  const netAmountPreview = totalSalePreview - numPurchase - numExpenses;

  // Toggle sorting by clicking header
  const handleSort = (col: SortColumn) => {
    if (sortColumn === col) {
      setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortColumn(col);
      setSortOrder('desc');
    }
  };

  // Filtered Daily Sales Entries
  const filteredEntries = useMemo(() => {
    return (entries || []).filter((entry) => {
      const matchesCanteen = isCanteenMatch(entry, selectedCanteenId, canteens);
      const q = searchTerm.toLowerCase().trim();
      const matchesSearch =
        !q ||
        (entry.canteenName && entry.canteenName.toLowerCase().includes(q)) ||
        entry.date.includes(q) ||
        (entry.expenseNote && entry.expenseNote.toLowerCase().includes(q)) ||
        (entry.remarks && entry.remarks.toLowerCase().includes(q));
      return matchesCanteen && matchesSearch;
    });
  }, [entries, selectedCanteenId, canteens, searchTerm]);

  // Sorted Daily Entries
  const sortedEntries = useMemo(() => {
    return [...filteredEntries].sort((a, b) => {
      let valA: any;
      let valB: any;

      if (sortColumn === 'date') {
        valA = new Date(a.date).getTime();
        valB = new Date(b.date).getTime();
      } else if (sortColumn === 'canteenName') {
        valA = (a.canteenName || '').toLowerCase();
        valB = (b.canteenName || '').toLowerCase();
      } else if (sortColumn === 'normalSale') {
        valA = Number(a.normalSale) || 0;
        valB = Number(b.normalSale) || 0;
      } else if (sortColumn === 'tokenSale') {
        valA = Number(a.tokenSale) || 0;
        valB = Number(b.tokenSale) || 0;
      } else if (sortColumn === 'totalSale') {
        valA = (Number(a.normalSale) || 0) + (Number(a.tokenSale) || 0);
        valB = (Number(b.normalSale) || 0) + (Number(b.tokenSale) || 0);
      } else if (sortColumn === 'purchase') {
        valA = Number(a.purchase) || 0;
        valB = Number(b.purchase) || 0;
      } else if (sortColumn === 'expenses') {
        valA = Number(a.expenses) || 0;
        valB = Number(b.expenses) || 0;
      } else if (sortColumn === 'netAmount') {
        valA = (Number(a.normalSale) || 0) + (Number(a.tokenSale) || 0) - (Number(a.purchase) || 0) - (Number(a.expenses) || 0);
        valB = (Number(b.normalSale) || 0) + (Number(b.tokenSale) || 0) - (Number(b.purchase) || 0) - (Number(b.expenses) || 0);
      } else {
        valA = new Date(a.date).getTime();
        valB = new Date(b.date).getTime();
      }

      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredEntries, sortColumn, sortOrder]);

  // Derived sub-lists from sorted entries
  const sortedSalesEntries = useMemo(() => {
    return sortedEntries.filter(
      (e) => (Number(e.normalSale) || 0) > 0 || (Number(e.tokenSale) || 0) > 0
    );
  }, [sortedEntries]);

  const sortedExpensesEntries = useMemo(() => {
    return sortedEntries.filter((e) => (Number(e.expenses) || 0) > 0);
  }, [sortedEntries]);

  const sortedPurchasesEntries = useMemo(() => {
    return sortedEntries.filter((e) => (Number(e.purchase) || 0) > 0);
  }, [sortedEntries]);

  // Filtered & Sorted Cash Deposits
  const sortedDeposits = useMemo(() => {
    const list = (cashDeposits || []).filter((deposit) => {
      const matchesCanteen = isCanteenMatch(deposit, selectedCanteenId, canteens);
      const q = searchTerm.toLowerCase().trim();
      const matchesSearch =
        !q ||
        (deposit.canteenName && deposit.canteenName.toLowerCase().includes(q)) ||
        deposit.date.includes(q) ||
        (deposit.depositTo && deposit.depositTo.toLowerCase().includes(q)) ||
        (deposit.bankName && deposit.bankName.toLowerCase().includes(q)) ||
        (deposit.slipNumber && deposit.slipNumber.toLowerCase().includes(q)) ||
        (deposit.depositedBy && deposit.depositedBy.toLowerCase().includes(q)) ||
        (deposit.remarks && deposit.remarks.toLowerCase().includes(q));
      return matchesCanteen && matchesSearch;
    });

    return list.sort((a, b) => {
      let valA: any;
      let valB: any;
      if (sortColumn === 'amount') {
        valA = Number(a.amount) || 0;
        valB = Number(b.amount) || 0;
      } else if (sortColumn === 'canteenName') {
        valA = (a.canteenName || '').toLowerCase();
        valB = (b.canteenName || '').toLowerCase();
      } else {
        valA = new Date(a.date).getTime();
        valB = new Date(b.date).getTime();
      }
      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
  }, [cashDeposits, selectedCanteenId, canteens, searchTerm, sortColumn, sortOrder]);

  // Financial Metrics
  const totalGrossSales = useMemo(() => {
    return filteredEntries.reduce((sum, e) => sum + (Number(e.totalSale) || 0), 0);
  }, [filteredEntries]);

  const totalNormalCash = useMemo(() => {
    return filteredEntries.reduce((sum, e) => sum + (Number(e.normalSale) || 0), 0);
  }, [filteredEntries]);

  const totalTokenSales = useMemo(() => {
    return filteredEntries.reduce((sum, e) => sum + (Number(e.tokenSale) || 0), 0);
  }, [filteredEntries]);

  const totalPurchases = useMemo(() => {
    return filteredEntries.reduce((sum, e) => sum + (Number(e.purchase) || 0), 0);
  }, [filteredEntries]);

  const totalExpenses = useMemo(() => {
    return filteredEntries.reduce((sum, e) => sum + (Number(e.expenses) || 0), 0);
  }, [filteredEntries]);

  const totalDeposited = useMemo(() => {
    return sortedDeposits.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);
  }, [sortedDeposits]);

  // Cash Reconciliation
  const totalOutflows = totalExpenses + totalPurchases;
  const baqiCashSale = totalNormalCash - totalOutflows;
  const remainingCashInHand = baqiCashSale - totalDeposited;

  // Calculate In-Hand Cash for a specific Canteen
  const getCanteenInHandCash = (targetCanteenId: string): number => {
    const cNormal = (entries || [])
      .filter((e) => isCanteenMatch(e, targetCanteenId, canteens))
      .reduce((sum, e) => sum + (Number(e.normalSale) || 0), 0);
    const cOutflows = (entries || [])
      .filter((e) => isCanteenMatch(e, targetCanteenId, canteens))
      .reduce((sum, e) => sum + (Number(e.expenses) || 0) + (Number(e.purchase) || 0), 0);
    const cDeposits = (cashDeposits || [])
      .filter((d) => isCanteenMatch(d, targetCanteenId, canteens))
      .reduce((sum, d) => sum + (Number(d.amount) || 0), 0);
    return (cNormal - cOutflows) - cDeposits;
  };

  const openAddModal = (mode: EntryFormMode = 'full') => {
    setEditingEntry(null);
    setEntryMode(mode);
    setDate(new Date().toISOString().split('T')[0]);
    setCanteenId(
      selectedCanteenId !== 'all' ? selectedCanteenId : activeCanteens[0]?.id || ''
    );
    setNormalSale(0);
    setTokenSale(0);
    setPurchase(0);
    setExpenses(0);
    setExpenseNote('');
    setRemarks('');
    setModalOpen(true);
  };

  const openEditModal = (entry: DailyEntry) => {
    setEditingEntry(entry);
    setEntryMode('full');
    setDate(entry.date);
    setCanteenId(entry.canteenId);
    setNormalSale(entry.normalSale);
    setTokenSale(entry.tokenSale);
    setPurchase(entry.purchase);
    setExpenses(entry.expenses);
    setExpenseNote(entry.expenseNote || '');
    setRemarks(entry.remarks || '');
    setModalOpen(true);
  };

  const handleSubmitEntry = (e: React.FormEvent) => {
    e.preventDefault();
    const selectedCanteen = canteens.find((c) => c.id === canteenId);
    const canteenName = selectedCanteen ? selectedCanteen.name : 'Unknown';

    let finalNormalSale = typeof normalSale === 'number' ? normalSale : 0;
    let finalTokenSale = typeof tokenSale === 'number' ? tokenSale : 0;
    let finalPurchase = typeof purchase === 'number' ? purchase : 0;
    let finalExpenses = typeof expenses === 'number' ? expenses : 0;

    if (!editingEntry) {
      if (entryMode === 'sales') {
        finalPurchase = 0;
        finalExpenses = 0;
      } else if (entryMode === 'expense') {
        finalNormalSale = 0;
        finalTokenSale = 0;
        finalPurchase = 0;
      } else if (entryMode === 'purchase') {
        finalNormalSale = 0;
        finalTokenSale = 0;
        finalExpenses = 0;
      }
    }

    const entryData = {
      date,
      canteenId,
      canteenName,
      normalSale: finalNormalSale,
      tokenSale: finalTokenSale,
      purchase: finalPurchase,
      expenses: finalExpenses,
      expenseNote: expenseNote.trim() || undefined,
      remarks: remarks.trim() || undefined,
    };

    if (editingEntry) {
      onEditEntry(editingEntry.id, entryData);
    } else {
      onAddEntry(entryData);
    }

    setModalOpen(false);
    setEditingEntry(null);
    if (onCloseQuickModal) onCloseQuickModal();
  };

  // Deposit Actions
  const handleOpenAddDeposit = () => {
    setEditingDeposit(null);
    setDepositFormError('');
    setDepositForm({
      date: new Date().toISOString().split('T')[0],
      canteenId:
        selectedCanteenId !== 'all' ? selectedCanteenId : activeCanteens[0]?.id || '',
      amount: '',
      depositTo: 'Bank Account',
      bankName: '',
      slipNumber: '',
      depositedBy: '',
      receivedBy: '',
      remarks: '',
    });
    setDepositModalOpen(true);
  };

  const handleOpenEditDeposit = (deposit: CanteenCashDeposit) => {
    setEditingDeposit(deposit);
    setDepositFormError('');
    setDepositForm({
      date: deposit.date,
      canteenId: deposit.canteenId,
      amount: deposit.amount.toString(),
      depositTo: deposit.depositTo || 'Bank Account',
      bankName: deposit.bankName || '',
      slipNumber: deposit.slipNumber || '',
      depositedBy: deposit.depositedBy || '',
      receivedBy: deposit.receivedBy || '',
      remarks: deposit.remarks || '',
    });
    setDepositModalOpen(true);
  };

  const handleSubmitDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(depositForm.amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setDepositFormError('Please enter a valid deposit amount.');
      return;
    }

    setDepositFormError('');
    const canteenObj = canteens.find((c) => c.id === depositForm.canteenId);
    const canteenName = canteenObj ? canteenObj.name : 'Branch';

    if (editingDeposit && onEditCashDeposit) {
      onEditCashDeposit(editingDeposit.id, {
        date: depositForm.date,
        canteenId: depositForm.canteenId,
        canteenName,
        amount: numAmount,
        depositTo: depositForm.depositTo,
        bankName: depositForm.bankName.trim() || undefined,
        slipNumber: depositForm.slipNumber.trim() || undefined,
        depositedBy: depositForm.depositedBy.trim() || undefined,
        receivedBy: depositForm.receivedBy.trim() || undefined,
        remarks: depositForm.remarks.trim() || undefined,
      });
    } else if (onAddCashDeposit) {
      onAddCashDeposit({
        date: depositForm.date,
        canteenId: depositForm.canteenId,
        canteenName,
        amount: numAmount,
        depositTo: depositForm.depositTo,
        bankName: depositForm.bankName.trim() || undefined,
        slipNumber: depositForm.slipNumber.trim() || undefined,
        depositedBy: depositForm.depositedBy.trim() || undefined,
        receivedBy: depositForm.receivedBy.trim() || undefined,
        remarks: depositForm.remarks.trim() || undefined,
      });
    }

    setDepositModalOpen(false);
    setEditingDeposit(null);
  };

  // Export handlers
  const handleExportCurrentTabExcel = () => {
    if (activeTab === 'sales') {
      const exportData = sortedSalesEntries.map((e, idx) => ({
        'Sr #': idx + 1,
        'Date': formatDisplayDate(e.date),
        'Branch': e.canteenName,
        'Cash Sales (Counter)': e.normalSale,
        'Token Sales (Monthly)': e.tokenSale,
        'Total Sales': (e.normalSale || 0) + (e.tokenSale || 0),
        'Remarks': e.remarks || '',
      }));
      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sales');
      XLSX.writeFile(wb, `Sales_${new Date().toISOString().slice(0, 10)}.xlsx`);
    } else if (activeTab === 'expenses') {
      const exportData = sortedExpensesEntries.map((e, idx) => ({
        'Sr #': idx + 1,
        'Date': formatDisplayDate(e.date),
        'Branch': e.canteenName,
        'Expense Amount': e.expenses,
        'Expense Detail': e.expenseNote || '',
        'Remarks': e.remarks || '',
      }));
      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Expenses');
      XLSX.writeFile(wb, `Expenses_${new Date().toISOString().slice(0, 10)}.xlsx`);
    } else if (activeTab === 'purchases') {
      const exportData = sortedPurchasesEntries.map((e, idx) => ({
        'Sr #': idx + 1,
        'Date': formatDisplayDate(e.date),
        'Branch': e.canteenName,
        'Purchase Amount': e.purchase,
        'Supplier / Remarks': e.remarks || '',
      }));
      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Purchases');
      XLSX.writeFile(wb, `Purchases_${new Date().toISOString().slice(0, 10)}.xlsx`);
    } else if (activeTab === 'deposits') {
      const exportData = sortedDeposits.map((d, idx) => ({
        'Sr #': idx + 1,
        'Date': d.date,
        'Branch': d.canteenName,
        'Amount Deposited': d.amount,
        'Deposited To': d.depositTo,
        'Bank / Account': d.bankName || '',
        'Slip / Ref #': d.slipNumber || '',
        'Deposited By': d.depositedBy || '',
        'Received By': d.receivedBy || '',
        'Remarks': d.remarks || '',
      }));
      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Deposits');
      XLSX.writeFile(wb, `Cash_Deposits_${new Date().toISOString().slice(0, 10)}.xlsx`);
    } else {
      const exportData = sortedEntries.map((e, idx) => ({
        'Sr #': idx + 1,
        'Date': e.date,
        'Branch': e.canteenName,
        'Cash Sales': e.normalSale,
        'Token Sales': e.tokenSale,
        'Total Sales': e.totalSale,
        'Purchases': e.purchase,
        'Expenses': e.expenses,
        'Net Amount': e.netAmount,
        'Expense Details': e.expenseNote || '',
        'Remarks': e.remarks || '',
      }));
      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'All Daily Entries');
      XLSX.writeFile(wb, `All_Daily_Entries_${new Date().toISOString().slice(0, 10)}.xlsx`);
    }
  };

  // Process pasted Excel rows
  const handleProcessImport = () => {
    if (!pastedText.trim()) return;

    const targetCanteen = canteens.find((c) => c.id === canteenId) || activeCanteens[0];
    if (!targetCanteen) return;

    const lines = pastedText.trim().split('\n');
    const dateGroups: Record<string, { totalAmount: number; notes: string[] }> = {};

    lines.forEach((line) => {
      const parts = line.split('\t').map((p) => p.trim());
      if (parts.length >= 2) {
        let dateStr = parts[0];
        let descStr = parts.length >= 3 ? parts[1] : 'Excel Expense';
        let amtStr = parts.length >= 3 ? parts[2] : parts[1];

        const cleanAmt = parseFloat(amtStr.replace(/[^0-9.-]+/g, ''));
        if (isNaN(cleanAmt)) return;

        let isoDate = new Date().toISOString().split('T')[0];
        try {
          const parsedD = new Date(dateStr);
          if (!isNaN(parsedD.getTime())) {
            isoDate = parsedD.toISOString().split('T')[0];
          }
        } catch (err) {
          // fallback
        }

        if (!dateGroups[isoDate]) {
          dateGroups[isoDate] = { totalAmount: 0, notes: [] };
        }

        dateGroups[isoDate].totalAmount += cleanAmt;
        dateGroups[isoDate].notes.push(`${descStr} (${cleanAmt.toLocaleString()})`);
      }
    });

    Object.entries(dateGroups).forEach(([dStr, data]) => {
      onAddEntry({
        date: dStr,
        canteenId: targetCanteen.id,
        canteenName: targetCanteen.name,
        normalSale: 0,
        tokenSale: 0,
        purchase: 0,
        expenses: data.totalAmount,
        expenseNote: data.notes.join(' | '),
        remarks: 'Imported Excel Expenses',
      });
    });

    setPastedText('');
    setImportModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-16 max-w-7xl mx-auto">
      {/* 1. Header & Actions */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Receipt className="w-6 h-6 text-emerald-600" />
            <span>Daily Sales & Operational Expenses</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Track daily counter cash sales, token sales, purchases, operating expenses, and bank deposits
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap self-start md:self-auto">
          <button
            onClick={handleOpenAddDeposit}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
          >
            <Landmark className="w-4 h-4 text-indigo-200" />
            <span>+ Record Cash Deposit</span>
          </button>

          <button
            onClick={() => openAddModal('full')}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Record Daily Entry</span>
          </button>

          <button
            onClick={() => setImportModalOpen(true)}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-slate-600" />
            <span>Import</span>
          </button>

          <button
            onClick={handleExportCurrentTabExcel}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Download Excel for current view"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Excel</span>
          </button>
        </div>
      </div>

      {/* 2. Reconciliation & Cash Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Card 1: Normal Cash Sale */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Cash Sales (Counter)
          </span>
          <p className="text-xl font-black text-slate-900 mt-1 font-mono">
            {formatCurrency(totalNormalCash, currencySymbol)}
          </p>
          <span className="text-[10px] text-emerald-600 font-medium mt-0.5 block">
            Counter cash received
          </span>
        </div>

        {/* Card 2: Total Expenses & Outflows */}
        <div className="bg-white p-3.5 rounded-2xl border border-rose-200 bg-rose-50/20 shadow-xs">
          <span className="text-[11px] font-bold text-rose-600 uppercase tracking-wider block">
            Expenses & Stock
          </span>
          <p className="text-xl font-black text-rose-700 mt-1 font-mono">
            −{formatCurrency(totalOutflows, currencySymbol)}
          </p>
          <span className="text-[10px] text-rose-500 font-medium mt-0.5 block">
            Deducted from cash sales
          </span>
        </div>

        {/* Card 3: Net Cash Balance */}
        <div className="bg-emerald-50/80 p-3.5 rounded-2xl border border-emerald-300 shadow-xs text-emerald-950">
          <span className="text-[11px] font-extrabold text-emerald-800 uppercase tracking-wider block">
            Net Cash Balance
          </span>
          <p className="text-xl font-black text-emerald-900 mt-1 font-mono">
            {formatCurrency(baqiCashSale, currencySymbol)}
          </p>
          <span className="text-[10px] text-emerald-700 font-semibold mt-0.5 block">
            Cash Sales − Expenses
          </span>
        </div>

        {/* Card 4: Token Sale */}
        <div className="bg-purple-50/60 p-3.5 rounded-2xl border border-purple-200 shadow-xs">
          <span className="text-[11px] font-bold text-purple-700 uppercase tracking-wider block">
            Token Sales (Monthly)
          </span>
          <p className="text-xl font-black text-purple-900 mt-1 font-mono">
            {formatCurrency(totalTokenSales, currencySymbol)}
          </p>
          <span className="text-[10px] text-purple-600 font-medium mt-0.5 block">
            Separate account • Clears monthly
          </span>
        </div>

        {/* Card 5: Deposited */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Deposited (Bank/HQ)
          </span>
          <p className="text-xl font-black text-indigo-700 mt-1 font-mono">
            {formatCurrency(totalDeposited, currencySymbol)}
          </p>
          <span className="text-[10px] text-slate-400 mt-0.5 block">
            {sortedDeposits.length} deposit transaction{sortedDeposits.length !== 1 ? 's' : ''}
          </span>
        </div>

        {/* Card 6: Remaining Cash in Hand */}
        <div
          className={`p-3.5 rounded-2xl border shadow-xs ${
            remainingCashInHand >= 0
              ? 'bg-amber-50/80 border-amber-300 text-amber-950'
              : 'bg-rose-50/80 border-rose-300 text-rose-950'
          }`}
        >
          <span className="text-[11px] font-bold uppercase tracking-wider block text-amber-900">
            Cash in Hand
          </span>
          <p
            className={`text-xl font-black mt-1 font-mono ${
              remainingCashInHand >= 0 ? 'text-amber-900' : 'text-rose-700'
            }`}
          >
            {formatCurrency(remainingCashInHand, currencySymbol)}
          </p>
          <span className="text-[10px] text-amber-800 font-medium mt-0.5 block">
            Net Cash − Deposited
          </span>
        </div>
      </div>

      {/* 3. Navigation Tabs */}
      <div className="flex border-b border-slate-200 gap-2 sm:gap-4 overflow-x-auto text-sm font-semibold pb-0.5">
        <button
          onClick={() => setActiveTab('all')}
          className={`pb-3 px-2 border-b-2 transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'all'
              ? 'border-slate-900 text-slate-900 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileText className="w-4 h-4 text-slate-600" />
          <span>All Entries ({filteredEntries.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('sales')}
          className={`pb-3 px-2 border-b-2 transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'sales'
              ? 'border-emerald-600 text-emerald-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Receipt className="w-4 h-4 text-emerald-600" />
          <span>Sales Only ({sortedSalesEntries.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('expenses')}
          className={`pb-3 px-2 border-b-2 transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'expenses'
              ? 'border-rose-600 text-rose-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Wallet className="w-4 h-4 text-rose-600" />
          <span>Expenses Only ({sortedExpensesEntries.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('purchases')}
          className={`pb-3 px-2 border-b-2 transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'purchases'
              ? 'border-amber-600 text-amber-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ShoppingBag className="w-4 h-4 text-amber-600" />
          <span>Purchases Only ({sortedPurchasesEntries.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('deposits')}
          className={`pb-3 px-2 border-b-2 transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'deposits'
              ? 'border-indigo-600 text-indigo-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Landmark className="w-4 h-4 text-indigo-600" />
          <span>Bank Deposits ({sortedDeposits.length})</span>
        </button>
      </div>

      {/* 4. Search and Sort Controls Row */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder={
              activeTab === 'sales'
                ? 'Search sales entries by date, branch, or remarks...'
                : activeTab === 'expenses'
                ? 'Search expenses by date, branch, item detail (e.g. Vegetables, Gas), or remarks...'
                : activeTab === 'purchases'
                ? 'Search purchases by date, branch, or remarks...'
                : activeTab === 'deposits'
                ? 'Search deposits by date, branch, bank name, slip number, or remarks...'
                : 'Search all records by date, branch, expense note, or remarks...'
            }
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-2 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs font-medium"
          />
        </div>

        {/* Intuitive Sort Dropdown */}
        <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-1.5 shadow-xs shrink-0 self-end sm:self-auto">
          <ArrowUpDown className="w-4 h-4 text-slate-500" />
          <span className="text-xs font-bold text-slate-500 whitespace-nowrap">Sort:</span>
          <select
            value={`${sortColumn}-${sortOrder}`}
            onChange={(e) => {
              const [col, ord] = e.target.value.split('-') as [SortColumn, SortOrder];
              setSortColumn(col);
              setSortOrder(ord);
            }}
            className="bg-transparent text-xs font-bold text-slate-800 focus:outline-none cursor-pointer"
          >
            <option value="date-desc">Date: Newest First</option>
            <option value="date-asc">Date: Oldest First</option>
            <option value="normalSale-desc">Highest Cash Sale</option>
            <option value="expenses-desc">Highest Expenses</option>
            <option value="purchase-desc">Highest Purchase</option>
            <option value="netAmount-desc">Highest Net Balance</option>
            <option value="canteenName-asc">Branch Name (A–Z)</option>
          </select>
        </div>
      </div>

      {/* 5A. TAB CONTENT: ALL IN ONE CONSOLIDATED TABLE */}
      {activeTab === 'all' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between flex-wrap gap-3 bg-slate-50/70">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-slate-200 text-slate-800 flex items-center justify-center font-bold">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <span>Combined Ledger</span>
                  <span className="text-xs bg-slate-200 text-slate-800 px-2 py-0.5 rounded-full font-semibold">
                    {sortedEntries.length} entries
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Sales, purchases, expenses, and net balances in a single unified view
                </p>
              </div>
            </div>

            <button
              onClick={() => openAddModal('full')}
              className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>+ Record Daily Entry</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 text-slate-600 font-bold text-xs uppercase tracking-wider border-b border-slate-200 select-none">
                <tr>
                  <th
                    onClick={() => handleSort('date')}
                    className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                  >
                    <div className="flex items-center gap-1">
                      <span>Date</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('canteenName')}
                    className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                  >
                    <div className="flex items-center gap-1">
                      <span>Branch</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('normalSale')}
                    className="py-3 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Cash Sales</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('tokenSale')}
                    className="py-3 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Token Sales</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('totalSale')}
                    className="py-3 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Total Sales</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('purchase')}
                    className="py-3 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Purchases</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('expenses')}
                    className="py-3 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Expenses</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th
                    onClick={() => handleSort('netAmount')}
                    className="py-3 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors whitespace-nowrap"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Net Balance</span>
                      <ArrowUpDown className="w-3 h-3 text-slate-400" />
                    </div>
                  </th>
                  <th className="py-3 px-4">Expense Details / Remarks</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sortedEntries.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="py-14 text-center">
                      <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-3 border border-emerald-100 shadow-xs">
                        <Receipt className="w-8 h-8" />
                      </div>
                      <p className="font-extrabold text-slate-800 text-base">No Daily Entries Found</p>
                      <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                        Click below to record counter cash collections, token sales, stock purchases, and expenses.
                      </p>
                      <button
                        onClick={() => openAddModal('full')}
                        className="mt-4 inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs transition-colors cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>+ Record Daily Entry</span>
                      </button>
                    </td>
                  </tr>
                ) : (
                  sortedEntries.map((entry) => (
                    <tr key={entry.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-slate-900 whitespace-nowrap">
                        {formatDisplayDate(entry.date)}
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-800 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <Building2 className="w-3.5 h-3.5 text-slate-400" />
                          <span>{entry.canteenName}</span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-right font-semibold text-slate-800 font-mono tabular-nums">
                        {formatCurrency(entry.normalSale, currencySymbol)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-semibold text-purple-700 font-mono tabular-nums">
                        {Number(entry.tokenSale) > 0 ? formatCurrency(entry.tokenSale, currencySymbol) : '—'}
                      </td>
                      <td className="py-3.5 px-4 text-right font-black text-slate-950 font-mono tabular-nums">
                        {formatCurrency(entry.totalSale, currencySymbol)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-semibold text-amber-700 font-mono tabular-nums">
                        {Number(entry.purchase) > 0 ? formatCurrency(entry.purchase, currencySymbol) : '—'}
                      </td>
                      <td className="py-3.5 px-4 text-right font-semibold text-rose-700 font-mono tabular-nums">
                        {Number(entry.expenses) > 0 ? formatCurrency(entry.expenses, currencySymbol) : '—'}
                      </td>
                      <td className="py-3.5 px-4 text-right font-black font-mono tabular-nums">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-lg text-xs ${
                            entry.netAmount >= 0
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : 'bg-rose-50 text-rose-800 border border-rose-200'
                          }`}
                        >
                          {formatCurrency(entry.netAmount, currencySymbol)}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-500 max-w-xs truncate">
                        {entry.expenseNote && (
                          <span className="block text-slate-800 font-medium truncate">
                            {entry.expenseNote}
                          </span>
                        )}
                        {entry.remarks && (
                          <span className="block text-slate-400 italic truncate">
                            {entry.remarks}
                          </span>
                        )}
                        {!entry.expenseNote && !entry.remarks && <span className="text-slate-300">—</span>}
                      </td>
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => openEditModal(entry)}
                            className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                            title="Edit"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteTargetId(entry.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              {sortedEntries.length > 0 && (
                <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                  <tr>
                    <td colSpan={2} className="py-3.5 px-4 text-slate-700">
                      Total ({sortedEntries.length} entries)
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-slate-900">
                      {formatCurrency(totalNormalCash, currencySymbol)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-purple-800">
                      {formatCurrency(totalTokenSales, currencySymbol)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-slate-950 text-base">
                      {formatCurrency(totalGrossSales, currencySymbol)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-amber-800">
                      {formatCurrency(totalPurchases, currencySymbol)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-rose-800">
                      {formatCurrency(totalExpenses, currencySymbol)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-emerald-800 text-base">
                      {formatCurrency(
                        totalGrossSales - totalPurchases - totalExpenses,
                        currencySymbol
                      )}
                    </td>
                    <td colSpan={2}></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      )}

      {/* 5B. TAB CONTENT: SALES ONLY TABLE */}
      {activeTab === 'sales' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between flex-wrap gap-3 bg-emerald-50/30">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                  <Receipt className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                    <span>Sales Records</span>
                    <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-semibold">
                      {sortedSalesEntries.length} entries
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Daily counter cash sales and monthly token khata sales
                  </p>
                </div>
              </div>

              <button
                onClick={() => openAddModal('sales')}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>+ Record Sale Entry</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-50 text-slate-600 font-bold text-xs uppercase tracking-wider border-b border-slate-200 select-none">
                  <tr>
                    <th
                      onClick={() => handleSort('date')}
                      className="py-3.5 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>Date</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('canteenName')}
                      className="py-3.5 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>Branch</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('normalSale')}
                      className="py-3.5 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center justify-end gap-1">
                        <span>Cash Sales (Counter)</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('tokenSale')}
                      className="py-3.5 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center justify-end gap-1">
                        <span>Token Sales (Monthly)</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('totalSale')}
                      className="py-3.5 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center justify-end gap-1">
                        <span>Total Combined Sales</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th className="py-3.5 px-4">Remarks</th>
                    <th className="py-3.5 px-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sortedSalesEntries.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center">
                        <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-3 border border-emerald-100 shadow-xs">
                          <Receipt className="w-7 h-7" />
                        </div>
                        <p className="font-extrabold text-slate-800 text-base">No Sales Records Found</p>
                        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                          Click below to add counter cash sales or monthly token sales.
                        </p>
                        <button
                          onClick={() => openAddModal('sales')}
                          className="mt-3.5 inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs transition-colors cursor-pointer"
                        >
                          <Plus className="w-4 h-4" />
                          <span>+ Record Sale Entry</span>
                        </button>
                      </td>
                    </tr>
                  ) : (
                    sortedSalesEntries.map((entry) => (
                      <tr key={entry.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-4 font-bold text-slate-900 whitespace-nowrap">
                          {formatDisplayDate(entry.date)}
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-slate-800 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <Building2 className="w-3.5 h-3.5 text-slate-400" />
                            <span>{entry.canteenName}</span>
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-right font-semibold text-slate-900 font-mono tabular-nums">
                          {formatCurrency(entry.normalSale, currencySymbol)}
                        </td>
                        <td className="py-3.5 px-4 text-right font-semibold text-purple-700 font-mono tabular-nums">
                          {Number(entry.tokenSale) > 0 ? formatCurrency(entry.tokenSale, currencySymbol) : '—'}
                        </td>
                        <td className="py-3.5 px-4 text-right font-black text-emerald-700 font-mono tabular-nums text-base">
                          {formatCurrency(entry.totalSale, currencySymbol)}
                        </td>
                        <td className="py-3.5 px-4 text-xs text-slate-500 max-w-xs truncate">
                          {entry.remarks ? (
                            <span className="text-slate-600 italic">{entry.remarks}</span>
                          ) : (
                            <span className="text-slate-300">—</span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => openEditModal(entry)}
                              className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                              title="Edit"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setDeleteTargetId(entry.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title="Delete"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                {sortedSalesEntries.length > 0 && (
                  <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                    <tr>
                      <td colSpan={2} className="py-3.5 px-4 text-slate-700">
                        Total Sales ({sortedSalesEntries.length} entries)
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-slate-900 text-sm">
                        {formatCurrency(
                          sortedSalesEntries.reduce((sum, e) => sum + (Number(e.normalSale) || 0), 0),
                          currencySymbol
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-purple-800 text-sm">
                        {formatCurrency(
                          sortedSalesEntries.reduce((sum, e) => sum + (Number(e.tokenSale) || 0), 0),
                          currencySymbol
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-emerald-800 text-base font-black">
                        {formatCurrency(
                          sortedSalesEntries.reduce((sum, e) => sum + (Number(e.totalSale) || 0), 0),
                          currencySymbol
                        )}
                      </td>
                      <td colSpan={2}></td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 5C. TAB CONTENT: EXPENSES ONLY TABLE */}
      {activeTab === 'expenses' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between flex-wrap gap-3 bg-rose-50/30">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
                  <Wallet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                    <span>Operating Expenses</span>
                    <span className="text-xs bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full font-semibold">
                      {sortedExpensesEntries.length} entries
                    </span>
                  </h3>
                  <p className="text-xs text-rose-700 font-medium">
                    Daily branch expenses (Vegetables, Gas, Ice, Repairs, etc.) deducted from cash sales
                  </p>
                </div>
              </div>

              <button
                onClick={() => openAddModal('expense')}
                className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>+ Record Expense</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-50 text-slate-600 font-bold text-xs uppercase tracking-wider border-b border-slate-200 select-none">
                  <tr>
                    <th
                      onClick={() => handleSort('date')}
                      className="py-3.5 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>Date</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('canteenName')}
                      className="py-3.5 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>Branch</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('expenses')}
                      className="py-3.5 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center justify-end gap-1">
                        <span>Expense Amount</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th className="py-3.5 px-4">Expense Details / Item Name</th>
                    <th className="py-3.5 px-4">Remarks</th>
                    <th className="py-3.5 px-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sortedExpensesEntries.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center">
                        <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-3 border border-rose-100 shadow-xs">
                          <Wallet className="w-7 h-7" />
                        </div>
                        <p className="font-extrabold text-slate-800 text-base">No Expense Records Found</p>
                        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                          Click below to add daily canteen operating expenses (vegetables, gas, ice, maintenance, etc.).
                        </p>
                        <button
                          onClick={() => openAddModal('expense')}
                          className="mt-3.5 inline-flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs transition-colors cursor-pointer"
                        >
                          <Plus className="w-4 h-4" />
                          <span>+ Record Expense</span>
                        </button>
                      </td>
                    </tr>
                  ) : (
                    sortedExpensesEntries.map((entry) => (
                      <tr key={entry.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-4 font-bold text-slate-900 whitespace-nowrap">
                          {formatDisplayDate(entry.date)}
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-slate-800 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <Building2 className="w-3.5 h-3.5 text-slate-400" />
                            <span>{entry.canteenName}</span>
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-right font-black text-rose-700 font-mono tabular-nums text-base">
                          {formatCurrency(entry.expenses, currencySymbol)}
                        </td>
                        <td className="py-3.5 px-4 text-xs font-semibold text-slate-800">
                          {entry.expenseNote ? (
                            <span className="bg-slate-100 text-slate-800 px-2 py-1 rounded-md">
                              {entry.expenseNote}
                            </span>
                          ) : (
                            <span className="text-slate-300">—</span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-xs text-slate-500 max-w-xs truncate">
                          {entry.remarks ? (
                            <span className="text-slate-600 italic">{entry.remarks}</span>
                          ) : (
                            <span className="text-slate-300">—</span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => openEditModal(entry)}
                              className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                              title="Edit"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setDeleteTargetId(entry.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title="Delete"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                {sortedExpensesEntries.length > 0 && (
                  <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                    <tr>
                      <td colSpan={2} className="py-3.5 px-4 text-slate-700">
                        Total Expenses ({sortedExpensesEntries.length} entries)
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-rose-700 text-base font-black">
                        {formatCurrency(
                          sortedExpensesEntries.reduce((sum, e) => sum + (Number(e.expenses) || 0), 0),
                          currencySymbol
                        )}
                      </td>
                      <td colSpan={3}></td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 5D. TAB CONTENT: PURCHASES ONLY TABLE */}
      {activeTab === 'purchases' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between flex-wrap gap-3 bg-amber-50/30">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                  <ShoppingBag className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                    <span>Stock Purchases</span>
                    <span className="text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-semibold">
                      {sortedPurchasesEntries.length} entries
                    </span>
                  </h3>
                  <p className="text-xs text-amber-800 font-medium">
                    Inventory and wholesale supplier purchases for canteens
                  </p>
                </div>
              </div>

              <button
                onClick={() => openAddModal('purchase')}
                className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>+ Record Stock Purchase</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-50 text-slate-600 font-bold text-xs uppercase tracking-wider border-b border-slate-200 select-none">
                  <tr>
                    <th
                      onClick={() => handleSort('date')}
                      className="py-3.5 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>Date</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('canteenName')}
                      className="py-3.5 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>Branch</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('purchase')}
                      className="py-3.5 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center justify-end gap-1">
                        <span>Purchase Amount</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th className="py-3.5 px-4">Remarks / Supplier Details</th>
                    <th className="py-3.5 px-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sortedPurchasesEntries.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center">
                        <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-3 border border-amber-100 shadow-xs">
                          <ShoppingBag className="w-7 h-7" />
                        </div>
                        <p className="font-extrabold text-slate-800 text-base">No Purchase Records Found</p>
                        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                          Click below to record stock and inventory purchases.
                        </p>
                        <button
                          onClick={() => openAddModal('purchase')}
                          className="mt-3.5 inline-flex items-center gap-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs transition-colors cursor-pointer"
                        >
                          <Plus className="w-4 h-4" />
                          <span>+ Record Stock Purchase</span>
                        </button>
                      </td>
                    </tr>
                  ) : (
                    sortedPurchasesEntries.map((entry) => (
                      <tr key={entry.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-4 font-bold text-slate-900 whitespace-nowrap">
                          {formatDisplayDate(entry.date)}
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-slate-800 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <Building2 className="w-3.5 h-3.5 text-slate-400" />
                            <span>{entry.canteenName}</span>
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-right font-black text-amber-800 font-mono tabular-nums text-base">
                          {formatCurrency(entry.purchase, currencySymbol)}
                        </td>
                        <td className="py-3.5 px-4 text-xs text-slate-600">
                          {entry.remarks ? (
                            <span>{entry.remarks}</span>
                          ) : (
                            <span className="text-slate-300">—</span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => openEditModal(entry)}
                              className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                              title="Edit"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setDeleteTargetId(entry.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title="Delete"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                {sortedPurchasesEntries.length > 0 && (
                  <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                    <tr>
                      <td colSpan={2} className="py-3.5 px-4 text-slate-700">
                        Total Purchases ({sortedPurchasesEntries.length} entries)
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-amber-800 text-base font-black">
                        {formatCurrency(
                          sortedPurchasesEntries.reduce((sum, e) => sum + (Number(e.purchase) || 0), 0),
                          currencySymbol
                        )}
                      </td>
                      <td colSpan={2}></td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 5E. TAB CONTENT: BANK DEPOSITS REGISTER */}
      {activeTab === 'deposits' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between flex-wrap gap-2 bg-indigo-50/20">
              <div className="flex items-center gap-2">
                <Landmark className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Canteen Cash Deposits to Bank / Head Office
                </h3>
              </div>
              <button
                onClick={handleOpenAddDeposit}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-3.5 py-1.5 rounded-xl flex items-center gap-1.5 transition cursor-pointer shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add Deposit</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-50 text-slate-600 font-bold text-xs uppercase tracking-wider border-b border-slate-200 select-none">
                  <tr>
                    <th
                      onClick={() => handleSort('date')}
                      className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>Date</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th
                      onClick={() => handleSort('canteenName')}
                      className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        <span>Branch</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th className="py-3 px-4">Deposited To</th>
                    <th className="py-3 px-4">Bank / Account Title</th>
                    <th className="py-3 px-4">Slip / Ref #</th>
                    <th className="py-3 px-4">Deposited By</th>
                    <th
                      onClick={() => handleSort('amount')}
                      className="py-3 px-4 text-right cursor-pointer hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center justify-end gap-1">
                        <span>Amount Deposited</span>
                        <ArrowUpDown className="w-3 h-3 text-slate-400" />
                      </div>
                    </th>
                    <th className="py-3 px-4">Remarks</th>
                    <th className="py-3 px-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sortedDeposits.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-slate-400">
                        <Landmark className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                        <p className="font-bold text-slate-600">No cash deposits recorded yet</p>
                        <p className="text-xs text-slate-400 mt-0.5">
                          When canteens deposit accumulated cash into the bank or send it to head office, record it here.
                        </p>
                        <button
                          onClick={handleOpenAddDeposit}
                          className="mt-3 inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition cursor-pointer shadow-xs"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Record First Deposit</span>
                        </button>
                      </td>
                    </tr>
                  ) : (
                    sortedDeposits.map((dep) => (
                      <tr key={dep.id} className="hover:bg-slate-50/80 transition">
                        <td className="py-3 px-4 font-bold text-slate-900 whitespace-nowrap">
                          {formatDisplayDate(dep.date)}
                        </td>
                        <td className="py-3 px-4 font-semibold text-slate-800 whitespace-nowrap">
                          {dep.canteenName}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                            {dep.depositTo}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-700 font-medium whitespace-nowrap">
                          {dep.bankName || '-'}
                        </td>
                        <td className="py-3 px-4 text-slate-600 font-mono whitespace-nowrap">
                          {dep.slipNumber || '-'}
                        </td>
                        <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                          {dep.depositedBy || '-'}
                        </td>
                        <td className="py-3 px-4 text-right font-black text-indigo-900 font-mono text-sm whitespace-nowrap">
                          {formatCurrency(dep.amount, currencySymbol)}
                        </td>
                        <td className="py-3 px-4 text-slate-500 italic max-w-xs truncate">
                          {dep.remarks || '-'}
                        </td>
                        <td className="py-3 px-4 text-center whitespace-nowrap">
                          {depositConfirmDeleteId === dep.id ? (
                            <div className="flex items-center justify-center gap-1">
                              <button
                                onClick={() => {
                                  if (onDeleteCashDeposit) onDeleteCashDeposit(dep.id);
                                  setDepositConfirmDeleteId(null);
                                }}
                                className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] rounded transition cursor-pointer shadow-xs"
                              >
                                Delete
                              </button>
                              <button
                                onClick={() => setDepositConfirmDeleteId(null)}
                                className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] rounded transition cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center justify-center gap-1">
                              <button
                                onClick={() => handleOpenEditDeposit(dep)}
                                className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition cursor-pointer"
                                title="Edit deposit"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => setDepositConfirmDeleteId(dep.id)}
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                                title="Delete deposit"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                {sortedDeposits.length > 0 && (
                  <tfoot className="bg-slate-50 font-bold border-t border-slate-200 text-slate-800">
                    <tr>
                      <td colSpan={6} className="py-3 px-4">
                        Total Cash Deposited ({sortedDeposits.length} Records)
                      </td>
                      <td className="py-3 px-4 text-right font-black text-indigo-700 text-sm font-mono">
                        {formatCurrency(totalDeposited, currencySymbol)}
                      </td>
                      <td colSpan={2}></td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 6. MODAL: Record / Edit Cash Deposit */}
      {depositModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-indigo-50 text-indigo-700">
                  <Landmark className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {editingDeposit ? 'Edit Cash Deposit' : 'Record Canteen Cash Deposit'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Record cash deposited into bank account or handed over to head office / owner
                  </p>
                </div>
              </div>
              <button
                onClick={() => setDepositModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {depositFormError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{depositFormError}</span>
              </div>
            )}

            <form onSubmit={handleSubmitDeposit} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={depositForm.date}
                    onChange={(e) => setDepositForm({ ...depositForm, date: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Branch *
                  </label>
                  <select
                    value={depositForm.canteenId}
                    onChange={(e) => setDepositForm({ ...depositForm, canteenId: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none cursor-pointer"
                  >
                    {activeCanteens.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Current in-hand cash indicator */}
              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200/80 flex items-center justify-between text-xs">
                <span className="font-semibold text-amber-900">
                  Current In-Hand Cash at this branch:
                </span>
                <span className="font-black text-amber-950 font-mono">
                  {formatCurrency(getCanteenInHandCash(depositForm.canteenId), currencySymbol)}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Deposit Amount ({currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    placeholder="e.g. 500000"
                    value={depositForm.amount}
                    onChange={(e) => setDepositForm({ ...depositForm, amount: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-black text-indigo-900 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Deposited To *
                  </label>
                  <select
                    value={depositForm.depositTo}
                    onChange={(e) => setDepositForm({ ...depositForm, depositTo: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none cursor-pointer"
                  >
                    <option value="Bank Account">Bank Account</option>
                    <option value="Head Office / Owner">Head Office / Owner</option>
                    <option value="Cashier">Cashier</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Bank / Account Title
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Meezan Bank, HBL, Allied Bank"
                    value={depositForm.bankName}
                    onChange={(e) => setDepositForm({ ...depositForm, bankName: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Deposit Slip / Ref #
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Slip # 40921, Online Txn ID"
                    value={depositForm.slipNumber}
                    onChange={(e) => setDepositForm({ ...depositForm, slipNumber: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Deposited By (Staff / Incharge)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Adeel, Kashif"
                    value={depositForm.depositedBy}
                    onChange={(e) =>
                      setDepositForm({ ...depositForm, depositedBy: e.target.value })
                    }
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Received By (Bank / Owner)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Bank Teller, Owner Handover"
                    value={depositForm.receivedBy}
                    onChange={(e) => setDepositForm({ ...depositForm, receivedBy: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Remarks / Notes (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Deposited accumulated cash from weekend sales"
                  value={depositForm.remarks}
                  onChange={(e) => setDepositForm({ ...depositForm, remarks: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2.5 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setDepositModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-xs cursor-pointer transition"
                >
                  {editingDeposit ? 'Update Deposit' : 'Save Deposit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 7. MODAL: Record / Edit Daily Entry */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl max-w-xl w-full my-8 overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className={`p-6 text-white flex items-center justify-between ${
              entryMode === 'sales'
                ? 'bg-emerald-950'
                : entryMode === 'expense'
                ? 'bg-rose-950'
                : entryMode === 'purchase'
                ? 'bg-amber-950'
                : 'bg-slate-900'
            }`}>
              <div className="flex items-center gap-2.5">
                {entryMode === 'sales' && <Receipt className="w-6 h-6 text-emerald-400" />}
                {entryMode === 'expense' && <Wallet className="w-6 h-6 text-rose-400" />}
                {entryMode === 'purchase' && <ShoppingBag className="w-6 h-6 text-amber-400" />}
                {entryMode === 'full' && <FileText className="w-6 h-6 text-slate-300" />}
                <div>
                  <h2 className="text-lg font-bold">
                    {editingEntry
                      ? 'Edit Entry'
                      : entryMode === 'sales'
                      ? 'Record Sales Entry'
                      : entryMode === 'expense'
                      ? 'Record Daily Expense'
                      : entryMode === 'purchase'
                      ? 'Record Stock Purchase'
                      : 'Record Daily Entry (Combined)'}
                  </h2>
                  <p className="text-xs text-slate-300">
                    {entryMode === 'sales'
                      ? 'Enter counter cash sales and monthly token sales'
                      : entryMode === 'expense'
                      ? 'Enter daily operational expenses (Vegetables, Gas, Ice, Repairs, etc.)'
                      : entryMode === 'purchase'
                      ? 'Enter stock and inventory supplies purchases'
                      : 'Record sales, inventory purchases, and daily expenses simultaneously'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setModalOpen(false);
                  if (onCloseQuickModal) onCloseQuickModal();
                }}
                className="text-slate-400 hover:text-white font-bold p-1 rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Category Mode Switcher */}
            <div className="px-6 pt-4 pb-1">
              <div className="grid grid-cols-4 bg-slate-100 p-1 rounded-xl text-xs font-bold gap-1 border border-slate-200">
                <button
                  type="button"
                  onClick={() => setEntryMode('sales')}
                  className={`py-2 px-1.5 rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer text-center ${
                    entryMode === 'sales'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Receipt className="w-3.5 h-3.5 hidden sm:inline" />
                  <span>Sales</span>
                </button>
                <button
                  type="button"
                  onClick={() => setEntryMode('expense')}
                  className={`py-2 px-1.5 rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer text-center ${
                    entryMode === 'expense'
                      ? 'bg-rose-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Wallet className="w-3.5 h-3.5 hidden sm:inline" />
                  <span>Expense</span>
                </button>
                <button
                  type="button"
                  onClick={() => setEntryMode('purchase')}
                  className={`py-2 px-1.5 rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer text-center ${
                    entryMode === 'purchase'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ShoppingBag className="w-3.5 h-3.5 hidden sm:inline" />
                  <span>Purchase</span>
                </button>
                <button
                  type="button"
                  onClick={() => setEntryMode('full')}
                  className={`py-2 px-1.5 rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer text-center ${
                    entryMode === 'full'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5 hidden sm:inline" />
                  <span>Combined</span>
                </button>
              </div>
            </div>

            <form onSubmit={handleSubmitEntry} className="p-6 pt-3 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Branch *
                  </label>
                  <select
                    value={canteenId}
                    onChange={(e) => setCanteenId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                  >
                    {activeCanteens.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.code})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* 1. SALES ONLY MODE */}
              {entryMode === 'sales' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                        Cash Sales (Counter) ({currencySymbol}) *
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={normalSale}
                        onChange={(e) =>
                          setNormalSale(e.target.value === '' ? '' : parseFloat(e.target.value))
                        }
                        placeholder="0"
                        className="w-full bg-slate-50 border border-emerald-300 rounded-xl p-2.5 text-sm font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                      />
                      <span className="text-[10px] text-slate-500 mt-1 block">
                        Direct cash collected at counter
                      </span>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase text-purple-800 mb-1">
                        Token Sales (Monthly Khata) ({currencySymbol})
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={tokenSale}
                        onChange={(e) =>
                          setTokenSale(e.target.value === '' ? '' : parseFloat(e.target.value))
                        }
                        placeholder="0"
                        className="w-full bg-slate-50 border border-purple-200 rounded-xl p-2.5 text-sm font-bold text-purple-900 focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono"
                      />
                      <span className="text-[10px] text-purple-600 mt-1 block">
                        Monthly token ledger sale (if any)
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs font-bold text-emerald-900">
                    <span>Total Calculated Sales:</span>
                    <span className="text-base font-black font-mono">
                      {formatCurrency(totalSalePreview, currencySymbol)}
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                      Remarks / Sale Notes (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Afternoon shift extra cash, event sale"
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                </div>
              )}

              {/* 2. EXPENSE ONLY MODE */}
              {entryMode === 'expense' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold uppercase text-rose-800 mb-1">
                      Daily Expense Amount ({currencySymbol}) *
                    </label>
                    <input
                      type="number"
                      min="1"
                      step="any"
                      required
                      value={expenses}
                      onChange={(e) =>
                        setExpenses(e.target.value === '' ? '' : parseFloat(e.target.value))
                      }
                      placeholder="e.g. 2500"
                      className="w-full bg-rose-50/50 border border-rose-300 rounded-xl p-3 text-base font-black text-rose-950 focus:outline-none focus:ring-2 focus:ring-rose-500 font-mono"
                    />
                    <span className="text-[11px] text-rose-700 font-medium mt-1 block">
                      This amount is deducted directly from counter cash sales
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-700 mb-1">
                      Expense Details / Item Name *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Vegetables 1,500, Gas cylinder 4,200, Ice 300"
                      value={expenseNote}
                      onChange={(e) => setExpenseNote(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500 font-medium"
                    />

                    {/* Quick Suggestion Chips */}
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      <span className="text-[10px] text-slate-400 font-semibold self-center mr-1">Quick Tag:</span>
                      {[
                        'Vegetables',
                        'Gas Cylinder',
                        'Ice',
                        'Milk',
                        'Chicken / Meat',
                        'Tea & Sugar',
                        'Repairs & Maintenance',
                        'Transport & Fare',
                      ].map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => {
                            setExpenseNote((prev) => (prev ? `${prev}, ${tag}` : tag));
                          }}
                          className="bg-slate-100 hover:bg-rose-100 hover:text-rose-800 text-slate-600 text-[10px] font-bold px-2 py-1 rounded-md transition cursor-pointer border border-slate-200"
                        >
                          + {tag}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                      Remarks (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="Paid by cashier / incharge note"
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500 font-medium"
                    />
                  </div>
                </div>
              )}

              {/* 3. PURCHASE ONLY MODE */}
              {entryMode === 'purchase' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold uppercase text-amber-800 mb-1">
                      Stock Purchase Amount (Inventory Supplies) ({currencySymbol}) *
                    </label>
                    <input
                      type="number"
                      min="1"
                      step="any"
                      required
                      value={purchase}
                      onChange={(e) =>
                        setPurchase(e.target.value === '' ? '' : parseFloat(e.target.value))
                      }
                      placeholder="e.g. 15000"
                      className="w-full bg-amber-50/50 border border-amber-300 rounded-xl p-3 text-base font-black text-amber-950 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                    />
                    <span className="text-[11px] text-amber-800 font-medium mt-1 block">
                      Inventory and stock purchases for the canteen
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                      Remarks / Supplier / Items Details (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Wholesale market purchase, Supplier: Al-Madina Traders"
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
                    />
                  </div>
                </div>
              )}

              {/* 4. FULL COMBINED MODE */}
              {entryMode === 'full' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                        Cash Sales ({currencySymbol})
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={normalSale}
                        onChange={(e) =>
                          setNormalSale(e.target.value === '' ? '' : parseFloat(e.target.value))
                        }
                        placeholder="0"
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase text-purple-800 mb-1">
                        Token Sales ({currencySymbol})
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={tokenSale}
                        onChange={(e) =>
                          setTokenSale(e.target.value === '' ? '' : parseFloat(e.target.value))
                        }
                        placeholder="0"
                        className="w-full bg-slate-50 border border-purple-200 rounded-xl p-2.5 text-sm font-bold text-purple-900 focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono"
                      />
                    </div>
                  </div>

                  {/* Total Sales Preview */}
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl flex items-center justify-between text-xs font-bold text-blue-900">
                    <span>Calculated Total Sales:</span>
                    <span className="text-base font-black font-mono">
                      {formatCurrency(totalSalePreview, currencySymbol)}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase text-amber-800 mb-1">
                        Stock Purchases ({currencySymbol})
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={purchase}
                        onChange={(e) =>
                          setPurchase(e.target.value === '' ? '' : parseFloat(e.target.value))
                        }
                        placeholder="0"
                        className="w-full bg-slate-50 border border-amber-200 rounded-xl p-2.5 text-sm font-bold text-amber-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase text-rose-800 mb-1">
                        Daily Expenses ({currencySymbol})
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={expenses}
                        onChange={(e) =>
                          setExpenses(e.target.value === '' ? '' : parseFloat(e.target.value))
                        }
                        placeholder="0"
                        className="w-full bg-slate-50 border border-rose-200 rounded-xl p-2.5 text-sm font-bold text-rose-900 focus:outline-none focus:ring-2 focus:ring-rose-500 font-mono"
                      />
                    </div>
                  </div>

                  {/* Net Balance Preview */}
                  <div
                    className={`p-3 rounded-xl flex items-center justify-between text-xs font-bold border ${
                      netAmountPreview >= 0
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                        : 'bg-rose-50 border-rose-200 text-rose-900'
                    }`}
                  >
                    <span>Calculated Net Balance:</span>
                    <span className="text-base font-black font-mono">
                      {formatCurrency(netAmountPreview, currencySymbol)}
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                      Expense Details / Note (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Chicken 29,150, Milk 23,625, Vegetables 6,720"
                      value={expenseNote}
                      onChange={(e) => setExpenseNote(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                      General Remarks (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="Additional operational remarks"
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                </div>
              )}

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setModalOpen(false);
                    if (onCloseQuickModal) onCloseQuickModal();
                  }}
                  className="px-4 py-2.5 text-sm font-semibold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2.5 text-sm font-semibold text-white rounded-xl cursor-pointer shadow-xs transition ${
                    entryMode === 'sales'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : entryMode === 'expense'
                      ? 'bg-rose-600 hover:bg-rose-700'
                      : entryMode === 'purchase'
                      ? 'bg-amber-600 hover:bg-amber-700'
                      : 'bg-slate-900 hover:bg-slate-800'
                  }`}
                >
                  {editingEntry
                    ? 'Save Changes'
                    : entryMode === 'sales'
                    ? 'Save Sales Entry'
                    : entryMode === 'expense'
                    ? 'Save Expense'
                    : entryMode === 'purchase'
                    ? 'Save Stock Purchase'
                    : 'Save Daily Entry'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 8. MODAL: Import Excel Modal */}
      {importModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full my-8 overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <FileSpreadsheet className="w-6 h-6 text-amber-400" />
                <div>
                  <h2 className="text-lg font-bold">Import / Paste Excel Data</h2>
                  <p className="text-xs text-slate-300">
                    Paste rows copied directly from Excel or Google Sheets
                  </p>
                </div>
              </div>
              <button
                onClick={() => setImportModalOpen(false)}
                className="text-slate-400 hover:text-white font-bold p-1 rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Target Branch *
                </label>
                <select
                  value={canteenId}
                  onChange={(e) => setCanteenId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
                >
                  {activeCanteens.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Paste Excel Rows (Date, Description, Amount)
                </label>
                <textarea
                  rows={8}
                  placeholder={`Example format (copy rows directly from Excel):\n01-Aug-2026\tChicken Bill\t29,150\n01-Aug-2026\tMilk Bill\t23,625\n02-Aug-2026\tVegetables Bill\t6,720`}
                  value={pastedText}
                  onChange={(e) => setPastedText(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <p className="text-xs text-slate-500 mt-1">
                  Rows will automatically be grouped by date into Daily Entries.
                </p>
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setImportModalOpen(false)}
                  className="px-4 py-2.5 text-sm font-semibold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleProcessImport}
                  disabled={!pastedText.trim()}
                  className="px-5 py-2.5 text-sm font-semibold text-white bg-amber-600 rounded-xl hover:bg-amber-700 disabled:opacity-50 cursor-pointer shadow-xs flex items-center gap-2"
                >
                  <Upload className="w-4 h-4" />
                  <span>Process & Import Records</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 9. Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={deleteTargetId !== null}
        title="Delete Daily Entry?"
        message="Are you sure you want to delete this daily canteen sales and expenses entry?"
        confirmLabel="Delete Record"
        onConfirm={() => {
          if (deleteTargetId) onDeleteEntry(deleteTargetId);
          setDeleteTargetId(null);
        }}
        onClose={() => setDeleteTargetId(null)}
      />
    </div>
  );
};

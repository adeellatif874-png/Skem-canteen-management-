import React, { useState } from 'react';
import {
  Users,
  Plus,
  Search,
  Edit2,
  Trash2,
  Phone,
  Calendar,
  Building2,
  CheckCircle2,
  XCircle,
  Briefcase,
  Power,
  DollarSign,
  Wallet,
  AlertTriangle,
  Printer,
  MessageSquare,
} from 'lucide-react';
import { Staff, StaffStatus, Canteen, AttendanceRecord, StaffFinancialRecord } from '../types';
import { formatCurrency, isCanteenMatch } from '../lib/storage';
import { ConfirmModal } from './ConfirmModal';
import { SalarySlipModal, sendWhatsAppSalarySlip } from './SalarySlipModal';

interface StaffViewProps {
  staffList: Staff[];
  canteens: Canteen[];
  selectedCanteenId: string;
  currencySymbol?: string;
  attendanceRecords?: AttendanceRecord[];
  staffFinancials?: StaffFinancialRecord[];
  onAddStaff: (staff: Omit<Staff, 'id' | 'createdAt'>) => void;
  onEditStaff: (id: string, staff: Partial<Staff>) => void;
  onDeleteStaff: (id: string) => void;
}

export function calculateStaffSalaryBreakdown(
  staff: Staff,
  attendanceRecords: AttendanceRecord[] = [],
  staffFinancials: StaffFinancialRecord[] = []
) {
  const basicSalary = staff.monthlySalary || 0;

  // Calculate attendance deductions
  const staffAttendance = attendanceRecords.filter((a) => a.staffId === staff.id);
  const leaveDays = staffAttendance.filter((a) => a.status === 'Leave').length;
  const absentDays = staffAttendance.filter((a) => a.status === 'Absent').length;
  const totalAbsentLeaveDays = leaveDays + absentDays;

  // Daily rate based on standard 30-day month
  const dailyRate = basicSalary > 0 ? basicSalary / 30 : 0;
  const leaveDeduction = Math.round(dailyRate * totalAbsentLeaveDays);

  // Financials
  const staffFins = staffFinancials.filter((f) => f.staffId === staff.id);
  const totalAdvance = staffFins
    .filter((f) => f.type === 'Advance')
    .reduce((sum, f) => sum + (f.amount || 0), 0);
  const totalPenalty = staffFins
    .filter((f) => f.type === 'Penalty')
    .reduce((sum, f) => sum + (f.amount || 0), 0);

  const totalDeductions = leaveDeduction + totalAdvance + totalPenalty;
  const remainingSalary = basicSalary - totalDeductions;

  return {
    basicSalary,
    leaveDays,
    absentDays,
    totalAbsentLeaveDays,
    leaveDeduction,
    totalAdvance,
    totalPenalty,
    totalDeductions,
    remainingSalary,
  };
}

const DESIGNATION_PRESETS = [
  'General Worker',
  'Main Chef / Cook',
  'Assistant Cook',
  'Counter Cashier',
  'Tea Master',
  'Helper',
  'Cleaning Staff',
  'Canteen Manager',
  'Store Keeper',
];

export const StaffView: React.FC<StaffViewProps> = ({
  staffList,
  canteens,
  selectedCanteenId,
  currencySymbol = 'Rs.',
  attendanceRecords = [],
  staffFinancials = [],
  onAddStaff,
  onEditStaff,
  onDeleteStaff,
}) => {
  const activeCanteens = canteens.filter((c) => c.status === 'active');

  const [searchTerm, setSearchTerm] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<Staff | null>(null);

  // Form
  const [name, setName] = useState('');
  const [canteenId, setCanteenId] = useState('');
  const [phone, setPhone] = useState('');
  const [designation, setDesignation] = useState('');
  const [monthlySalary, setMonthlySalary] = useState<number | ''>('');
  const [joiningDate, setJoiningDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [status, setStatus] = useState<StaffStatus>('active');

  // Delete modal
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);
  const [selectedSlipStaff, setSelectedSlipStaff] = useState<Staff | null>(null);

  const filteredStaff = staffList.filter((s) => {
    const matchesCanteen = isCanteenMatch(s, selectedCanteenId, canteens);
    const matchesSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.designation.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (s.phone && s.phone.includes(searchTerm)) ||
      (s.canteenName && s.canteenName.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCanteen && matchesSearch;
  });

  const openAddModal = () => {
    setEditingStaff(null);
    setName('');
    setCanteenId(activeCanteens[0]?.id || canteens[0]?.id || '');
    setPhone('');
    setDesignation('Main Cook');
    setMonthlySalary('');
    setJoiningDate(new Date().toISOString().split('T')[0]);
    setStatus('active');
    setModalOpen(true);
  };

  const openEditModal = (staff: Staff) => {
    setEditingStaff(staff);
    setName(staff.name);
    setCanteenId(staff.canteenId);
    setPhone(staff.phone || '');
    setDesignation(staff.designation);
    setMonthlySalary(staff.monthlySalary !== undefined ? staff.monthlySalary : '');
    setJoiningDate(staff.joiningDate);
    setStatus(staff.status);
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const canteenObj = canteens.find((c) => c.id === canteenId);
    if (!name.trim() || !canteenObj) return;

    const numSalary = typeof monthlySalary === 'number' ? monthlySalary : 0;

    const data = {
      name: name.trim(),
      canteenId,
      canteenName: canteenObj.name,
      phone: phone.trim(),
      designation: designation.trim() || 'Staff Worker',
      monthlySalary: numSalary,
      joiningDate,
      status,
    };

    if (editingStaff) {
      onEditStaff(editingStaff.id, data);
    } else {
      onAddStaff(data);
    }
    setModalOpen(false);
  };

  const handleToggleStatus = (staff: Staff) => {
    const nextStatus: StaffStatus = staff.status === 'active' ? 'inactive' : 'active';
    onEditStaff(staff.id, { status: nextStatus });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="w-7 h-7 text-emerald-600" />
            <span>Staff Directory & Salary Ledger</span>
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage staff members, set custom designations, set total monthly salary & view net remaining salary
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-xs transition-colors cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Staff</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          placeholder="Search staff members by name, designation, canteen or phone number..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-white border border-slate-200 rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs font-medium"
        />
      </div>

      {/* Staff Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredStaff.length === 0 ? (
          <div className="col-span-full bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-400">
            <Users className="w-12 h-12 mx-auto mb-3 opacity-30 text-slate-500" />
            <p className="text-base font-semibold text-slate-600">No Staff Members Found</p>
            <p className="text-xs text-slate-400 mt-1">
              Click "Add New Staff" to register canteen staff members with custom designation and salary.
            </p>
          </div>
        ) : (
          filteredStaff.map((staff) => {
            const breakdown = calculateStaffSalaryBreakdown(
              staff,
              attendanceRecords,
              staffFinancials
            );

            return (
              <div
                key={staff.id}
                className={`bg-white rounded-2xl border transition-all shadow-xs flex flex-col justify-between overflow-hidden ${
                  staff.status === 'active'
                    ? 'border-slate-200 hover:border-emerald-300 hover:shadow-md'
                    : 'border-slate-200 bg-slate-50/60 opacity-80'
                }`}
              >
                <div className="p-5 space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-base shrink-0">
                        {staff.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <h3 className="text-base font-bold text-slate-900">{staff.name}</h3>
                        <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
                          <Briefcase className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="font-semibold text-slate-700">{staff.designation}</span>
                        </div>
                      </div>
                    </div>

                    <span
                      className={`px-2 py-0.5 text-xs font-bold rounded-full flex items-center gap-1 shrink-0 ${
                        staff.status === 'active'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {staff.status === 'active' ? (
                        <>
                          <CheckCircle2 className="w-3 h-3" /> Active
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3 h-3" /> Inactive
                        </>
                      )}
                    </span>
                  </div>

                  {/* Staff Info */}
                  <div className="pt-2 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-slate-400 shrink-0" />
                      <span className="font-semibold text-slate-800">{staff.canteenName}</span>
                    </div>

                    {staff.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                        <span>{staff.phone}</span>
                      </div>
                    )}

                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
                      <span>Joined: {staff.joiningDate}</span>
                    </div>
                  </div>

                  {/* Salary & Remaining Balance Box */}
                  <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 font-semibold flex items-center gap-1">
                        <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                        Total Monthly Salary:
                      </span>
                      <span className="font-black text-slate-900">
                        {formatCurrency(breakdown.basicSalary, currencySymbol)}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-1 text-[11px] text-slate-600 pt-1.5 border-t border-slate-200/60">
                      <div>
                        <span className="text-slate-400 block text-[9px] uppercase font-bold">Leaves Cut</span>
                        <span className="font-bold text-amber-700">
                          {formatCurrency(breakdown.leaveDeduction, currencySymbol)}
                        </span>
                        <span className="text-[9px] text-slate-400 block">({breakdown.totalAbsentLeaveDays} days)</span>
                      </div>

                      <div>
                        <span className="text-slate-400 block text-[9px] uppercase font-bold">Advances</span>
                        <span className="font-bold text-indigo-700">
                          {formatCurrency(breakdown.totalAdvance, currencySymbol)}
                        </span>
                      </div>

                      <div>
                        <span className="text-slate-400 block text-[9px] uppercase font-bold">Penalties</span>
                        <span className="font-bold text-rose-700">
                          {formatCurrency(breakdown.totalPenalty, currencySymbol)}
                        </span>
                      </div>
                    </div>

                    {/* Net Remaining Salary */}
                    <div className="bg-emerald-900 text-white rounded-lg p-2 flex items-center justify-between text-xs mt-1">
                      <span className="font-bold flex items-center gap-1 text-emerald-200">
                        <Wallet className="w-3.5 h-3.5 text-emerald-400" />
                        Remaining Salary:
                      </span>
                      <span className="font-black text-sm text-emerald-300">
                        {formatCurrency(breakdown.remainingSalary, currencySymbol)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action Bar */}
                <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
                  <button
                    onClick={() => handleToggleStatus(staff)}
                    className={`flex items-center gap-1.5 font-semibold transition-colors cursor-pointer ${
                      staff.status === 'active'
                        ? 'text-slate-600 hover:text-slate-900'
                        : 'text-emerald-600 hover:text-emerald-700'
                    }`}
                  >
                    <Power className="w-3.5 h-3.5" />
                    <span>{staff.status === 'active' ? 'Deactivate' : 'Activate'}</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => sendWhatsAppSalarySlip(staff, breakdown, currencySymbol, staff.canteenName)}
                      className="px-2 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer shadow-2xs"
                      title="Send Salary Slip to Employee on WhatsApp"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>WhatsApp</span>
                    </button>
                    <button
                      onClick={() => setSelectedSlipStaff(staff)}
                      className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                      title="View & Print Salary Slip"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Slip</span>
                    </button>
                    <button
                      onClick={() => openEditModal(staff)}
                      className="p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-200 transition-colors cursor-pointer"
                      title="Edit Staff"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setDeleteTargetId(staff.id)}
                      className="p-1.5 rounded-lg text-rose-600 hover:text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer"
                      title="Delete Staff"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal Form */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white z-10">
              <h2 className="text-xl font-bold text-slate-900">
                {editingStaff ? 'Edit Staff Member' : 'Add New Staff Member'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm cursor-pointer p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mohammad Ali"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Canteen */}
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Assigned Canteen *
                </label>
                <select
                  required
                  value={canteenId}
                  onChange={(e) => setCanteenId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {activeCanteens.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.code})
                    </option>
                  ))}
                </select>
              </div>

              {/* Designation with Custom Text Input & Quick Preset Chips */}
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Designation / Role (Write Custom or Click Preset) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Write designation e.g. Main Chef, Counter Boy, Tea Master"
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                
                {/* Preset Chips */}
                <div className="mt-2 space-y-1">
                  <span className="text-[11px] text-slate-400 font-medium block">Quick presets (click to select):</span>
                  <div className="flex flex-wrap gap-1.5">
                    {DESIGNATION_PRESETS.map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setDesignation(preset)}
                        className={`text-[11px] font-semibold px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                          designation === preset
                            ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                            : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                        }`}
                      >
                        {preset}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Total Monthly Salary & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Total Monthly Salary ({currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="e.g. 35000"
                    value={monthlySalary}
                    onChange={(e) =>
                      setMonthlySalary(e.target.value === '' ? '' : Number(e.target.value))
                    }
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Basic monthly fixed salary
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Phone (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 0300-1234567"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Joining Date & Status */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Joining Date
                  </label>
                  <input
                    type="date"
                    required
                    value={joiningDate}
                    onChange={(e) => setJoiningDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as StaffStatus)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 text-sm font-semibold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 text-sm font-semibold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 cursor-pointer shadow-xs"
                >
                  {editingStaff ? 'Save Changes' : 'Register Staff'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmModal
        isOpen={deleteTargetId !== null}
        title="Delete Staff Member?"
        message="Are you sure you want to delete this staff record?"
        confirmLabel="Delete Staff"
        onConfirm={() => {
          if (deleteTargetId) onDeleteStaff(deleteTargetId);
          setDeleteTargetId(null);
        }}
        onClose={() => setDeleteTargetId(null)}
      />

      {/* Salary Slip Modal */}
      <SalarySlipModal
        isOpen={selectedSlipStaff !== null}
        onClose={() => setSelectedSlipStaff(null)}
        staff={selectedSlipStaff}
        canteen={canteens.find((c) => c.id === selectedSlipStaff?.canteenId)}
        currencySymbol={currencySymbol}
        attendanceRecords={attendanceRecords}
        staffFinancials={staffFinancials}
      />
    </div>
  );
};


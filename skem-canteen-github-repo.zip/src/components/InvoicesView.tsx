import React, { useState, useMemo } from 'react';
import {
  FileText,
  Plus,
  Search,
  Filter,
  Printer,
  Edit,
  Trash2,
  Copy,
  Download,
  Building2,
  Calendar,
  CheckCircle2,
  X,
  PlusCircle,
  Receipt,
  Eye,
  FileSpreadsheet,
  CreditCard,
  Clock,
  AlertTriangle,
} from 'lucide-react';
import { Invoice, InvoiceItem, Canteen, InvoiceChequePayment, ChequeStatus } from '../types';
import { InvoiceChequeModal } from './InvoiceChequeModal';
import { InvoiceChequesSection } from './InvoiceChequesSection';
import {
  calculateInvoiceTotals,
  numberToWords,
  exportInvoiceToExactExcel,
  exportAllInvoicesFormattedExcel,
  printInvoiceDocument,
  resolveBuyerAddress,
} from '../lib/invoiceUtils';
import { formatCurrency } from '../lib/storage';

interface InvoicesViewProps {
  invoices: Invoice[];
  invoiceChequePayments?: InvoiceChequePayment[];
  canteens: Canteen[];
  selectedCanteenId: string;
  onAddInvoice: (invoice: Omit<Invoice, 'id' | 'createdAt'>) => void;
  onUpdateInvoice: (invoice: Invoice) => void;
  onDeleteInvoice: (id: string) => void;
  onAddChequePayment?: (cheque: Omit<InvoiceChequePayment, 'id' | 'createdAt'>) => void;
  onUpdateChequePayment?: (cheque: InvoiceChequePayment) => void;
  onDeleteChequePayment?: (id: string) => void;
  currencySymbol: string;
}

export const InvoicesView: React.FC<InvoicesViewProps> = ({
  invoices = [],
  invoiceChequePayments = [],
  canteens = [],
  selectedCanteenId,
  onAddInvoice,
  onUpdateInvoice,
  onDeleteInvoice,
  onAddChequePayment,
  onUpdateChequePayment,
  onDeleteChequePayment,
  currencySymbol = 'Rs.',
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'invoices' | 'cheques'>('invoices');
  const [isChequeModalOpen, setIsChequeModalOpen] = useState(false);
  const [editingCheque, setEditingCheque] = useState<InvoiceChequePayment | null>(null);
  const [preselectedInvoiceIdForCheque, setPreselectedInvoiceIdForCheque] = useState<string | undefined>(undefined);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBranchFilter, setSelectedBranchFilter] = useState<string>(
    selectedCanteenId !== 'all' ? selectedCanteenId : 'all'
  );
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [previewInvoice, setPreviewInvoice] = useState<Invoice | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Settlement mapping from cheques to invoices
  const invoiceChequeSettlementMap = useMemo(() => {
    const map = new Map<string, { total: number; cheques: InvoiceChequePayment[] }>();
    (invoiceChequePayments || []).forEach((c) => {
      if (c.invoiceId && c.status !== 'Bounced' && c.status !== 'Cancelled') {
        const cur = map.get(c.invoiceId) || { total: 0, cheques: [] };
        cur.total += c.settledAmount || c.amount || 0;
        cur.cheques.push(c);
        map.set(c.invoiceId, cur);
      }
    });
    return map;
  }, [invoiceChequePayments]);

  const handleOpenAddCheque = (invoiceId?: string) => {
    setPreselectedInvoiceIdForCheque(invoiceId);
    setEditingCheque(null);
    setIsChequeModalOpen(true);
  };

  const handleOpenEditCheque = (cheque: InvoiceChequePayment) => {
    setEditingCheque(cheque);
    setPreselectedInvoiceIdForCheque(cheque.invoiceId);
    setIsChequeModalOpen(true);
  };

  const handleQuickUpdateChequeStatus = (cheque: InvoiceChequePayment, newStatus: ChequeStatus) => {
    if (!onUpdateChequePayment) return;
    const now = new Date().toISOString().split('T')[0];
    onUpdateChequePayment({
      ...cheque,
      status: newStatus,
      depositDate: newStatus === 'Deposited' || newStatus === 'Cleared' ? (cheque.depositDate || now) : cheque.depositDate,
      clearedDate: newStatus === 'Cleared' ? (cheque.clearedDate || now) : cheque.clearedDate,
    });
  };

  // Form State
  const [formData, setFormData] = useState<{
    invoiceNo: string;
    invoiceDate: string;
    canteenId: string;
    companyName: string;
    companyAddress: string;
    companyNtn: string;
    companyStrn: string;
    companyPhone: string;
    invoiceTitle: string;
    buyerName: string;
    buyerNtn: string;
    buyerStrn: string;
    buyerAddress: string;
    poNo: string;
    poDate: string;
    items: InvoiceItem[];
    notes: string;
    terms: string;
  }>({
    invoiceNo: '',
    invoiceDate: new Date().toISOString().split('T')[0],
    canteenId: selectedCanteenId !== 'all' ? selectedCanteenId : canteens[0]?.id || '',
    companyName: 'RNC ENTERPRISES',
    companyAddress: 'Second floor near zaika hotel jarranwala road, Khurrianwala',
    companyNtn: '121541-5',
    companyStrn: '2400690400146',
    companyPhone: '041-5489876 : 0300-8653676',
    invoiceTitle: 'SALES TAX INVOICE',
    buyerName: 'BEACON IMPEX (BEACON GENERAL)',
    buyerNtn: '2560721-9',
    buyerStrn: '08-01-3200-019-37',
    buyerAddress: 'P102 jail road Faisalabad',
    poNo: '',
    poDate: '',
    items: [
      {
        id: 'item-temp-1',
        sNo: 1,
        um: 'CF',
        grnDate: new Date().toISOString().split('T')[0],
        grnNo: '',
        particulars: '',
        qty: 1,
        rate: 0,
        amountWithoutGst: 0,
        gstRate: 18,
        gstAmount: 0,
        netAmount: 0,
      },
    ],
    notes: 'Goods once sold are non-refundable. Payment terms as agreed.',
    terms: 'Computerized Sales Tax Invoice generated in compliance with FBR sales tax rules.',
  });

  // Extract known buyers and their addresses/tax IDs from existing invoices for quick one-click autofill
  const knownBuyers = useMemo(() => {
    const map = new Map<string, { name: string; ntn: string; strn: string; address: string }>();
    map.set('BEACON IMPEX PVT LTD', {
      name: 'BEACON IMPEX PVT LTD',
      ntn: '2560721-9',
      strn: '08-01-3200-019-37',
      address: 'P102 jail road Faisalabad',
    });
    map.set('BEACON IMPEX (BEACON GENERAL)', {
      name: 'BEACON IMPEX (BEACON GENERAL)',
      ntn: '2560721-9',
      strn: '08-01-3200-019-37',
      address: 'P102 jail road Faisalabad',
    });
    (invoices || []).forEach((inv) => {
      if (inv.buyerName) {
        const key = inv.buyerName.trim().toUpperCase();
        if (!map.has(key)) {
          map.set(key, {
            name: inv.buyerName,
            ntn: inv.buyerNtn || '',
            strn: inv.buyerStrn || '',
            address: resolveBuyerAddress(inv.buyerAddress),
          });
        }
      }
    });
    return Array.from(map.values());
  }, [invoices]);

  // Filter Invoices
  const filteredInvoices = useMemo(() => {
    return invoices.filter((inv) => {
      // Branch filter
      if (selectedBranchFilter !== 'all') {
        if (inv.canteenId && inv.canteenId !== selectedBranchFilter) return false;
      }

      // Search filter
      if (searchTerm.trim() !== '') {
        const term = searchTerm.toLowerCase();
        const matchNo = inv.invoiceNo?.toLowerCase().includes(term);
        const matchBuyer = inv.buyerName?.toLowerCase().includes(term);
        const matchPo = inv.poNo?.toLowerCase().includes(term);
        const matchCompany = inv.companyName?.toLowerCase().includes(term);
        const matchParticulars = inv.items?.some((it) =>
          it.particulars?.toLowerCase().includes(term)
        );
        if (!matchNo && !matchBuyer && !matchPo && !matchCompany && !matchParticulars) {
          return false;
        }
      }

      return true;
    });
  }, [invoices, selectedBranchFilter, searchTerm]);

  // Statistics
  const stats = useMemo(() => {
    let totalInvoices = filteredInvoices.length;
    let totalAmountWithoutGst = 0;
    let totalGst = 0;
    let totalNet = 0;

    filteredInvoices.forEach((inv) => {
      totalAmountWithoutGst += inv.totalAmountWithoutGst || 0;
      totalGst += inv.totalGstAmount || 0;
      totalNet += inv.totalNetAmount || 0;
    });

    return {
      totalInvoices,
      totalAmountWithoutGst,
      totalGst,
      totalNet,
    };
  }, [filteredInvoices]);

  // Open Form for New Invoice
  const handleOpenNew = () => {
    // Generate next invoice number
    let nextNum = 1;
    if (invoices.length > 0) {
      const numbers = invoices
        .map((i) => parseInt(i.invoiceNo, 10))
        .filter((n) => !isNaN(n));
      if (numbers.length > 0) {
        nextNum = Math.max(...numbers) + 1;
      }
    }

    setEditingInvoice(null);
    setFormData({
      invoiceNo: nextNum.toString(),
      invoiceDate: new Date().toISOString().split('T')[0],
      canteenId: selectedCanteenId !== 'all' ? selectedCanteenId : canteens[0]?.id || '',
      companyName: 'RNC ENTERPRISES',
      companyAddress: 'Second floor near zaika hotel jarranwala road, Khurrianwala',
      companyNtn: '121541-5',
      companyStrn: '2400690400146',
      companyPhone: '041-5489876 : 0300-8653676',
      invoiceTitle: 'SALES TAX INVOICE',
      buyerName: 'BEACON IMPEX (BEACON GENERAL)',
      buyerNtn: '2560721-9',
      buyerStrn: '08-01-3200-019-37',
      buyerAddress: 'P102 jail road Faisalabad',
      poNo: '',
      poDate: '',
      items: [
        {
          id: `item-${Date.now()}-1`,
          sNo: 1,
          um: 'CF',
          grnDate: new Date().toISOString().split('T')[0],
          grnNo: '',
          particulars: '',
          qty: 1,
          rate: 0,
          amountWithoutGst: 0,
          gstRate: 18,
          gstAmount: 0,
          netAmount: 0,
        },
      ],
      notes: 'Goods once sold are non-refundable. Payment terms as agreed.',
      terms: 'Computerized Sales Tax Invoice generated in compliance with FBR sales tax rules.',
    });
    setIsFormOpen(true);
  };

  // Open Form for Edit
  const handleOpenEdit = (inv: Invoice) => {
    setEditingInvoice(inv);
    setFormData({
      invoiceNo: inv.invoiceNo,
      invoiceDate: inv.invoiceDate,
      canteenId: inv.canteenId || '',
      companyName: inv.companyName,
      companyAddress: inv.companyAddress,
      companyNtn: inv.companyNtn,
      companyStrn: inv.companyStrn,
      companyPhone: inv.companyPhone,
      invoiceTitle: inv.invoiceTitle || 'SALES TAX INVOICE',
      buyerName: inv.buyerName,
      buyerNtn: inv.buyerNtn,
      buyerStrn: inv.buyerStrn,
      buyerAddress: resolveBuyerAddress(inv.buyerAddress),
      poNo: inv.poNo || '',
      poDate: '',
      items: inv.items && inv.items.length > 0 ? inv.items : [],
      notes: inv.notes || '',
      terms: inv.terms || '',
    });
    setIsFormOpen(true);
  };

  // Duplicate Invoice
  const handleDuplicate = (inv: Invoice) => {
    let nextNum = 1;
    const numbers = invoices
      .map((i) => parseInt(i.invoiceNo, 10))
      .filter((n) => !isNaN(n));
    if (numbers.length > 0) {
      nextNum = Math.max(...numbers) + 1;
    }

    const duplicated: Omit<Invoice, 'id' | 'createdAt'> = {
      ...inv,
      invoiceNo: nextNum.toString(),
      invoiceDate: new Date().toISOString().split('T')[0],
      items: inv.items.map((it, idx) => ({
        ...it,
        id: `item-${Date.now()}-${idx}`,
      })),
    };

    onAddInvoice(duplicated);
  };

  // Line Item Handlers
  const handleItemChange = (index: number, field: keyof InvoiceItem, val: any) => {
    setFormData((prev) => {
      const newItems = [...prev.items];
      const item = { ...newItems[index], [field]: val };

      // Re-calculate row amounts
      const qty = Number(item.qty) || 0;
      const rate = Number(item.rate) || 0;
      const amountWithoutGst = qty * rate;
      const gstRate = Number(item.gstRate) || 0;
      const gstAmount = Math.round((amountWithoutGst * gstRate) / 100);
      const netAmount = amountWithoutGst + gstAmount;

      item.amountWithoutGst = amountWithoutGst;
      item.gstAmount = gstAmount;
      item.netAmount = netAmount;

      newItems[index] = item;
      return { ...prev, items: newItems };
    });
  };

  const handleAddItem = () => {
    setFormData((prev) => ({
      ...prev,
      items: [
        ...prev.items,
        {
          id: `item-${Date.now()}-${prev.items.length + 1}`,
          sNo: prev.items.length + 1,
          um: 'CF',
          grnDate: new Date().toISOString().split('T')[0],
          grnNo: '',
          particulars: '',
          qty: 1,
          rate: 0,
          amountWithoutGst: 0,
          gstRate: 18,
          gstAmount: 0,
          netAmount: 0,
        },
      ],
    }));
  };

  const handleRemoveItem = (index: number) => {
    if (formData.items.length <= 1) return;
    setFormData((prev) => {
      const newItems = prev.items.filter((_, idx) => idx !== index);
      // Re-index sNo
      const reindexed = newItems.map((it, idx) => ({ ...it, sNo: idx + 1 }));
      return { ...prev, items: reindexed };
    });
  };

  // Submit Invoice Form
  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.invoiceNo || !formData.buyerName) {
      alert('Please fill in Invoice Number and Buyer Name.');
      return;
    }

    const { totalQty, totalAmountWithoutGst, totalGstAmount, totalNetAmount, amountInWords } =
      calculateInvoiceTotals(formData.items);

    const targetCanteen = canteens.find((c) => c.id === formData.canteenId);
    const resolvedAddress = resolveBuyerAddress(formData.buyerAddress);

    if (editingInvoice) {
      onUpdateInvoice({
        ...editingInvoice,
        ...formData,
        buyerAddress: resolvedAddress,
        canteenName: targetCanteen ? targetCanteen.name : editingInvoice.canteenName,
        totalQty,
        totalAmountWithoutGst,
        totalGstAmount,
        totalNetAmount,
        amountInWords,
      });
    } else {
      onAddInvoice({
        ...formData,
        buyerAddress: resolvedAddress,
        canteenName: targetCanteen ? targetCanteen.name : 'RNC Electric Store',
        totalQty,
        totalAmountWithoutGst,
        totalGstAmount,
        totalNetAmount,
        amountInWords,
      });
    }

    setIsFormOpen(false);
  };

  // Export Invoices list to formatted Excel with individual sheets matching template
  const handleExportExcel = () => {
    if (filteredInvoices.length === 1) {
      exportInvoiceToExactExcel(filteredInvoices[0]);
    } else {
      exportAllInvoicesFormattedExcel(filteredInvoices);
    }
  };

  // Printable Invoice view
  const handlePrint = (invoiceToPrint?: Invoice) => {
    const target = invoiceToPrint || previewInvoice;
    if (target) {
      printInvoiceDocument(target);
    } else {
      window.print();
    }
  };

  // Calculated live form totals
  const liveFormTotals = useMemo(() => {
    return calculateInvoiceTotals(formData.items);
  }, [formData.items]);

  return (
    <div className="space-y-6 pb-12">
      {/* Printable CSS Hook */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #printable-invoice-modal, #printable-invoice-modal * {
            visibility: visible;
          }
          #printable-invoice-modal {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 0;
            background: white !important;
          }
          .no-print {
            display: none !important;
          }
        }
      `}</style>

      {/* Top Sub-Navigation Tabs: Tax Invoices vs Cheque Tracking */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSubTab('invoices')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
              activeSubTab === 'invoices'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Tax Invoices & Billing</span>
            <span
              className={`text-xs px-2 py-0.5 rounded-full ${
                activeSubTab === 'invoices' ? 'bg-slate-800 text-slate-300' : 'bg-slate-200 text-slate-600'
              }`}
            >
              {invoices.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('cheques')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
              activeSubTab === 'cheques'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Cheque Payments & Recovery</span>
            <span
              className={`text-xs px-2 py-0.5 rounded-full ${
                activeSubTab === 'cheques' ? 'bg-indigo-700 text-indigo-200' : 'bg-indigo-200 text-indigo-900'
              }`}
            >
              {(invoiceChequePayments || []).length}
            </span>
          </button>
        </div>

        {activeSubTab === 'invoices' && (
          <button
            onClick={() => handleOpenAddCheque()}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl border border-indigo-200 transition cursor-pointer"
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>+ Record Cheque</span>
          </button>
        )}
      </div>

      {activeSubTab === 'cheques' ? (
        <InvoiceChequesSection
          invoices={invoices}
          cheques={invoiceChequePayments || []}
          canteens={canteens}
          currencySymbol={currencySymbol}
          onOpenAddCheque={handleOpenAddCheque}
          onOpenEditCheque={handleOpenEditCheque}
          onDeleteCheque={(id) => onDeleteChequePayment && onDeleteChequePayment(id)}
          onQuickUpdateStatus={handleQuickUpdateChequeStatus}
        />
      ) : (
        <>
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">
              Sales Tax Invoices
            </h1>
            <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-0.5 rounded-full">
              FBR Format
            </span>
          </div>
          <p className="text-slate-500 text-sm mt-1">
            Generate, print, and track official GST Sales Tax Invoices & Delivery Vouchers
          </p>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button
            onClick={handleExportExcel}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-sm transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Excel Export</span>
          </button>

          <button
            onClick={handleOpenNew}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-sm shadow-sm transition-all active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Create Invoice</span>
          </button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Total Invoices
          </span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-black text-slate-800">{stats.totalInvoices}</span>
            <span className="text-xs font-semibold text-slate-500">Issued</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Amount W/O GST
          </span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-black text-slate-800">
              {formatCurrency(stats.totalAmountWithoutGst, currencySymbol)}
            </span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider">
            Total GST (18%)
          </span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-black text-emerald-700">
              {formatCurrency(stats.totalGst, currencySymbol)}
            </span>
          </div>
        </div>

        <div className="bg-emerald-900 text-white p-5 rounded-2xl shadow-sm">
          <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
            Total Net Billed
          </span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-black text-white">
              {formatCurrency(stats.totalNet, currencySymbol)}
            </span>
          </div>
        </div>
      </div>

      {/* Search & Branch Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by Invoice #, Buyer Name, PO #, or item description..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <Building2 className="w-4 h-4 text-slate-400 shrink-0" />
          <select
            value={selectedBranchFilter}
            onChange={(e) => setSelectedBranchFilter(e.target.value)}
            className="w-full md:w-auto px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">All Canteens / Stores</option>
            {canteens.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Invoices List Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredInvoices.length === 0 ? (
          <div className="py-16 text-center">
            <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-800">No Invoices Found</h3>
            <p className="text-sm text-slate-500 mt-1 max-w-sm mx-auto">
              Create your first official Sales Tax Invoice to print and manage your billing.
            </p>
            <button
              onClick={handleOpenNew}
              className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white font-semibold rounded-xl text-sm hover:bg-emerald-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Create Invoice Now</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                  <th className="py-3.5 px-4">Inv # & Date</th>
                  <th className="py-3.5 px-4">Buyer / Customer</th>
                  <th className="py-3.5 px-4">PO Details</th>
                  <th className="py-3.5 px-4">Items</th>
                  <th className="py-3.5 px-4 text-right">Amount (W/O GST)</th>
                  <th className="py-3.5 px-4 text-right">GST</th>
                  <th className="py-3.5 px-4 text-right">Net Amount</th>
                  <th className="py-3.5 px-4 text-center">Payment Status</th>
                  <th className="py-3.5 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-slate-900 bg-slate-100 px-2 py-0.5 rounded-lg border border-slate-200 text-xs">
                          #{inv.invoiceNo}
                        </span>
                      </div>
                      <span className="text-xs text-slate-500 block mt-0.5 font-medium">
                        {inv.invoiceDate}
                      </span>
                      <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200/60 mt-1 inline-block">
                        System Generated
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-800 block">{inv.buyerName}</span>
                      <span className="text-xs text-slate-500 block truncate max-w-[260px] mt-0.5" title={resolveBuyerAddress(inv.buyerAddress)}>
                        📍 {resolveBuyerAddress(inv.buyerAddress)}
                      </span>
                      <div className="text-xs text-slate-500 flex flex-wrap items-center gap-x-2 gap-y-0.5 mt-0.5">
                        {inv.buyerNtn && <span>NTN: {inv.buyerNtn}</span>}
                        {inv.buyerStrn && <span>STRN: {inv.buyerStrn}</span>}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      {inv.poNo ? (
                        <span className="font-semibold text-slate-700 text-xs bg-slate-100 px-2 py-1 rounded-md border border-slate-200 inline-block">
                          PO: {inv.poNo}
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400">-</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-slate-800">
                        {inv.items?.length || 0} items
                      </span>
                      <span className="text-xs text-slate-500 block truncate max-w-[160px]">
                        {inv.items?.[0]?.particulars || ''}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right font-medium text-slate-700">
                      {formatCurrency(inv.totalAmountWithoutGst, currencySymbol)}
                    </td>

                    <td className="py-3.5 px-4 text-right font-medium text-emerald-700">
                      {formatCurrency(inv.totalGstAmount, currencySymbol)}
                    </td>

                    <td className="py-3.5 px-4 text-right font-black text-slate-900">
                      {formatCurrency(inv.totalNetAmount, currencySymbol)}
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      {(() => {
                        const settlement = invoiceChequeSettlementMap.get(inv.id);
                        const settled = settlement?.total || 0;
                        const total = inv.totalNetAmount || 0;
                        const isPaid = settled >= total && total > 0;
                        const isPartial = settled > 0 && settled < total;
                        const balance = Math.max(0, total - settled);

                        if (isPaid) {
                          return (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Paid</span>
                            </span>
                          );
                        }
                        if (isPartial) {
                          return (
                            <div>
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                                <Clock className="w-3 h-3" />
                                <span>Partial</span>
                              </span>
                              <span className="block text-[10px] text-amber-700 font-semibold mt-0.5">
                                Due: {formatCurrency(balance, currencySymbol)}
                              </span>
                            </div>
                          );
                        }
                        return (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                            <AlertTriangle className="w-3 h-3" />
                            <span>Unpaid</span>
                          </span>
                        );
                      })()}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => handleOpenAddCheque(inv.id)}
                          title="Record Cheque for this Invoice"
                          className="p-1.5 text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <CreditCard className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setPreviewInvoice(inv)}
                          title="View Invoice Preview"
                          className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handlePrint(inv)}
                          title="Print / Save PDF"
                          className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                        >
                          <Printer className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => exportInvoiceToExactExcel(inv)}
                          title="Download Formatted Excel (.xls)"
                          className="p-1.5 text-emerald-700 hover:text-emerald-900 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <FileSpreadsheet className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleOpenEdit(inv)}
                          title="Edit Invoice"
                          className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <Edit className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleDuplicate(inv)}
                          title="Duplicate Invoice"
                          className="p-1.5 text-slate-600 hover:text-purple-700 hover:bg-purple-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <Copy className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => setDeleteConfirmId(inv.id)}
                          title="Delete Invoice"
                          className="p-1.5 text-slate-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Table Footer with System Generated Notice */}
            <div className="bg-slate-50 border-t border-slate-200 px-6 py-3 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
              <span className="font-semibold text-slate-600">
                Total {filteredInvoices.length} invoices issued & recorded
              </span>
              <span className="font-bold text-slate-600 uppercase tracking-wider text-[11px] flex items-center gap-1.5 bg-white px-3 py-1 rounded-full border border-slate-200 shadow-2xs">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                This is a system generated invoice - No signature required
              </span>
            </div>
          </div>
        )}
      </div>
      </>
      )}

      {/* Cheque Entry / Edit Modal */}
      <InvoiceChequeModal
        isOpen={isChequeModalOpen}
        onClose={() => {
          setIsChequeModalOpen(false);
          setEditingCheque(null);
          setPreselectedInvoiceIdForCheque(undefined);
        }}
        onSave={(data) => {
          if (onAddChequePayment) onAddChequePayment(data);
        }}
        onUpdate={(data) => {
          if (onUpdateChequePayment) onUpdateChequePayment(data);
        }}
        editingCheque={editingCheque}
        preselectedInvoiceId={preselectedInvoiceIdForCheque}
        invoices={invoices}
        existingCheques={invoiceChequePayments || []}
        currencySymbol={currencySymbol}
      />

      {/* Delete Confirmation Dialog */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white max-w-sm w-full p-6 rounded-2xl border border-slate-200 shadow-xl">
            <h3 className="text-lg font-bold text-slate-900">Delete Invoice?</h3>
            <p className="text-sm text-slate-500 mt-2">
              Are you sure you want to delete this invoice? This action cannot be undone.
            </p>
            <div className="flex items-center justify-end gap-3 mt-6">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteInvoice(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="px-4 py-2 text-sm font-semibold bg-rose-600 text-white rounded-xl hover:bg-rose-700 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create / Edit Invoice Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white max-w-4xl w-full my-8 p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div>
                <h2 className="text-xl font-extrabold text-slate-900">
                  {editingInvoice ? `Edit Invoice #${editingInvoice.invoiceNo}` : 'Create New Sales Tax Invoice'}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Enter buyer details, PO info, and line items with GST computation
                </p>
              </div>
              <button
                onClick={() => setIsFormOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="space-y-6">
              {/* Seller & Header Info */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-4">
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
                  1. Seller / Enterprise Details
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Company Name</label>
                    <input
                      type="text"
                      value={formData.companyName}
                      onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                      required
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-semibold text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">NTN #</label>
                    <input
                      type="text"
                      value={formData.companyNtn}
                      onChange={(e) => setFormData({ ...formData, companyNtn: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">STRN #</label>
                    <input
                      type="text"
                      value={formData.companyStrn}
                      onChange={(e) => setFormData({ ...formData, companyStrn: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-800"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Address</label>
                    <input
                      type="text"
                      value={formData.companyAddress}
                      onChange={(e) => setFormData({ ...formData, companyAddress: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Phone Numbers</label>
                    <input
                      type="text"
                      value={formData.companyPhone}
                      onChange={(e) => setFormData({ ...formData, companyPhone: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-800"
                    />
                  </div>
                </div>
              </div>

              {/* Invoice & Buyer Info */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
                    2. Invoice & Buyer Information
                  </span>
                  {knownBuyers.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[11px] font-semibold text-slate-500">Quick Fill:</span>
                      {knownBuyers.map((b, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setFormData((prev) => ({
                              ...prev,
                              buyerName: b.name,
                              buyerNtn: b.ntn,
                              buyerStrn: b.strn,
                              buyerAddress: b.address,
                            }));
                          }}
                          className="text-[11px] font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-lg transition-colors cursor-pointer"
                        >
                          {b.name}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Invoice No *</label>
                    <input
                      type="text"
                      value={formData.invoiceNo}
                      onChange={(e) => setFormData({ ...formData, invoiceNo: e.target.value })}
                      required
                      placeholder="e.g. 11"
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Invoice Date *</label>
                    <input
                      type="date"
                      value={formData.invoiceDate}
                      onChange={(e) => setFormData({ ...formData, invoiceDate: e.target.value })}
                      required
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">PO No</label>
                    <input
                      type="text"
                      value={formData.poNo}
                      onChange={(e) => setFormData({ ...formData, poNo: e.target.value })}
                      placeholder="e.g. 3398"
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-800"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Buyer Name *</label>
                    <input
                      type="text"
                      value={formData.buyerName}
                      onChange={(e) => setFormData({ ...formData, buyerName: e.target.value })}
                      required
                      placeholder="e.g. BEACON IMPEX"
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm font-semibold text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Buyer NTN #</label>
                    <input
                      type="text"
                      value={formData.buyerNtn}
                      onChange={(e) => setFormData({ ...formData, buyerNtn: e.target.value })}
                      placeholder="e.g. 2560721-9"
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-800"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-600 block mb-1">Buyer STRN #</label>
                    <input
                      type="text"
                      value={formData.buyerStrn}
                      onChange={(e) => setFormData({ ...formData, buyerStrn: e.target.value })}
                      placeholder="e.g. 08-01-3200-019-37"
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-600 block mb-1">Buyer Address</label>
                  <input
                    type="text"
                    value={formData.buyerAddress}
                    onChange={(e) => setFormData({ ...formData, buyerAddress: e.target.value })}
                    placeholder="e.g. P102 jail road Faisalabad"
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-800"
                  />
                </div>
              </div>

              {/* Line Items Table */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                    3. Items / Particulars
                  </span>
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-xl transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Item Row</span>
                  </button>
                </div>

                <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                  <table className="w-full text-left text-xs border-collapse min-w-[700px]">
                    <thead className="bg-slate-100 font-bold text-slate-600 border-b border-slate-200">
                      <tr>
                        <th className="p-2.5 w-10">S#</th>
                        <th className="p-2.5 w-16">UM</th>
                        <th className="p-2.5 w-24">GRN #</th>
                        <th className="p-2.5">Particulars / Description</th>
                        <th className="p-2.5 w-16">Qty</th>
                        <th className="p-2.5 w-24">Rate</th>
                        <th className="p-2.5 w-28 text-right">Amount (W/O)</th>
                        <th className="p-2.5 w-16 text-center">GST %</th>
                        <th className="p-2.5 w-24 text-right">GST Amt</th>
                        <th className="p-2.5 w-28 text-right">Net Amount</th>
                        <th className="p-2.5 w-10"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {formData.items.map((item, idx) => (
                        <tr key={item.id || idx} className="bg-white">
                          <td className="p-2 font-bold text-slate-500 text-center">{idx + 1}</td>
                          <td className="p-2">
                            <input
                              type="text"
                              value={item.um}
                              onChange={(e) => handleItemChange(idx, 'um', e.target.value)}
                              placeholder="CF"
                              className="w-full px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold uppercase"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="text"
                              value={item.grnNo || ''}
                              onChange={(e) => handleItemChange(idx, 'grnNo', e.target.value)}
                              placeholder="3936"
                              className="w-full px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="text"
                              value={item.particulars}
                              onChange={(e) => handleItemChange(idx, 'particulars', e.target.value)}
                              required
                              placeholder="e.g. TROLLY WOODEN"
                              className="w-full px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              min="0"
                              step="any"
                              value={item.qty}
                              onChange={(e) => handleItemChange(idx, 'qty', e.target.value)}
                              className="w-full px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-center"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              min="0"
                              step="any"
                              value={item.rate}
                              onChange={(e) => handleItemChange(idx, 'rate', e.target.value)}
                              className="w-full px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                            />
                          </td>
                          <td className="p-2 text-right font-semibold text-slate-700">
                            {formatCurrency(item.amountWithoutGst, currencySymbol)}
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              min="0"
                              max="100"
                              value={item.gstRate}
                              onChange={(e) => handleItemChange(idx, 'gstRate', e.target.value)}
                              className="w-full px-1.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-center"
                            />
                          </td>
                          <td className="p-2 text-right font-semibold text-emerald-700">
                            {formatCurrency(item.gstAmount, currencySymbol)}
                          </td>
                          <td className="p-2 text-right font-black text-slate-900">
                            {formatCurrency(item.netAmount, currencySymbol)}
                          </td>
                          <td className="p-2 text-center">
                            {formData.items.length > 1 && (
                              <button
                                type="button"
                                onClick={() => handleRemoveItem(idx)}
                                className="text-slate-400 hover:text-rose-600 p-1"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-slate-50 font-black border-t border-slate-200 text-xs">
                      <tr>
                        <td colSpan={4} className="p-2.5 text-right uppercase">
                          Total:
                        </td>
                        <td className="p-2.5 text-center">{liveFormTotals.totalQty}</td>
                        <td></td>
                        <td className="p-2.5 text-right">
                          {formatCurrency(liveFormTotals.totalAmountWithoutGst, currencySymbol)}
                        </td>
                        <td></td>
                        <td className="p-2.5 text-right text-emerald-700">
                          {formatCurrency(liveFormTotals.totalGstAmount, currencySymbol)}
                        </td>
                        <td className="p-2.5 text-right text-slate-900 text-sm">
                          {formatCurrency(liveFormTotals.totalNetAmount, currencySymbol)}
                        </td>
                        <td></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-200 text-xs font-bold text-emerald-900">
                  <span className="text-emerald-700 font-semibold mr-1">Amount in Words:</span>
                  <span>{liveFormTotals.amountInWords}</span>
                </div>
              </div>

              {/* Terms & Conditions & Special Notes Input */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-4">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                  4. Terms & Conditions and Invoice Notes
                </span>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Terms & Conditions (Printed on invoice bottom)
                  </label>
                  <textarea
                    rows={2}
                    value={formData.terms}
                    onChange={(e) => setFormData({ ...formData, terms: e.target.value })}
                    placeholder="e.g. Computerized Sales Tax Invoice generated in compliance with FBR sales tax rules. This is a system generated invoice - No signature required."
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Return Policy / Notes
                  </label>
                  <input
                    type="text"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="e.g. Goods once sold are non-refundable. Payment terms as agreed."
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Form Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-5 py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 text-sm font-bold bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 shadow-sm transition-all active:scale-95"
                >
                  {editingInvoice ? 'Update Invoice' : 'Save & Issue Invoice'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Printable FBR Sales Tax Invoice Modal (Matches uploaded screenshot exactly) */}
      {previewInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white max-w-4xl w-full my-6 p-6 sm:p-10 rounded-3xl border border-slate-300 shadow-2xl space-y-6">
            <div className="no-print flex items-center justify-between border-b border-slate-200 pb-4">
              <div className="flex items-center gap-2">
                <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-full">
                  Official Invoice Preview
                </span>
                <span className="font-extrabold text-slate-800">
                  Invoice #{previewInvoice.invoiceNo}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => exportInvoiceToExactExcel(previewInvoice)}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-xs rounded-xl transition-all cursor-pointer"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                  <span>Download Excel (.xlsx)</span>
                </button>
                <button
                  onClick={() => handlePrint(previewInvoice)}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print / Save as PDF</span>
                </button>
                <button
                  onClick={() => setPreviewInvoice(null)}
                  className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Exact Sales Tax Invoice Layout as requested in screenshot */}
            <div
              id="printable-invoice-modal"
              className="bg-white text-black p-4 sm:p-6 border border-black font-sans text-xs leading-tight"
            >
              {/* Header Company Details */}
              <div className="text-center pb-2 border-b-2 border-black">
                <h1 className="text-xl sm:text-2xl font-black tracking-wider uppercase underline">
                  {previewInvoice.companyName || 'RNC ENTERPRISES'}
                </h1>
                <p className="font-semibold text-xs mt-1">
                  {previewInvoice.companyAddress || 'Second floor near zaika hotel jarranwala road, Khurrianwala'}
                </p>
                <p className="font-semibold text-xs mt-0.5">
                  NTN# {previewInvoice.companyNtn || '121541-5'}, STRN# {previewInvoice.companyStrn || '2400690400146'}
                </p>
                <p className="font-semibold text-xs mt-0.5">
                  PHONE NO: {previewInvoice.companyPhone || '041-5489876 : 0300-8653676'}
                </p>
                <h2 className="text-base sm:text-lg font-black tracking-wide uppercase mt-2 underline">
                  {previewInvoice.invoiceTitle || 'SALES TAX INVOICE'}
                </h2>
              </div>

              {/* Buyer & Order Metadata Table */}
              <table className="w-full border-collapse border-b-2 border-black text-xs mt-2">
                <tbody>
                  <tr className="border-b border-black">
                    <td className="font-bold border-r border-black p-1.5 w-28 uppercase">
                      BUYER NAME
                    </td>
                    <td className="font-bold border-r border-black p-1.5 text-sm" colSpan={2}>
                      {previewInvoice.buyerName}
                    </td>
                    <td className="font-bold border-r border-black p-1.5 w-24">INV. NO.</td>
                    <td className="font-black p-1.5 w-32 text-center text-sm">
                      {previewInvoice.invoiceNo}
                    </td>
                  </tr>
                  <tr className="border-b border-black">
                    <td className="font-bold border-r border-black p-1.5">NTN#</td>
                    <td className="font-bold border-r border-black p-1.5" colSpan={2}>
                      {previewInvoice.buyerNtn || '-'}
                    </td>
                    <td className="font-bold border-r border-black p-1.5">INVOICE DATE</td>
                    <td className="font-bold p-1.5 text-center">
                      {previewInvoice.invoiceDate || '-'}
                    </td>
                  </tr>
                  <tr className="border-b border-black">
                    <td className="font-bold border-r border-black p-1.5">STRN#</td>
                    <td className="font-bold border-r border-black p-1.5" colSpan={2}>
                      {previewInvoice.buyerStrn || '-'}
                    </td>
                    <td className="font-bold border-r border-black p-1.5">PO NO.</td>
                    <td className="font-bold p-1.5 text-center">
                      {previewInvoice.poNo || '-'}
                    </td>
                  </tr>
                  <tr>
                    <td colSpan={5} className="font-bold text-center p-1.5 bg-slate-50 border-t border-black">
                      {resolveBuyerAddress(previewInvoice.buyerAddress)}
                    </td>
                  </tr>
                </tbody>
              </table>

              {/* Items Grid */}
              <table className="w-full border-collapse border-b-2 border-black text-xs mt-1">
                <thead>
                  <tr className="border-b-2 border-black text-center font-bold">
                    <th className="border-r border-black p-1.5 w-12">S/NO.</th>
                    <th className="border-r border-black p-1.5 w-14">UM</th>
                    <th className="border-r border-black p-1.5 w-24">GRN DATE</th>
                    <th className="border-r border-black p-1.5 w-16">GRN#</th>
                    <th className="border-r border-black p-1.5 text-center">PARTICULARS</th>
                    <th className="border-r border-black p-1.5 w-12">QTY</th>
                    <th className="border-r border-black p-1.5 w-20">RATE</th>
                    <th className="border-r border-black p-1.5 w-24">
                      AMOUNT<br />W/O GST
                    </th>
                    <th className="border-r border-black p-1.5 w-20">
                      GST 18%
                    </th>
                    <th className="p-1.5 w-24">NET AMOUNT</th>
                  </tr>
                </thead>
                <tbody>
                  {previewInvoice.items.map((item, idx) => (
                    <tr key={item.id || idx} className="border-b border-black text-center">
                      <td className="border-r border-black p-2 font-bold">{item.sNo || idx + 1}</td>
                      <td className="border-r border-black p-2 font-bold">{item.um || 'CF'}</td>
                      <td className="border-r border-black p-2 font-medium">
                        {item.grnDate || previewInvoice.invoiceDate}
                      </td>
                      <td className="border-r border-black p-2 font-medium">{item.grnNo || '-'}</td>
                      <td className="border-r border-black p-2 font-bold text-left px-3">
                        {item.particulars}
                      </td>
                      <td className="border-r border-black p-2 font-bold">{item.qty}</td>
                      <td className="border-r border-black p-2 font-bold">
                        {item.rate ? item.rate.toLocaleString() : '0'}
                      </td>
                      <td className="border-r border-black p-2 font-bold">
                        {item.amountWithoutGst ? item.amountWithoutGst.toLocaleString() : '0'}
                      </td>
                      <td className="border-r border-black p-2 font-bold">
                        {item.gstAmount ? item.gstAmount.toLocaleString() : '0'}
                      </td>
                      <td className="p-2 font-black">
                        {item.netAmount ? item.netAmount.toLocaleString() : '0'}
                      </td>
                    </tr>
                  ))}

                  {/* Spacer Rows to create authentic voucher look if items < 4 */}
                  {Array.from({ length: Math.max(0, 4 - previewInvoice.items.length) }).map(
                    (_, index) => (
                      <tr key={`spacer-${index}`} className="border-b border-black text-center h-8">
                        <td className="border-r border-black"></td>
                        <td className="border-r border-black"></td>
                        <td className="border-r border-black"></td>
                        <td className="border-r border-black"></td>
                        <td className="border-r border-black"></td>
                        <td className="border-r border-black"></td>
                        <td className="border-r border-black"></td>
                        <td className="border-r border-black"></td>
                        <td className="border-r border-black"></td>
                        <td></td>
                      </tr>
                    )
                  )}

                  {/* Totals Row */}
                  <tr className="font-black border-t-2 border-black text-center bg-slate-50">
                    <td colSpan={5} className="border-r border-black p-2 text-right uppercase">
                      TOTAL
                    </td>
                    <td className="border-r border-black p-2">{previewInvoice.totalQty}</td>
                    <td className="border-r border-black p-2"></td>
                    <td className="border-r border-black p-2">
                      {previewInvoice.totalAmountWithoutGst?.toLocaleString()}
                    </td>
                    <td className="border-r border-black p-2">
                      {previewInvoice.totalGstAmount?.toLocaleString()}
                    </td>
                    <td className="p-2 text-sm font-black">
                      {previewInvoice.totalNetAmount?.toLocaleString()}
                    </td>
                  </tr>
                </tbody>
              </table>

              {/* Amount in words & Signatures */}
              <div className="pt-4 space-y-8">
                <div className="border-b border-black pb-2">
                  <span className="font-bold uppercase">Amount in Words: </span>
                  <span className="font-semibold underline">
                    {previewInvoice.amountInWords ||
                      numberToWords(previewInvoice.totalNetAmount || 0)}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-8 pt-8 text-center font-bold text-xs">
                  <div>
                    <div className="border-t border-black pt-1">Prepared By</div>
                  </div>
                  <div>
                    <div className="border-t border-black pt-1">Checked By</div>
                  </div>
                  <div>
                    <div className="border-t border-black pt-1">Authorized Signature</div>
                  </div>
                </div>

                {/* System Generated Invoice Notice */}
                <div className="text-center font-bold tracking-widest text-[11px] text-slate-700 border-t border-dashed border-black/40 pt-2.5 uppercase mt-6">
                  This is a system generated invoice - No signature required
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

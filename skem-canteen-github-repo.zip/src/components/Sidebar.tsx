import React from 'react';
import {
  LayoutDashboard,
  Receipt,
  CalendarCheck,
  Users,
  Wallet,
  FileSpreadsheet,
  Building2,
  Settings,
  PlusCircle,
  Coffee,
  Lock,
  Cloud,
  RefreshCw,
  FileText,
  Handshake,
  Layers,
  ChevronLeft,
  ChevronRight,
  X,
  Store,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Ticket,
  Coins,
} from 'lucide-react';
import { Canteen } from '../types';
import { NavTab } from './Navbar';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  canteens: Canteen[];
  selectedCanteenId: string;
  setSelectedCanteenId: (id: string) => void;
  onQuickAddEntry: () => void;
  hasPin?: boolean;
  onLockApp?: () => void;
  lockedCanteenId?: string;
  cloudStatus?: 'connecting' | 'synced' | 'offline' | 'error';
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
}

interface NavSection {
  title: string;
  items: {
    id: NavTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  canteens,
  selectedCanteenId,
  setSelectedCanteenId,
  onQuickAddEntry,
  hasPin = false,
  onLockApp,
  lockedCanteenId,
  cloudStatus = 'synced',
  mobileOpen,
  setMobileOpen,
  isCollapsed,
  setIsCollapsed,
}) => {
  const activeCanteens = canteens.filter((c) => c.status === 'active');

  const navSections: NavSection[] = [
    {
      title: 'Main Operations',
      items: [
        { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard },
        { id: 'daily_entry', label: 'Daily Sales & Expenses', icon: Receipt },
        { id: 'petty_cash', label: 'Daily Petty Cash', icon: Coins, badge: 'Float' },
        { id: 'window_sales', label: 'Window & Shift Sales', icon: Layers },
        { id: 'invoices', label: 'Invoices & Billing', icon: FileText },
      ],
    },
    {
      title: 'Khata & Accounts',
      items: [
        { id: 'parties', label: 'Parties & Khata Ledger', icon: Handshake },
        { id: 'labour_tokens', label: 'Labour Monthly Tokens', icon: Ticket, badge: 'Sadaqat' },
        { id: 'financials', label: 'Staff Advances & Ledger', icon: Wallet },
      ],
    },
    {
      title: 'Human Resources',
      items: [
        { id: 'staff', label: 'Staff Directory', icon: Users },
        { id: 'attendance', label: 'Daily Attendance', icon: CalendarCheck },
      ],
    },
    {
      title: 'System & Admin',
      items: [
        { id: 'reports', label: 'Reports & Analytics', icon: FileSpreadsheet },
        { id: 'canteens', label: 'Branches & Canteens', icon: Building2 },
        { id: 'settings', label: 'Settings & Cloud Backup', icon: Settings },
      ],
    },
  ];

  const handleNavClick = (tab: NavTab) => {
    setActiveTab(tab);
    setMobileOpen(false);
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[#0B132B] border-r border-slate-800 text-slate-300 shadow-2xl select-none">
      {/* Brand Header */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between gap-3 bg-gradient-to-b from-[#111C3D] to-[#0B132B]">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 via-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-lg shadow-emerald-950/60 font-bold text-lg overflow-hidden shrink-0 ring-2 ring-emerald-400/30">
            <img
              src="/icon-192.jpg"
              alt="SKEM Canteens"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
            <Coffee className="w-5 h-5 absolute inset-0 m-auto -z-10 text-white" />
          </div>
          {!isCollapsed && (
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-white tracking-tight text-base truncate">
                  SKEM Canteens
                </span>
                <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-extrabold px-1.5 py-0.5 rounded border border-emerald-500/30">
                  ERP
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium truncate flex items-center gap-1">
                <span>Enterprise Suite</span>
                <span className="inline-block w-1 h-1 rounded-full bg-slate-500"></span>
                <span className="text-emerald-400 font-semibold">v2.8</span>
              </p>
            </div>
          )}
        </div>

        {/* Mobile close button */}
        <button
          onClick={() => setMobileOpen(false)}
          className="lg:hidden p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer"
          aria-label="Close menu"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Desktop Collapse Toggle */}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="hidden lg:flex p-1.5 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-lg cursor-pointer transition-colors"
          title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isCollapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <ChevronLeft className="w-4 h-4" />
          )}
        </button>
      </div>

      {/* Cloud Status Pill & Branch Selector */}
      {!isCollapsed ? (
        <div className="px-3.5 py-3 border-b border-slate-800/80 space-y-2.5 bg-[#0e1733]/50">
          {/* Cloud Database Status */}
          <div className="flex items-center justify-between text-xs px-1">
            <span className="text-slate-400 font-semibold text-[11px] flex items-center gap-1.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              Database Status
            </span>
            {cloudStatus === 'synced' && (
              <span className="inline-flex items-center gap-1 text-emerald-300 bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded-full text-[10px] font-bold">
                <Cloud className="w-3 h-3 text-emerald-400" />
                <span>Cloud Live</span>
              </span>
            )}
            {cloudStatus === 'connecting' && (
              <span className="inline-flex items-center gap-1 text-amber-300 bg-amber-950/80 border border-amber-500/30 px-2 py-0.5 rounded-full text-[10px] font-bold">
                <RefreshCw className="w-3 h-3 text-amber-400 animate-spin" />
                <span>Connecting...</span>
              </span>
            )}
            {cloudStatus === 'offline' && (
              <span className="inline-flex items-center gap-1 text-slate-300 bg-slate-800 border border-slate-700 px-2 py-0.5 rounded-full text-[10px] font-bold">
                <ShieldCheck className="w-3 h-3 text-slate-400" />
                <span>Local Offline</span>
              </span>
            )}
          </div>

          {/* Canteen Selector */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 px-1">
              Active Branch Filter
            </label>
            <div className="relative">
              <select
                value={lockedCanteenId || selectedCanteenId}
                disabled={Boolean(lockedCanteenId)}
                onChange={(e) => setSelectedCanteenId(e.target.value)}
                className="w-full appearance-none bg-[#162044] border border-slate-700/80 hover:border-slate-600 text-white text-xs font-semibold rounded-xl pl-8 pr-7 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed shadow-inner transition-colors truncate"
              >
                {!lockedCanteenId && (
                  <option value="all">All Canteens ({activeCanteens.length})</option>
                )}
                {activeCanteens.map((c) => (
                  <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                    {c.name} {lockedCanteenId === c.id ? '(Locked)' : ''}
                  </option>
                ))}
              </select>
              <Store className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Quick Add Button */}
          <button
            onClick={onQuickAddEntry}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-black py-2.5 px-3 rounded-xl shadow-md shadow-emerald-950/60 hover:shadow-lg transition-all cursor-pointer transform active:scale-[0.98]"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ New Daily Entry</span>
          </button>
        </div>
      ) : (
        <div className="p-2 border-b border-slate-800 flex flex-col items-center gap-2">
          <button
            onClick={onQuickAddEntry}
            className="p-2.5 bg-gradient-to-tr from-emerald-500 to-teal-600 text-white rounded-xl shadow-md transition-all cursor-pointer hover:scale-105 active:scale-95"
            title="Record Daily Sales & Expenses"
          >
            <PlusCircle className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-4">
        {navSections.map((section, sIndex) => (
          <div key={sIndex} className="space-y-1">
            {!isCollapsed && (
              <div className="px-2 text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mb-1">
                {section.title}
              </div>
            )}
            {section.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  title={isCollapsed ? item.label : undefined}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer group ${
                    isActive
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold shadow-md shadow-emerald-950/80 ring-1 ring-emerald-400/40'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  } ${isCollapsed ? 'justify-center px-2' : ''}`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                      isActive ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'
                    }`}
                  />
                  {!isCollapsed && (
                    <span className="truncate flex-1 text-left">{item.label}</span>
                  )}
                  {!isCollapsed && isActive && (
                    <span className="w-2 h-2 rounded-full bg-white shadow-xs"></span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Footer System Status / Operator Card */}
      <div className="p-3 border-t border-slate-800/80 bg-[#080d1e] space-y-2">
        {!isCollapsed ? (
          <div className="flex items-center justify-between text-xs px-1 text-slate-400">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-[10px] text-emerald-400">
                OP
              </div>
              <div className="min-w-0">
                <p className="text-[11px] font-bold text-slate-200 truncate leading-tight">
                  Canteen Admin
                </p>
                <p className="text-[10px] text-emerald-400 font-medium">Production Mode</p>
              </div>
            </div>
            <div className="flex items-center gap-1 text-[10px] font-mono text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Safe</span>
            </div>
          </div>
        ) : null}

        {hasPin && onLockApp && (
          <button
            onClick={onLockApp}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/50 transition-colors cursor-pointer ${
              isCollapsed ? 'justify-center px-2' : ''
            }`}
            title="Lock App / Pin Protect"
          >
            <Lock className="w-4 h-4 shrink-0 text-rose-400" />
            {!isCollapsed && <span>Lock Application</span>}
          </button>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside
        className={`hidden lg:block shrink-0 sticky top-0 h-screen transition-all duration-300 z-30 ${
          isCollapsed ? 'w-18' : 'w-64'
        }`}
      >
        {sidebarContent}
      </aside>

      {/* Mobile Drawer Backdrop & Slide-over */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity"
            onClick={() => setMobileOpen(false)}
          />
          <div className="relative w-72 max-w-[85vw] h-full shadow-2xl z-10 animate-in slide-in-from-left duration-200">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};

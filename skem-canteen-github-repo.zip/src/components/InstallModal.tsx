import React, { useState } from 'react';
import {
  Smartphone,
  Share2,
  MoreVertical,
  Copy,
  Check,
  ExternalLink,
  X,
  Download,
  Laptop,
  CheckCircle,
} from 'lucide-react';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  deferredPrompt: any;
  onNativeInstallTriggered?: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({
  isOpen,
  onClose,
  deferredPrompt,
  onNativeInstallTriggered,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = window.location.href;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }).catch(() => {
      // Fallback
      const textArea = document.createElement('textarea');
      textArea.value = currentUrl;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  const handleNativeInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted' && onNativeInstallTriggered) {
        onNativeInstallTriggered();
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5 relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-2 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
          title="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pr-8">
          <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Install SKEM Canteens App
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Add app to your mobile or PC home screen for 1-click access
            </p>
          </div>
        </div>

        {/* Trigger Native Prompt if available */}
        {deferredPrompt && (
          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl space-y-2">
            <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
              <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>Direct Browser Install Available!</span>
            </div>
            <p className="text-xs text-emerald-800">
              Your browser supports automatic installation. Click below to add SKEM Canteens directly to your home screen or desktop.
            </p>
            <button
              onClick={handleNativeInstall}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-colors mt-2"
            >
              <Download className="w-4 h-4" />
              <span>Click Here to Install Now</span>
            </button>
          </div>
        )}

        {/* Action 1: Open in New Tab */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Step 1: Open in Browser Tab (Recommended)
          </h3>
          <p className="text-xs text-slate-500">
            If you are viewing inside AI Studio preview frame, open the app directly in Chrome or Safari for full PWA installation support:
          </p>
          <div className="flex items-center gap-2">
            <a
              href={currentUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Open App in Full Browser Tab</span>
            </a>

            <button
              onClick={handleCopyLink}
              className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs py-2.5 px-3.5 rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors border border-slate-200 shrink-0"
              title="Copy link"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700 font-bold">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Link</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Action 2: Mobile Install Instructions */}
        <div className="space-y-3 pt-2 border-t border-slate-100">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Step 2: Add to Phone Home Screen
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* Android */}
            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1.5">
              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-emerald-600" />
                <span>Android (Chrome)</span>
              </div>
              <ol className="list-decimal list-inside text-slate-600 space-y-1 text-[11px] leading-relaxed">
                <li>Tap 3 dots menu <MoreVertical className="w-3 h-3 inline text-slate-700" /> at top right.</li>
                <li>Select <strong>"Add to Home screen"</strong> or <strong>"Install app"</strong>.</li>
                <li>Tap <strong>Add</strong> to place app icon on mobile home screen.</li>
              </ol>
            </div>

            {/* iPhone */}
            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1.5">
              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                <Share2 className="w-4 h-4 text-emerald-600" />
                <span>iPhone (Safari)</span>
              </div>
              <ol className="list-decimal list-inside text-slate-600 space-y-1 text-[11px] leading-relaxed">
                <li>Tap Share button <Share2 className="w-3 h-3 inline text-slate-700" /> at bottom bar.</li>
                <li>Scroll down and tap <strong>"Add to Home Screen"</strong>.</li>
                <li>Tap <strong>Add</strong> in top right corner.</li>
              </ol>
            </div>
          </div>
        </div>

        {/* Standalone & Offline Guarantee Box */}
        <div className="bg-slate-900 text-slate-100 rounded-2xl p-4 space-y-1.5 text-xs">
          <div className="font-bold text-emerald-400 flex items-center gap-1.5">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Standalone Native App & 100% Offline Storage</span>
          </div>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            When installed via <strong>"Add to Home Screen"</strong> / <strong>"Install App"</strong> in Chrome or Safari, this app launches as a full standalone application (without browser URL bar) with its own app icon. All sales, staff salaries, advances, and reports are saved locally on your phone/PC device storage and work <strong>100% offline without internet connection</strong>.
          </p>
        </div>

        {/* Footer */}
        <div className="pt-2 text-center">
          <button
            onClick={onClose}
            className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs py-2.5 rounded-xl cursor-pointer transition-colors"
          >
            Got It / Close
          </button>
        </div>
      </div>
    </div>
  );
};

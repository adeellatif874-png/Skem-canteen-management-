import React, { useState, useMemo } from 'react';
import {
  Ticket,
  Users,
  Wallet,
  Plus,
  Search,
  Filter,
  Calendar,
  DollarSign,
  Printer,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowUpRight,
  TrendingUp,
  CreditCard,
  Edit2,
  Trash2,
  X,
  Building2,
  HelpCircle,
  Layers,
  ArrowRight,
  Receipt,
  Check,
} from 'lucide-react';
import {
  LabourWorker,
  LabourTokenIssue,
  LabourTokenPayment,
  Canteen,
  DailyEntry,
} from '../types';
import { formatCurrency, formatDisplayDate, downloadExcel } from '../lib/storage';

interface LabourTokensViewProps {
  labourWorkers: LabourWorker[];
  labourTokenIssues: LabourTokenIssue[];
  labourTokenPayments: LabourTokenPayment[];
  canteens: Canteen[];
  selectedCanteenId: string;
  currencySymbol: string;
  onAddWorker: (worker: Omit<LabourWorker, 'id' | 'createdAt'>) => void;
  onEditWorker: (id: string, updated: Partial<LabourWorker>) => void;
  onDeleteWorker: (id: string) => void;
  onIssueTokens: (issue: Omit<LabourTokenIssue, 'id' | 'createdAt' | 'totalAmount'> & { totalAmount?: number }) => void;
  onDeleteTokenIssue: (id: string) => void;
  onCollectCash: (payment: Omit<LabourTokenPayment, 'id' | 'createdAt'>) => void;
  onDeletePayment: (id: string) => void;
}

export const LabourTokensView: React.FC<LabourTokensViewProps> = ({
  labourWorkers = [],
  labourTokenIssues = [],
  labourTokenPayments = [],
  canteens = [],
  selectedCanteenId,
  currencySymbol,
  onAddWorker,
  onEditWorker,
  onDeleteWorker,
  onIssueTokens,
  onDeleteTokenIssue,
  onCollectCash,
  onDeletePayment,
}) => {
  // Current active view tab inside Labour Tokens
  const [activeSubTab, setActiveSubTab] = useState<'summary' | 'daily_issues' | 'payments' | 'workers'>('summary');

  // Month selector (YYYY-MM)
  const currentYearMonth = new Date().toISOString().slice(0, 7);
  const [selectedMonth, setSelectedMonth] = useState<string>(currentYearMonth);

  // Search and filter
  const [searchQuery, setSearchQuery] = useState('');
  const [canteenFilter, setCanteenFilter] = useState<string>(selectedCanteenId === 'all' ? 'cant-sadaqat' : selectedCanteenId);

  // Modals state
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showWorkerModal, setShowWorkerModal] = useState(false);
  const [editingWorker, setEditingWorker] = useState<LabourWorker | null>(null);
  const [selectedWorkerForSlip, setSelectedWorkerForSlip] = useState<LabourWorker | null>(null);
  const [selectedWorkerIdForQuickAction, setSelectedWorkerIdForQuickAction] = useState<string>('');

  // Delete confirmation state (avoids blocked iframe window.confirm)
  const [deleteConfirmWorkerId, setDeleteConfirmWorkerId] = useState<string | null>(null);
  const [deleteConfirmIssueId, setDeleteConfirmIssueId] = useState<string | null>(null);
  const [deleteConfirmPaymentId, setDeleteConfirmPaymentId] = useState<string | null>(null);

  // Form states for Token Issue (Token Qty and Amount optional / manual)
  const [issueForm, setIssueForm] = useState({
    labourId: '',
    date: new Date().toISOString().slice(0, 10),
    tokenQty: '' as string | number,
    tokenRate: '' as string | number,
    totalAmount: '' as string | number,
    mealType: 'General',
    remarks: '',
  });

  // Form states for Cash Collection
  const [paymentForm, setPaymentForm] = useState({
    labourId: '',
    date: new Date().toISOString().slice(0, 10),
    amount: 1000,
    paymentMethod: 'Cash' as 'Cash' | 'Online / Bank' | 'Salary Deduction' | 'Other',
    depositedToDailySale: true,
    notes: 'Token cash collection deposited into daily cash sale',
  });

  // Form states for Worker
  const [workerForm, setWorkerForm] = useState({
    name: '',
    labourNo: '',
    canteenId: 'cant-sadaqat',
    department: '',
    phone: '',
    defaultTokenRate: 100,
    status: 'active' as 'active' | 'inactive',
    notes: '',
  });

  // Filter workers based on canteen and search
  const filteredWorkers = useMemo(() => {
    return labourWorkers.filter((worker) => {
      const matchCanteen = canteenFilter === 'all' || worker.canteenId === canteenFilter;
      const matchQuery =
        searchQuery.trim() === '' ||
        worker.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (worker.labourNo && worker.labourNo.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (worker.department && worker.department.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCanteen && matchQuery;
    });
  }, [labourWorkers, canteenFilter, searchQuery]);

  // Compute monthly calculations per labour
  const workerMonthlySummaries = useMemo(() => {
    return filteredWorkers.map((worker) => {
      // Find all token issues for this worker in selectedMonth
      const issues = labourTokenIssues.filter(
        (issue) => issue.labourId === worker.id && issue.month === selectedMonth
      );
      const totalTokens = issues.reduce((sum, item) => sum + (Number(item.tokenQty) || 0), 0);
      const totalAmount = issues.reduce((sum, item) => sum + (Number(item.totalAmount) || 0), 0);

      // Find all payments for this worker in selectedMonth
      const payments = labourTokenPayments.filter(
        (pay) => pay.labourId === worker.id && pay.month === selectedMonth
      );
      const totalCollected = payments.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
      const balance = totalAmount - totalCollected;

      return {
        worker,
        totalTokens,
        totalAmount,
        totalCollected,
        balance,
        issuesCount: issues.length,
        status: balance <= 0 && totalAmount > 0 ? 'cleared' : totalCollected > 0 ? 'partial' : totalAmount > 0 ? 'pending' : 'no_issue',
      };
    });
  }, [filteredWorkers, labourTokenIssues, labourTokenPayments, selectedMonth]);

  // Aggregate monthly stats
  const monthStats = useMemo(() => {
    let totalTokens = 0;
    let totalValue = 0;
    let totalCollected = 0;
    let totalBalance = 0;

    workerMonthlySummaries.forEach((summary) => {
      totalTokens += summary.totalTokens;
      totalValue += summary.totalAmount;
      totalCollected += summary.totalCollected;
      totalBalance += summary.balance;
    });

    return {
      activeWorkersCount: filteredWorkers.filter((w) => w.status === 'active').length,
      totalTokens,
      totalValue,
      totalCollected,
      totalBalance,
    };
  }, [workerMonthlySummaries, filteredWorkers]);

  // Monthly issues list
  const monthlyIssues = useMemo(() => {
    return labourTokenIssues
      .filter((issue) => {
        const matchCanteen = canteenFilter === 'all' || issue.canteenId === canteenFilter;
        const matchMonth = issue.month === selectedMonth;
        const matchQuery =
          searchQuery.trim() === '' ||
          issue.labourName.toLowerCase().includes(searchQuery.toLowerCase());
        return matchCanteen && matchMonth && matchQuery;
      })
      .sort((a, b) => (b.date > a.date ? 1 : -1));
  }, [labourTokenIssues, canteenFilter, selectedMonth, searchQuery]);

  // Monthly payments list
  const monthlyPayments = useMemo(() => {
    return labourTokenPayments
      .filter((pay) => {
        const matchCanteen = canteenFilter === 'all' || pay.canteenId === canteenFilter;
        const matchMonth = pay.month === selectedMonth;
        const matchQuery =
          searchQuery.trim() === '' ||
          pay.labourName.toLowerCase().includes(searchQuery.toLowerCase());
        return matchCanteen && matchMonth && matchQuery;
      })
      .sort((a, b) => (b.date > a.date ? 1 : -1));
  }, [labourTokenPayments, canteenFilter, selectedMonth, searchQuery]);

  // Open Issue Token Modal for a specific worker
  const handleOpenIssueModal = (workerId?: string) => {
    const targetId = workerId || filteredWorkers[0]?.id || '';
    const worker = labourWorkers.find((w) => w.id === targetId);
    const defaultRate = worker?.defaultTokenRate ? worker.defaultTokenRate.toString() : '';
    setIssueForm({
      labourId: targetId,
      date: new Date().toISOString().slice(0, 10),
      tokenQty: '',
      tokenRate: defaultRate,
      totalAmount: '',
      mealType: 'General',
      remarks: '',
    });
    setShowIssueModal(true);
  };

  // Open Cash Collection Modal for a specific worker
  const handleOpenPaymentModal = (workerId?: string, defaultAmount?: number) => {
    const targetId = workerId || filteredWorkers[0]?.id || '';
    const summary = workerMonthlySummaries.find((s) => s.worker.id === targetId);
    const amount = defaultAmount !== undefined ? defaultAmount : summary && summary.balance > 0 ? summary.balance : 1000;

    setPaymentForm({
      labourId: targetId,
      date: new Date().toISOString().slice(0, 10),
      amount: amount > 0 ? amount : 1000,
      paymentMethod: 'Cash',
      depositedToDailySale: true,
      notes: 'Token cash collection deposited into daily cash sale',
    });
    setShowPaymentModal(true);
  };

  // Submit Issue Tokens (Tokens and Amount can be written manually / optionally)
  const handleSubmitIssue = (e: React.FormEvent) => {
    e.preventDefault();
    const worker = labourWorkers.find((w) => w.id === issueForm.labourId);
    if (!worker) return;

    const qty = issueForm.tokenQty !== '' ? Number(issueForm.tokenQty) : 0;
    const rate = issueForm.tokenRate !== '' ? Number(issueForm.tokenRate) : 0;
    let finalAmount = 0;

    if (issueForm.totalAmount !== '' && !isNaN(Number(issueForm.totalAmount))) {
      finalAmount = Number(issueForm.totalAmount);
    } else if (qty > 0 && rate > 0) {
      finalAmount = qty * rate;
    }

    const month = issueForm.date.slice(0, 7);
    onIssueTokens({
      labourId: worker.id,
      labourName: worker.name,
      canteenId: worker.canteenId,
      canteenName: worker.canteenName,
      date: issueForm.date,
      month,
      tokenQty: qty,
      tokenRate: rate,
      totalAmount: finalAmount,
      mealType: issueForm.mealType,
      remarks: issueForm.remarks,
    });

    setShowIssueModal(false);
  };

  // Submit Cash Collection
  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const worker = labourWorkers.find((w) => w.id === paymentForm.labourId);
    if (!worker) return;

    onCollectCash({
      labourId: worker.id,
      labourName: worker.name,
      canteenId: worker.canteenId,
      canteenName: worker.canteenName,
      date: paymentForm.date,
      month: selectedMonth,
      amount: Number(paymentForm.amount),
      paymentMethod: paymentForm.paymentMethod,
      depositedToDailySale: paymentForm.depositedToDailySale,
      dailyEntryDate: paymentForm.date,
      notes: paymentForm.notes,
    });

    setShowPaymentModal(false);
  };

  // Submit Worker Create/Edit
  const handleSubmitWorker = (e: React.FormEvent) => {
    e.preventDefault();
    const canteen = canteens.find((c) => c.id === workerForm.canteenId);
    const canteenName = canteen ? canteen.name : 'Sadaqat Canteen';

    if (editingWorker) {
      onEditWorker(editingWorker.id, {
        name: workerForm.name,
        labourNo: workerForm.labourNo,
        canteenId: workerForm.canteenId,
        canteenName,
        department: workerForm.department,
        phone: workerForm.phone,
        defaultTokenRate: Number(workerForm.defaultTokenRate),
        status: workerForm.status,
        notes: workerForm.notes,
      });
    } else {
      onAddWorker({
        name: workerForm.name,
        labourNo: workerForm.labourNo || `L-${Date.now().toString().slice(-3)}`,
        canteenId: workerForm.canteenId,
        canteenName,
        department: workerForm.department,
        phone: workerForm.phone,
        defaultTokenRate: Number(workerForm.defaultTokenRate) || 100,
        status: workerForm.status,
        notes: workerForm.notes,
      });
    }

    setEditingWorker(null);
    setShowWorkerModal(false);
  };

  // Export Excel
  const handleExportExcel = () => {
    const exportData = workerMonthlySummaries.map((item, index) => ({
      'Sr #': index + 1,
      'Labour Name': item.worker.name,
      'Token Card / Labour #': item.worker.labourNo || '-',
      'Department / Section': item.worker.department || '-',
      'Canteen': item.worker.canteenName,
      'Month': selectedMonth,
      'Tokens Issued (Qty)': item.totalTokens,
      'Token Rate': item.worker.defaultTokenRate,
      'Total Amount (Rs)': item.totalAmount,
      'Cash Collected (Rs)': item.totalCollected,
      'Remaining Balance (Rs)': item.balance,
      'Status': item.status.toUpperCase(),
      'Phone': item.worker.phone || '-',
    }));

    downloadExcel(exportData, `Labour_Tokens_Khata_${selectedMonth}`);
  };

  // Month labels generator
  const getMonthOptions = () => {
    const options = [];
    const date = new Date();
    for (let i = 0; i < 12; i++) {
      const d = new Date(date.getFullYear(), date.getMonth() - i, 1);
      const ym = d.toISOString().slice(0, 7);
      const label = d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      options.push({ value: ym, label });
    }
    return options;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner / Hero Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 text-white shadow-xl border border-slate-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-semibold">
              <Ticket className="w-3.5 h-3.5" />
              <span>Sadaqat Canteen • Labour Khata & Token Accounts</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-3">
              Labour Monthly Tokens
              <span className="text-base font-normal text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded-lg border border-emerald-800/60">
                Labour Ledger
              </span>
            </h1>
            <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
              Manage monthly canteen tokens issued to workers, track month-end dues, and collect cash directly with automatic deposit into daily cash sales for executive dashboard synchronization.
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => handleOpenIssueModal()}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-sm font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-950/50 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            >
              <Ticket className="w-4 h-4" />
              <span>+ Issue Daily Tokens</span>
            </button>

            <button
              onClick={() => handleOpenPaymentModal()}
              className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold px-4 py-2.5 rounded-xl shadow-lg shadow-indigo-950/50 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            >
              <Wallet className="w-4 h-4" />
              <span>+ Collect Cash</span>
            </button>

            <button
              onClick={() => {
                setEditingWorker(null);
                setWorkerForm({
                  name: '',
                  labourNo: `L-${(labourWorkers.length + 101).toString()}`,
                  canteenId: canteenFilter === 'all' ? 'cant-sadaqat' : canteenFilter,
                  department: '',
                  phone: '',
                  defaultTokenRate: 100,
                  status: 'active',
                  notes: '',
                });
                setShowWorkerModal(true);
              }}
              className="inline-flex items-center gap-2 bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 text-sm font-medium px-3.5 py-2.5 rounded-xl transition-all cursor-pointer"
            >
              <Users className="w-4 h-4 text-emerald-400" />
              <span>Add Labour</span>
            </button>
          </div>
        </div>

        {/* Month & Filter Bar */}
        <div className="relative z-10 mt-6 pt-5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
              <Calendar className="w-4 h-4 text-emerald-400" />
              <span className="text-xs text-slate-400 font-medium">Month:</span>
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-transparent text-sm font-semibold text-white focus:outline-none cursor-pointer"
              >
                {getMonthOptions().map((opt) => (
                  <option key={opt.value} value={opt.value} className="bg-slate-900 text-white">
                    {opt.label} ({opt.value})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
              <Building2 className="w-4 h-4 text-teal-400" />
              <span className="text-xs text-slate-400 font-medium">Branch:</span>
              <select
                value={canteenFilter}
                onChange={(e) => setCanteenFilter(e.target.value)}
                className="bg-transparent text-sm font-semibold text-white focus:outline-none cursor-pointer"
              >
                <option value="all" className="bg-slate-900 text-white">All Branches</option>
                {canteens.map((c) => (
                  <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportExcel}
              className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export Excel</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Core Month-End Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Total Labour Enrolled */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Labour</p>
            <p className="text-2xl font-extrabold text-slate-900 mt-1">
              {monthStats.activeWorkersCount} <span className="text-xs font-normal text-slate-400">workers</span>
            </p>
            <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>Sadaqat Canteen Accounts</span>
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-slate-700">
            <Users className="w-6 h-6" />
          </div>
        </div>

        {/* Metric 2: Tokens Issued This Month */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Tokens Issued</p>
            <p className="text-2xl font-extrabold text-indigo-900 mt-1">
              {monthStats.totalTokens} <span className="text-xs font-normal text-slate-400">Tokens</span>
            </p>
            <p className="text-xs font-bold text-indigo-600 mt-1">
              Value: {formatCurrency(monthStats.totalValue, currencySymbol)}
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
            <Ticket className="w-6 h-6" />
          </div>
        </div>

        {/* Metric 3: Cash Collected & Deposited to Daily Sale */}
        <div className="bg-white rounded-xl p-5 border border-emerald-200 bg-emerald-50/20 shadow-xs flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <p className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">Cash Collected</p>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.5 rounded">
                In Cash Sale
              </span>
            </div>
            <p className="text-2xl font-extrabold text-emerald-700 mt-1">
              {formatCurrency(monthStats.totalCollected, currencySymbol)}
            </p>
            <p className="text-xs text-emerald-600 mt-1 font-medium flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Added to Dashboard Daily Sale</span>
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        {/* Metric 4: Outstanding Balance (Receivables) */}
        <div className="bg-white rounded-xl p-5 border border-amber-200 bg-amber-50/20 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-amber-800 uppercase tracking-wider">Remaining Balance</p>
            <p className="text-2xl font-extrabold text-amber-900 mt-1">
              {formatCurrency(monthStats.totalBalance, currencySymbol)}
            </p>
            <p className="text-xs text-amber-700 mt-1 font-medium">
              Month-End Pending Collections
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center text-amber-700">
            <Wallet className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveSubTab('summary')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'summary'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>Month-End Labour Khata ({workerMonthlySummaries.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('daily_issues')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'daily_issues'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Ticket className="w-4 h-4" />
            <span>Daily Token Issuance Log ({monthlyIssues.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('payments')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'payments'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>Cash Collections ({monthlyPayments.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('workers')}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'workers'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Workers Directory ({filteredWorkers.length})</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search labour name, #, department..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 text-sm bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>
      </div>

      {/* TAB 1: Monthly Labour Summary */}
      {activeSubTab === 'summary' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
            <div>
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <span>Month-End Labour Balance Sheet ({selectedMonth})</span>
                <span className="text-xs font-normal text-slate-500">
                  (Monthly Token Ledger Summary)
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Shows total tokens issued, total bill amount, cash collected, and remaining balance for each worker.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-600 bg-slate-200/80 px-2.5 py-1 rounded-lg">
                Total Month Due: {formatCurrency(monthStats.totalBalance, currencySymbol)}
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold uppercase tracking-wider">
                  <th className="py-3 px-4">Labour / Worker</th>
                  <th className="py-3 px-4">Card / Dept</th>
                  <th className="py-3 px-4 text-center">Rate / Token</th>
                  <th className="py-3 px-4 text-center">Tokens Issued</th>
                  <th className="py-3 px-4 text-right">Total Bill (Rs)</th>
                  <th className="py-3 px-4 text-right">Cash Collected</th>
                  <th className="py-3 px-4 text-right">Balance Due</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {workerMonthlySummaries.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-slate-400">
                      <Ticket className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                      <p className="font-semibold text-slate-700">No labour accounts found</p>
                      <p className="text-xs text-slate-400 mt-1">Add a labour worker to start tracking monthly tokens</p>
                      <button
                        onClick={() => setShowWorkerModal(true)}
                        className="mt-3 inline-flex items-center gap-1.5 bg-emerald-600 text-white text-xs font-semibold px-3 py-1.5 rounded-lg hover:bg-emerald-700 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Register Worker</span>
                      </button>
                    </td>
                  </tr>
                ) : (
                  workerMonthlySummaries.map((summary) => {
                    const isFullyPaid = summary.balance <= 0 && summary.totalAmount > 0;
                    const isPartial = summary.totalCollected > 0 && summary.balance > 0;
                    const isPending = summary.totalCollected === 0 && summary.totalAmount > 0;

                    return (
                      <tr key={summary.worker.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-4 font-semibold text-slate-900">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center shrink-0">
                              {summary.worker.name.slice(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-bold text-slate-900 leading-tight">{summary.worker.name}</p>
                              {summary.worker.phone && (
                                <p className="text-xs text-slate-400">{summary.worker.phone}</p>
                              )}
                            </div>
                          </div>
                        </td>

                        <td className="py-3.5 px-4 text-slate-600">
                          <span className="font-mono text-xs font-bold bg-slate-100 px-2 py-0.5 rounded text-slate-700">
                            {summary.worker.labourNo || '-'}
                          </span>
                          {summary.worker.department && (
                            <p className="text-xs text-slate-500 mt-0.5">{summary.worker.department}</p>
                          )}
                        </td>

                        <td className="py-3.5 px-4 text-center text-slate-700 font-medium">
                          {formatCurrency(summary.worker.defaultTokenRate, currencySymbol)}
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <span className="inline-flex items-center gap-1 font-bold text-indigo-900 bg-indigo-50 px-2.5 py-1 rounded-md text-xs">
                            <Ticket className="w-3 h-3 text-indigo-600" />
                            {summary.totalTokens}
                          </span>
                        </td>

                        <td className="py-3.5 px-4 text-right font-bold text-slate-900">
                          {formatCurrency(summary.totalAmount, currencySymbol)}
                        </td>

                        <td className="py-3.5 px-4 text-right font-bold text-emerald-700">
                          {formatCurrency(summary.totalCollected, currencySymbol)}
                        </td>

                        <td className="py-3.5 px-4 text-right font-extrabold">
                          <span
                            className={
                              summary.balance > 0
                                ? 'text-amber-700 bg-amber-50 px-2 py-0.5 rounded'
                                : summary.totalAmount > 0
                                ? 'text-emerald-700'
                                : 'text-slate-400'
                            }
                          >
                            {formatCurrency(summary.balance, currencySymbol)}
                          </span>
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          {isFullyPaid && (
                            <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 text-xs font-bold px-2 py-0.5 rounded-full">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Cleared</span>
                            </span>
                          )}
                          {isPartial && (
                            <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-800 text-xs font-bold px-2 py-0.5 rounded-full">
                              <Clock className="w-3 h-3" />
                              <span>Partial</span>
                            </span>
                          )}
                          {isPending && (
                            <span className="inline-flex items-center gap-1 bg-rose-100 text-rose-800 text-xs font-bold px-2 py-0.5 rounded-full">
                              <AlertCircle className="w-3 h-3" />
                              <span>Unpaid</span>
                            </span>
                          )}
                          {summary.totalAmount === 0 && (
                            <span className="text-xs text-slate-400 italic">No Tokens</span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {/* Issue Token button */}
                            <button
                              onClick={() => handleOpenIssueModal(summary.worker.id)}
                              title="Issue Tokens to this worker"
                              className="p-1.5 rounded-lg text-indigo-600 hover:bg-indigo-50 transition cursor-pointer"
                            >
                              <Ticket className="w-4 h-4" />
                            </button>

                            {/* Collect Cash button */}
                            <button
                              onClick={() => handleOpenPaymentModal(summary.worker.id, summary.balance)}
                              title="Collect Cash from this worker"
                              className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 transition cursor-pointer font-bold text-xs flex items-center gap-0.5"
                            >
                              <DollarSign className="w-4 h-4" />
                            </button>

                            {/* Print Statement Slip button */}
                            <button
                              onClick={() => setSelectedWorkerForSlip(summary.worker)}
                              title="Print Monthly Bill / Slip"
                              className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100 transition cursor-pointer"
                            >
                              <Printer className="w-4 h-4" />
                            </button>

                            {/* Delete Worker button with in-app confirmation */}
                            {deleteConfirmWorkerId === summary.worker.id ? (
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => {
                                    onDeleteWorker(summary.worker.id);
                                    setDeleteConfirmWorkerId(null);
                                  }}
                                  className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] rounded transition cursor-pointer shadow-xs"
                                >
                                  Delete
                                </button>
                                <button
                                  onClick={() => setDeleteConfirmWorkerId(null)}
                                  className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] rounded transition cursor-pointer"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => setDeleteConfirmWorkerId(summary.worker.id)}
                                title={`Delete ${summary.worker.name}`}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: Daily Token Issuance Log */}
      {activeSubTab === 'daily_issues' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between gap-3 bg-slate-50/50">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                Daily Token Issuance Record ({selectedMonth})
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Every individual token given to workers on daily or shift basis.
              </p>
            </div>
            <button
              onClick={() => handleOpenIssueModal()}
              className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg cursor-pointer transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Issue Tokens</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold uppercase tracking-wider">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Labour Worker</th>
                  <th className="py-3 px-4">Meal / Shift</th>
                  <th className="py-3 px-4 text-center">Qty</th>
                  <th className="py-3 px-4 text-right">Rate</th>
                  <th className="py-3 px-4 text-right">Total Amount</th>
                  <th className="py-3 px-4">Remarks</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {monthlyIssues.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400">
                      No token issues recorded for this month.
                    </td>
                  </tr>
                ) : (
                  monthlyIssues.map((issue) => (
                    <tr key={issue.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-900">
                        {formatDisplayDate(issue.date)}
                      </td>
                      <td className="py-3 px-4 font-bold text-slate-800">
                        {issue.labourName}
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        <span className="bg-slate-100 px-2 py-0.5 rounded text-xs">
                          {issue.mealType || 'General'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center font-bold text-indigo-900">
                        {issue.tokenQty && issue.tokenQty > 0 ? issue.tokenQty : '—'}
                      </td>
                      <td className="py-3 px-4 text-right text-slate-700">
                        {issue.tokenRate && issue.tokenRate > 0 ? formatCurrency(issue.tokenRate, currencySymbol) : '—'}
                      </td>
                      <td className="py-3 px-4 text-right font-extrabold text-slate-900">
                        {formatCurrency(issue.totalAmount, currencySymbol)}
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-500">
                        {issue.remarks || '-'}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {deleteConfirmIssueId === issue.id ? (
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => {
                                onDeleteTokenIssue(issue.id);
                                setDeleteConfirmIssueId(null);
                              }}
                              className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] rounded transition cursor-pointer shadow-xs"
                            >
                              Delete
                            </button>
                            <button
                              onClick={() => setDeleteConfirmIssueId(null)}
                              className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] rounded transition cursor-pointer"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirmIssueId(issue.id)}
                            title="Delete this token issue record"
                            className="p-1 rounded text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: Cash Collections & Daily Cash Sale Integration */}
      {activeSubTab === 'payments' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
            <div>
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <span>Cash Collection & Daily Sale Integration Log</span>
                <span className="bg-emerald-100 text-emerald-800 text-xs px-2 py-0.5 rounded-full font-semibold">
                  Auto Daily Cash Sale Deposit
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Every cash payment collected from labour is safely recorded here and credited to Daily Cash Sales.
              </p>
            </div>
            <button
              onClick={() => handleOpenPaymentModal()}
              className="inline-flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg cursor-pointer transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Record Cash Payment</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold uppercase tracking-wider">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Labour Worker</th>
                  <th className="py-3 px-4">Month Settled</th>
                  <th className="py-3 px-4">Payment Method</th>
                  <th className="py-3 px-4 text-right">Amount Collected</th>
                  <th className="py-3 px-4 text-center">Daily Cash Sale Status</th>
                  <th className="py-3 px-4">Notes</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {monthlyPayments.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400">
                      No cash collections recorded for this month.
                    </td>
                  </tr>
                ) : (
                  monthlyPayments.map((pay) => (
                    <tr key={pay.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-900">
                        {formatDisplayDate(pay.date)}
                      </td>
                      <td className="py-3 px-4 font-bold text-slate-800">
                        {pay.labourName}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-600">
                        {pay.month}
                      </td>
                      <td className="py-3 px-4 text-slate-700">
                        <span className="bg-slate-100 px-2 py-0.5 rounded text-xs font-semibold">
                          {pay.paymentMethod}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-extrabold text-emerald-700">
                        {formatCurrency(pay.amount, currencySymbol)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {pay.depositedToDailySale ? (
                          <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-0.5 rounded-full">
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span>Added to Daily Cash Sale</span>
                          </span>
                        ) : (
                          <span className="text-xs text-slate-400">Manual Ledger Only</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-500">
                        {pay.notes || '-'}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {deleteConfirmPaymentId === pay.id ? (
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => {
                                onDeletePayment(pay.id);
                                setDeleteConfirmPaymentId(null);
                              }}
                              className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] rounded transition cursor-pointer shadow-xs"
                            >
                              Delete
                            </button>
                            <button
                              onClick={() => setDeleteConfirmPaymentId(null)}
                              className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] rounded transition cursor-pointer"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirmPaymentId(pay.id)}
                            title="Delete this payment record"
                            className="p-1 rounded text-rose-500 hover:bg-rose-50 transition cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: Workers Directory */}
      {activeSubTab === 'workers' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between gap-3 bg-slate-50/50">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                Enrolled Labour Workers & Contractors
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Register workers at Sadaqat Canteen to issue monthly tokens on credit.
              </p>
            </div>
            <button
              onClick={() => {
                setEditingWorker(null);
                setWorkerForm({
                  name: '',
                  labourNo: `L-${(labourWorkers.length + 101).toString()}`,
                  canteenId: canteenFilter === 'all' ? 'cant-sadaqat' : canteenFilter,
                  department: '',
                  phone: '',
                  defaultTokenRate: 100,
                  status: 'active',
                  notes: '',
                });
                setShowWorkerModal(true);
              }}
              className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg cursor-pointer transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Register Worker</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold uppercase tracking-wider">
                  <th className="py-3 px-4">Labour Name</th>
                  <th className="py-3 px-4">Token Card / #</th>
                  <th className="py-3 px-4">Canteen / Branch</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Phone</th>
                  <th className="py-3 px-4 text-center">Default Token Rate</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredWorkers.map((worker) => (
                  <tr key={worker.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      {worker.name}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-xs font-bold text-slate-700">
                      {worker.labourNo || '-'}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {worker.canteenName}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {worker.department || '-'}
                    </td>
                    <td className="py-3.5 px-4 text-slate-500 font-mono text-xs">
                      {worker.phone || '-'}
                    </td>
                    <td className="py-3.5 px-4 text-center font-bold text-slate-800">
                      {formatCurrency(worker.defaultTokenRate, currencySymbol)}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span
                        className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                          worker.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {worker.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => {
                            setEditingWorker(worker);
                            setWorkerForm({
                              name: worker.name,
                              labourNo: worker.labourNo || '',
                              canteenId: worker.canteenId,
                              department: worker.department || '',
                              phone: worker.phone || '',
                              defaultTokenRate: worker.defaultTokenRate || 100,
                              status: worker.status,
                              notes: worker.notes || '',
                            });
                            setShowWorkerModal(true);
                          }}
                          className="p-1 text-slate-500 hover:text-slate-900 transition cursor-pointer"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        {deleteConfirmWorkerId === worker.id ? (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                onDeleteWorker(worker.id);
                                setDeleteConfirmWorkerId(null);
                              }}
                              className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] rounded transition cursor-pointer shadow-xs"
                            >
                              Delete
                            </button>
                            <button
                              onClick={() => setDeleteConfirmWorkerId(null)}
                              className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] rounded transition cursor-pointer"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirmWorkerId(worker.id)}
                            title={`Delete ${worker.name}`}
                            className="p-1 text-rose-500 hover:bg-rose-50 rounded transition cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL 1: Issue Tokens */}
      {showIssueModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                <Ticket className="w-5 h-5 text-emerald-600" />
                <span>Issue Daily Tokens to Labour</span>
              </h3>
              <button
                onClick={() => setShowIssueModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitIssue} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Select Labour Worker *
                </label>
                <select
                  required
                  value={issueForm.labourId}
                  onChange={(e) => {
                    const worker = labourWorkers.find((w) => w.id === e.target.value);
                    setIssueForm((prev) => ({
                      ...prev,
                      labourId: e.target.value,
                      tokenRate: worker?.defaultTokenRate || prev.tokenRate,
                    }));
                  }}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium text-slate-800"
                >
                  <option value="">-- Choose Worker --</option>
                  {labourWorkers
                    .filter((w) => canteenFilter === 'all' || w.canteenId === canteenFilter)
                    .map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name} {w.labourNo ? `(${w.labourNo})` : ''} - {w.canteenName}
                      </option>
                    ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={issueForm.date}
                    onChange={(e) => setIssueForm({ ...issueForm, date: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Meal / Shift Type
                  </label>
                  <select
                    value={issueForm.mealType}
                    onChange={(e) => setIssueForm({ ...issueForm, mealType: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Lunch">Lunch</option>
                    <option value="Dinner">Dinner</option>
                    <option value="Breakfast">Breakfast / Tea</option>
                    <option value="General">General / All-Day</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-slate-700">
                      Token Quantity
                    </label>
                    <span className="text-[10px] text-slate-400 font-medium">Optional</span>
                  </div>
                  <input
                    type="number"
                    min="0"
                    placeholder="e.g. 5 (Khali bhi chhor saktay hain)"
                    value={issueForm.tokenQty}
                    onChange={(e) => {
                      const qty = e.target.value;
                      let newTotal = issueForm.totalAmount;
                      if (qty !== '' && issueForm.tokenRate !== '') {
                        newTotal = (Number(qty) * Number(issueForm.tokenRate)).toString();
                      }
                      setIssueForm({ ...issueForm, tokenQty: qty, totalAmount: newTotal });
                    }}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-slate-700">
                      Rate per Token (Rs)
                    </label>
                    <span className="text-[10px] text-slate-400 font-medium">Optional</span>
                  </div>
                  <input
                    type="number"
                    min="0"
                    placeholder="e.g. 100"
                    value={issueForm.tokenRate}
                    onChange={(e) => {
                      const rate = e.target.value;
                      let newTotal = issueForm.totalAmount;
                      if (rate !== '' && issueForm.tokenQty !== '') {
                        newTotal = (Number(issueForm.tokenQty) * Number(rate)).toString();
                      }
                      setIssueForm({ ...issueForm, tokenRate: rate, totalAmount: newTotal });
                    }}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                  />
                </div>
              </div>

              {/* Total Amount Input (Directly editable / Optional / Auto-calculated) */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-800">
                    Total Khata Amount (Rs) (Optional / Khud Likhein)
                  </label>
                  <span className="text-[11px] text-emerald-700 font-semibold">Direct amount enter kar saktay hain</span>
                </div>
                <input
                  type="number"
                  min="0"
                  placeholder="e.g. 500, 1500 (Direct amount likhein ya tokens enter karein)"
                  value={issueForm.totalAmount}
                  onChange={(e) => setIssueForm({ ...issueForm, totalAmount: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-base bg-emerald-50/60 border-2 border-emerald-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-black text-emerald-950 placeholder:text-slate-400 font-mono"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Tokens aur rate likhenge to amount khud ban jaye gi, ya aap direct yahan amount bhi likh saktay hain.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Remarks / Notes
                </label>
                <input
                  type="text"
                  placeholder="e.g. Shift 1 tokens, contractor boys"
                  value={issueForm.remarks}
                  onChange={(e) => setIssueForm({ ...issueForm, remarks: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowIssueModal(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition"
                >
                  Confirm & Issue
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Collect Cash & Auto-deposit into Daily Sale */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                  <Wallet className="w-5 h-5 text-indigo-600" />
                  <span>Collect Labour Cash</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Record cash collection from labour or contractor
                </p>
              </div>
              <button
                onClick={() => setShowPaymentModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitPayment} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Select Labour Worker *
                </label>
                <select
                  required
                  value={paymentForm.labourId}
                  onChange={(e) => {
                    const summary = workerMonthlySummaries.find((s) => s.worker.id === e.target.value);
                    setPaymentForm((prev) => ({
                      ...prev,
                      labourId: e.target.value,
                      amount: summary && summary.balance > 0 ? summary.balance : prev.amount,
                    }));
                  }}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium text-slate-800"
                >
                  <option value="">-- Choose Worker --</option>
                  {labourWorkers.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name} {w.labourNo ? `(${w.labourNo})` : ''} - {w.canteenName}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Payment Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={paymentForm.date}
                    onChange={(e) => setPaymentForm({ ...paymentForm, date: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Amount Collected (Rs) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={paymentForm.amount}
                    onChange={(e) => setPaymentForm({ ...paymentForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-emerald-700"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Payment Method
                </label>
                <select
                  value={paymentForm.paymentMethod}
                  onChange={(e: any) => setPaymentForm({ ...paymentForm, paymentMethod: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Cash">Cash</option>
                  <option value="Online / Bank">Online / EasyPaisa / JazzCash</option>
                  <option value="Salary Deduction">Salary Deduction</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              {/* CRITICAL FEATURE: Option to credit cash into Daily Cash Sale for Dashboard */}
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2">
                <label className="flex items-start gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={paymentForm.depositedToDailySale}
                    onChange={(e) => setPaymentForm({ ...paymentForm, depositedToDailySale: e.target.checked })}
                    className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                  />
                  <div>
                    <span className="text-xs font-bold text-emerald-900 block">
                      Deposit to Today's Daily Cash Sale
                    </span>
                    <span className="text-[11px] text-emerald-700 block leading-tight mt-0.5">
                      This cash will be credited into the canteen's Daily Cash Sales (Normal Sale) and reflected on the dashboard.
                    </span>
                  </div>
                </label>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Notes / Receipt Details
                </label>
                <input
                  type="text"
                  placeholder="e.g. Month-end cash settlement from worker"
                  value={paymentForm.notes}
                  onChange={(e) => setPaymentForm({ ...paymentForm, notes: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md transition"
                >
                  Record Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Worker Add / Edit */}
      {showWorkerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-600" />
                <span>{editingWorker ? 'Edit Labour Worker' : 'Register New Labour Worker'}</span>
              </h3>
              <button
                onClick={() => setShowWorkerModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitWorker} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Worker / Contractor Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Muhammad Rashid or Contractor Team"
                  value={workerForm.name}
                  onChange={(e) => setWorkerForm({ ...workerForm, name: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Labour / Card #
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. L-101"
                    value={workerForm.labourNo}
                    onChange={(e) => setWorkerForm({ ...workerForm, labourNo: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Canteen Branch *
                  </label>
                  <select
                    value={workerForm.canteenId}
                    onChange={(e) => setWorkerForm({ ...workerForm, canteenId: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {canteens.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Department / Unit
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Weaving Unit 1"
                    value={workerForm.department}
                    onChange={(e) => setWorkerForm({ ...workerForm, department: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Phone / Contact
                  </label>
                  <input
                    type="text"
                    placeholder="0300-1234567"
                    value={workerForm.phone}
                    onChange={(e) => setWorkerForm({ ...workerForm, phone: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-slate-700">
                      Default Token Rate (Rs)
                    </label>
                    <span className="text-[10px] text-slate-400 font-medium">Optional</span>
                  </div>
                  <input
                    type="number"
                    min="0"
                    placeholder="e.g. 100"
                    value={workerForm.defaultTokenRate || ''}
                    onChange={(e) => setWorkerForm({ ...workerForm, defaultTokenRate: Number(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Status
                  </label>
                  <select
                    value={workerForm.status}
                    onChange={(e: any) => setWorkerForm({ ...workerForm, status: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Notes
                </label>
                <input
                  type="text"
                  placeholder="Additional worker info"
                  value={workerForm.notes}
                  onChange={(e) => setWorkerForm({ ...workerForm, notes: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowWorkerModal(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition"
                >
                  {editingWorker ? 'Update Worker' : 'Save Worker'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PRINTABLE SLIP MODAL */}
      {selectedWorkerForSlip && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <Printer className="w-5 h-5 text-indigo-600" />
                <span>Monthly Labour Token Slip / Bill</span>
              </h3>
              <button
                onClick={() => setSelectedWorkerForSlip(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Slip Paper Content */}
            <div className="mt-4 p-5 border border-slate-300 rounded-xl bg-slate-50/50 space-y-4 text-slate-800">
              {/* Slip Header */}
              <div className="text-center border-b border-slate-200 pb-3">
                <h2 className="font-extrabold text-lg tracking-tight text-slate-900">
                  {selectedWorkerForSlip.canteenName || 'SADAQAT CANTEEN'}
                </h2>
                <p className="text-xs font-medium text-slate-500">
                  MONTHLY LABOUR TOKEN KHATA STATEMENT
                </p>
                <p className="text-xs font-bold text-indigo-800 mt-1">
                  Billing Period: {selectedMonth}
                </p>
              </div>

              {/* Worker Details */}
              <div className="grid grid-cols-2 gap-2 text-xs border-b border-slate-200 pb-3">
                <div>
                  <span className="text-slate-500">Labour Name:</span>{' '}
                  <span className="font-bold text-slate-900">{selectedWorkerForSlip.name}</span>
                </div>
                <div>
                  <span className="text-slate-500">Labour / Card #:</span>{' '}
                  <span className="font-mono font-bold text-slate-900">{selectedWorkerForSlip.labourNo || '-'}</span>
                </div>
                <div>
                  <span className="text-slate-500">Department:</span>{' '}
                  <span className="font-semibold text-slate-800">{selectedWorkerForSlip.department || '-'}</span>
                </div>
                <div>
                  <span className="text-slate-500">Contact:</span>{' '}
                  <span className="font-mono text-slate-800">{selectedWorkerForSlip.phone || '-'}</span>
                </div>
              </div>

              {/* Tokens Table */}
              <div className="space-y-2">
                <p className="text-xs font-bold uppercase text-slate-600">Daily Token Log:</p>
                <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-lg bg-white">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-100 border-b border-slate-200 text-slate-600 font-bold">
                      <tr>
                        <th className="p-2">Date</th>
                        <th className="p-2 text-center">Qty</th>
                        <th className="p-2 text-right">Rate</th>
                        <th className="p-2 text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {labourTokenIssues
                        .filter(
                          (issue) =>
                            issue.labourId === selectedWorkerForSlip.id && issue.month === selectedMonth
                        )
                        .map((issue) => (
                          <tr key={issue.id}>
                            <td className="p-2 text-slate-700">{formatDisplayDate(issue.date)}</td>
                            <td className="p-2 text-center font-bold text-indigo-900">{issue.tokenQty}</td>
                            <td className="p-2 text-right text-slate-600">{issue.tokenRate}</td>
                            <td className="p-2 text-right font-bold text-slate-900">{issue.totalAmount}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Financial Calculation */}
              {(() => {
                const summary = workerMonthlySummaries.find((s) => s.worker.id === selectedWorkerForSlip.id);
                return (
                  <div className="bg-slate-100 p-3 rounded-lg space-y-1.5 text-xs font-semibold">
                    <div className="flex justify-between text-slate-700">
                      <span>Total Tokens Issued:</span>
                      <span className="font-bold text-slate-900">{summary?.totalTokens || 0}</span>
                    </div>
                    <div className="flex justify-between text-slate-700">
                      <span>Total Token Bill:</span>
                      <span className="font-bold text-slate-900">{formatCurrency(summary?.totalAmount || 0, currencySymbol)}</span>
                    </div>
                    <div className="flex justify-between text-emerald-700">
                      <span>Cash Paid / Collected:</span>
                      <span className="font-bold text-emerald-800">{formatCurrency(summary?.totalCollected || 0, currencySymbol)}</span>
                    </div>
                    <div className="flex justify-between text-sm font-extrabold pt-1 border-t border-slate-300 text-slate-900">
                      <span>Net Balance Due:</span>
                      <span className={summary && summary.balance > 0 ? 'text-amber-700' : 'text-emerald-700'}>
                        {formatCurrency(summary?.balance || 0, currencySymbol)}
                      </span>
                    </div>
                  </div>
                );
              })()}

              {/* Signatures */}
              <div className="grid grid-cols-2 gap-4 pt-4 text-xs text-center">
                <div className="border-t border-slate-400 pt-1 text-slate-600">
                  Canteen Incharge Signature
                </div>
                <div className="border-t border-slate-400 pt-1 text-slate-600">
                  Labour / Worker Signature
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-4 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedWorkerForSlip(null)}
                className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 px-5 py-2 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md transition cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Slip</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

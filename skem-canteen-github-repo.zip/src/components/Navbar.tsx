import React, { useState } from 'react';
import {
  LayoutDashboard,
  Receipt,
  CalendarCheck,
  Users,
  Wallet,
  FileSpreadsheet,
  Building2,
  Settings,
  Menu,
  X,
  PlusCircle,
  Coffee,
  Lock,
  Cloud,
  CloudOff,
  RefreshCw,
  FileText,
  Handshake,
  Layers,
  Ticket,
  Coins,
} from 'lucide-react';
import { Canteen } from '../types';

export type NavTab =
  | 'dashboard'
  | 'daily_entry'
  | 'petty_cash'
  | 'invoices'
  | 'parties'
  | 'labour_tokens'
  | 'window_sales'
  | 'attendance'
  | 'staff'
  | 'financials'
  | 'reports'
  | 'canteens'
  | 'settings';

interface NavbarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  canteens: Canteen[];
  selectedCanteenId: string;
  setSelectedCanteenId: (id: string) => void;
  onQuickAddEntry: () => void;
  hasPin?: boolean;
  onLockApp?: () => void;
  lockedCanteenId?: string;
  cloudStatus?: 'connecting' | 'synced' | 'offline' | 'error';
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  canteens,
  selectedCanteenId,
  setSelectedCanteenId,
  onQuickAddEntry,
  hasPin = false,
  onLockApp,
  lockedCanteenId,
  cloudStatus = 'synced',
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'dashboard' as NavTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'daily_entry' as NavTab, label: 'Daily Entry', icon: Receipt },
    { id: 'petty_cash' as NavTab, label: 'Petty Cash', icon: Coins },
    { id: 'invoices' as NavTab, label: 'Invoices', icon: FileText },
    { id: 'parties' as NavTab, label: 'Parties & Khata', icon: Handshake },
    { id: 'labour_tokens' as NavTab, label: 'Labour Tokens', icon: Ticket },
    { id: 'window_sales' as NavTab, label: 'Window Shifts', icon: Layers },
    { id: 'attendance' as NavTab, label: 'Attendance', icon: CalendarCheck },
    { id: 'staff' as NavTab, label: 'Staff', icon: Users },
    { id: 'financials' as NavTab, label: 'Advances & Penalties', icon: Wallet },
    { id: 'reports' as NavTab, label: 'Reports', icon: FileSpreadsheet },
    { id: 'canteens' as NavTab, label: 'Canteens', icon: Building2 },
    { id: 'settings' as NavTab, label: 'Settings', icon: Settings },
  ];

  const handleNavClick = (tab: NavTab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  const activeCanteens = canteens.filter((c) => c.status === 'active');

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-sm font-bold text-lg overflow-hidden relative">
              <img
                src="/icon-192.jpg"
                alt="SKEM Canteens Icon"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
              <Coffee className="w-6 h-6 absolute inset-0 m-auto -z-10" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-900 tracking-tight text-lg sm:text-xl">
                  SKEM Canteens
                </span>
                <span className="bg-emerald-100 text-emerald-800 text-xs font-semibold px-2 py-0.5 rounded-full">
                  Management
                </span>
                {cloudStatus === 'synced' && (
                  <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] sm:text-[11px] font-bold px-2 py-0.5 rounded-full" title="Firebase Cloud Database Connected - Auto-Saved Forever across all devices">
                    <Cloud className="w-3 h-3 text-emerald-600" />
                    <span>Saved to Cloud</span>
                  </span>
                )}
                {cloudStatus === 'connecting' && (
                  <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-200 text-[10px] sm:text-[11px] font-bold px-2 py-0.5 rounded-full">
                    <RefreshCw className="w-3 h-3 text-amber-600 animate-spin" />
                    <span>Syncing...</span>
                  </span>
                )}
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      if ('caches' in window) {
                        const keys = await caches.keys();
                        await Promise.all(keys.map((k) => caches.delete(k)));
                      }
                      if ('serviceWorker' in navigator) {
                        const regs = await navigator.serviceWorker.getRegistrations();
                        for (const r of regs) await r.unregister();
                      }
                    } catch (e) {}
                    window.location.reload();
                  }}
                  className="inline-flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 text-[10px] sm:text-[11px] font-bold px-2 py-0.5 rounded-full cursor-pointer transition-colors active:scale-95 ml-0.5"
                  title="Click to clear cache and reload latest software updates"
                >
                  <RefreshCw className="w-2.5 h-2.5 text-slate-600" />
                  <span>Refresh App</span>
                </button>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                Daily Sales, Expenses & Staff Management
              </p>
            </div>
          </div>

          {/* Desktop Canteen Selector & Quick Action */}
          <div className="hidden lg:flex items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-100/80 px-3 py-1.5 rounded-xl border border-slate-200">
              <Building2 className="w-4 h-4 text-slate-500" />
              <span className="text-xs font-medium text-slate-600">Canteen:</span>
              <select
                value={lockedCanteenId || selectedCanteenId}
                disabled={Boolean(lockedCanteenId)}
                onChange={(e) => setSelectedCanteenId(e.target.value)}
                className="bg-transparent text-sm font-semibold text-slate-800 focus:outline-none cursor-pointer pr-1 disabled:opacity-80"
              >
                {!lockedCanteenId && <option value="all">All Canteens ({activeCanteens.length})</option>}
                {activeCanteens.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} {lockedCanteenId === c.id ? '(Locked Branch)' : ''}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={onQuickAddEntry}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold px-4 py-2 rounded-xl transition-all shadow-xs hover:shadow-md cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>New Daily Entry</span>
            </button>

            {hasPin && onLockApp && (
              <button
                onClick={onLockApp}
                className="flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold px-3 py-2 rounded-xl transition-all cursor-pointer border border-rose-200"
                title="Lock App / Log Out"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Lock</span>
              </button>
            )}
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex lg:hidden items-center gap-2">
            {hasPin && onLockApp && (
              <button
                onClick={onLockApp}
                className="p-2 bg-rose-50 text-rose-700 rounded-xl text-xs font-bold border border-rose-200"
                title="Lock App"
              >
                <Lock className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onQuickAddEntry}
              className="p-2 bg-emerald-600 text-white rounded-xl text-xs font-semibold flex items-center gap-1"
              title="Add Daily Entry"
            >
              <PlusCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Entry</span>
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Desktop Navigation Tabs */}
        <nav className="hidden lg:flex items-center gap-1 overflow-x-auto pb-0 -mb-px">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'border-emerald-600 text-emerald-700 bg-emerald-50/50 rounded-t-lg'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-4 shadow-lg animate-in slide-in-from-top-2">
          {/* Canteen Filter in Mobile */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              Active Canteen Filter
            </label>
            <select
              value={selectedCanteenId}
              onChange={(e) => setSelectedCanteenId(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg p-2 text-sm font-semibold text-slate-800"
            >
              <option value="all">All Canteens ({activeCanteens.length})</option>
              {activeCanteens.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Icon
                    className={`w-5 h-5 mb-1.5 ${
                      isActive ? 'text-emerald-600' : 'text-slate-500'
                    }`}
                  />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};

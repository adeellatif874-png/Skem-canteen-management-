import React, { useState } from 'react';
import { Lock, KeyRound, ShieldAlert, CheckCircle, Unlock } from 'lucide-react';

interface LockScreenModalProps {
  isOpen: boolean;
  pinCode: string;
  onUnlock: () => void;
  onResetPinEmergency?: () => void;
}

export const LockScreenModal: React.FC<LockScreenModalProps> = ({
  isOpen,
  pinCode,
  onUnlock,
  onResetPinEmergency,
}) => {
  const [enteredPin, setEnteredPin] = useState('');
  const [error, setError] = useState(false);

  if (!isOpen) return null;

  const handleKeyPress = (num: string) => {
    if (enteredPin.length < 6) {
      const next = enteredPin + num;
      setEnteredPin(next);
      setError(false);
      if (next === pinCode) {
        setTimeout(() => {
          setEnteredPin('');
          onUnlock();
        }, 150);
      } else if (next.length >= pinCode.length) {
        setError(true);
      }
    }
  };

  const handleDelete = () => {
    setEnteredPin((prev) => prev.slice(0, -1));
    setError(false);
  };

  const handleClear = () => {
    setEnteredPin('');
    setError(false);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-sm w-full p-8 shadow-2xl border border-slate-200 text-center space-y-6">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto shadow-inner">
          <Lock className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">
            SKEM Canteens Locked
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Enter Manager Security PIN to access canteen reports and daily entries
          </p>
        </div>

        {/* PIN Indicators */}
        <div className="flex justify-center gap-3 py-2">
          {Array.from({ length: Math.max(4, pinCode.length) }).map((_, idx) => {
            const filled = idx < enteredPin.length;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full border-2 transition-all ${
                  error
                    ? 'border-rose-500 bg-rose-500 animate-shake'
                    : filled
                    ? 'border-emerald-600 bg-emerald-600 scale-110 shadow-xs'
                    : 'border-slate-300 bg-slate-100'
                }`}
              />
            );
          })}
        </div>

        {error && (
          <p className="text-xs font-bold text-rose-600 flex items-center justify-center gap-1 animate-in fade-in">
            <ShieldAlert className="w-4 h-4" />
            <span>Incorrect Security PIN. Try again!</span>
          </p>
        )}

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-3 max-w-[240px] mx-auto pt-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
            <button
              key={num}
              onClick={() => handleKeyPress(num)}
              className="h-12 rounded-2xl bg-slate-100 hover:bg-slate-200 active:bg-emerald-100 text-slate-900 font-extrabold text-xl flex items-center justify-center transition-all active:scale-95 cursor-pointer shadow-2xs"
            >
              {num}
            </button>
          ))}
          <button
            onClick={handleClear}
            className="h-12 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs flex items-center justify-center transition-all cursor-pointer"
          >
            Clear
          </button>
          <button
            onClick={() => handleKeyPress('0')}
            className="h-12 rounded-2xl bg-slate-100 hover:bg-slate-200 active:bg-emerald-100 text-slate-900 font-extrabold text-xl flex items-center justify-center transition-all active:scale-95 cursor-pointer shadow-2xs"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="h-12 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs flex items-center justify-center transition-all cursor-pointer"
          >
            ⌫
          </button>
        </div>

        {/* Forgot PIN Emergency helper */}
        <div className="pt-2 text-[11px] text-slate-400">
          Default PIN is <strong className="text-slate-600 font-mono">1234</strong> (if set)
        </div>
      </div>
    </div>
  );
};

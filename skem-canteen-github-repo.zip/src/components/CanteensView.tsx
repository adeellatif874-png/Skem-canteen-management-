import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Edit2,
  Trash2,
  Power,
  Search,
  Phone,
  User,
  MapPin,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { Canteen, CanteenStatus } from '../types';
import { ConfirmModal } from './ConfirmModal';

interface CanteensViewProps {
  canteens: Canteen[];
  onAddCanteen: (canteen: Omit<Canteen, 'id' | 'createdAt'>) => void;
  onEditCanteen: (id: string, updated: Partial<Canteen>) => void;
  onDeleteCanteen: (id: string) => void;
}

export const CanteensView: React.FC<CanteensViewProps> = ({
  canteens,
  onAddCanteen,
  onEditCanteen,
  onDeleteCanteen,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingCanteen, setEditingCanteen] = useState<Canteen | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [location, setLocation] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');
  const [status, setStatus] = useState<CanteenStatus>('active');

  // Delete Confirmation State
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  const filteredCanteens = canteens.filter(
    (c) =>
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.location && c.location.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const openAddModal = () => {
    setEditingCanteen(null);
    setName('');
    setCode(`CAN-0${canteens.length + 1}`);
    setLocation('');
    setContactPerson('');
    setPhone('');
    setStatus('active');
    setModalOpen(true);
  };

  const openEditModal = (canteen: Canteen) => {
    setEditingCanteen(canteen);
    setName(canteen.name);
    setCode(canteen.code);
    setLocation(canteen.location || '');
    setContactPerson(canteen.contactPerson || '');
    setPhone(canteen.phone || '');
    setStatus(canteen.status);
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim()) return;

    if (editingCanteen) {
      onEditCanteen(editingCanteen.id, {
        name: name.trim(),
        code: code.trim(),
        location: location.trim(),
        contactPerson: contactPerson.trim(),
        phone: phone.trim(),
        status,
      });
    } else {
      onAddCanteen({
        name: name.trim(),
        code: code.trim(),
        location: location.trim(),
        contactPerson: contactPerson.trim(),
        phone: phone.trim(),
        status,
      });
    }
    setModalOpen(false);
  };

  const handleToggleStatus = (canteen: Canteen) => {
    const newStatus: CanteenStatus = canteen.status === 'active' ? 'inactive' : 'active';
    onEditCanteen(canteen.id, { status: newStatus });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Building2 className="w-7 h-7 text-emerald-600" />
            <span>Manage Canteens</span>
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Add, configure and activate or deactivate canteens in the system
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-xs transition-colors cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Canteen</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          placeholder="Search canteens by name, code or location..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-white border border-slate-200 rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-xs font-medium"
        />
      </div>

      {/* Canteen Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredCanteens.length === 0 ? (
          <div className="col-span-full bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-400">
            <Building2 className="w-12 h-12 mx-auto mb-3 opacity-30 text-slate-500" />
            <p className="text-base font-semibold text-slate-600">No Canteens Found</p>
            <p className="text-xs text-slate-400 mt-1">
              Try adjusting your search query or click "Add New Canteen" above.
            </p>
          </div>
        ) : (
          filteredCanteens.map((canteen) => (
            <div
              key={canteen.id}
              className={`bg-white rounded-2xl border transition-all shadow-xs flex flex-col justify-between overflow-hidden ${
                canteen.status === 'active'
                  ? 'border-slate-200 hover:border-emerald-300 hover:shadow-md'
                  : 'border-slate-200 bg-slate-50/60 opacity-80'
              }`}
            >
              <div className="p-5">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      {canteen.code}
                    </span>
                    <h3 className="text-lg font-bold text-slate-900 mt-2">{canteen.name}</h3>
                  </div>

                  <span
                    className={`px-2.5 py-1 text-xs font-bold rounded-full flex items-center gap-1 ${
                      canteen.status === 'active'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {canteen.status === 'active' ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" /> Active
                      </>
                    ) : (
                      <>
                        <XCircle className="w-3.5 h-3.5" /> Inactive
                      </>
                    )}
                  </span>
                </div>

                <div className="mt-4 space-y-2 text-xs text-slate-600">
                  {canteen.location && (
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                      <span className="truncate">{canteen.location}</span>
                    </div>
                  )}
                  {canteen.contactPerson && (
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-slate-400 shrink-0" />
                      <span>Incharge: {canteen.contactPerson}</span>
                    </div>
                  )}
                  {canteen.phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                      <span>{canteen.phone}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Card Footer Action Bar */}
              <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
                <button
                  onClick={() => handleToggleStatus(canteen)}
                  className={`flex items-center gap-1.5 font-semibold transition-colors cursor-pointer ${
                    canteen.status === 'active'
                      ? 'text-slate-600 hover:text-slate-900'
                      : 'text-emerald-600 hover:text-emerald-700'
                  }`}
                  title={canteen.status === 'active' ? 'Deactivate Canteen' : 'Activate Canteen'}
                >
                  <Power className="w-3.5 h-3.5" />
                  <span>{canteen.status === 'active' ? 'Deactivate' : 'Activate'}</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openEditModal(canteen)}
                    className="p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-200 transition-colors cursor-pointer"
                    title="Edit Canteen"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setDeleteTargetId(canteen.id)}
                    className="p-1.5 rounded-lg text-rose-600 hover:text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer"
                    title="Delete Canteen"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal Add / Edit Canteen */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">
                {editingCanteen ? 'Edit Canteen' : 'Add New Canteen'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Canteen Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Main Campus Canteen"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Canteen Code *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. MCC-01"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as CanteenStatus)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Location / Address (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Academic Block A, Ground Floor"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Contact Person (Incharge)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Muhammad Tariq"
                    value={contactPerson}
                    onChange={(e) => setContactPerson(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 0300-1234567"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 text-sm font-semibold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 text-sm font-semibold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 cursor-pointer shadow-xs"
                >
                  {editingCanteen ? 'Save Changes' : 'Create Canteen'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={deleteTargetId !== null}
        title="Delete Canteen?"
        message="Are you sure you want to delete this canteen? Data associated with this canteen will be unlinked or removed."
        confirmLabel="Delete Canteen"
        onConfirm={() => {
          if (deleteTargetId) onDeleteCanteen(deleteTargetId);
          setDeleteTargetId(null);
        }}
        onClose={() => setDeleteTargetId(null)}
      />
    </div>
  );
};

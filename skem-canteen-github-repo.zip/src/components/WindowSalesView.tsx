import React, { useState, useMemo } from 'react';
import {
  Layers,
  Calendar,
  Clock,
  TrendingUp,
  TrendingDown,
  Plus,
  Search,
  Filter,
  FileSpreadsheet,
  Printer,
  Trash2,
  Edit2,
  X,
  Store,
  CheckCircle2,
  HelpCircle,
  BarChart3,
  ArrowRight,
} from 'lucide-react';
import { WindowShiftSale, Canteen, PRESET_WINDOWS, PRESET_SHIFTS } from '../types';
import { formatCurrency, formatDisplayDate } from '../lib/storage';
import { exportWindowSalesExcel } from '../lib/windowSalesData';

interface WindowSalesViewProps {
  windowSales: WindowShiftSale[];
  canteens: Canteen[];
  currencySymbol: string;
  onAddWindowSale: (sale: Omit<WindowShiftSale, 'id' | 'createdAt'>) => void;
  onEditWindowSale: (sale: WindowShiftSale) => void;
  onDeleteWindowSale: (id: string) => void;
}

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export const WindowSalesView: React.FC<WindowSalesViewProps> = ({
  windowSales = [],
  canteens = [],
  currencySymbol = 'Rs.',
  onAddWindowSale,
  onEditWindowSale,
  onDeleteWindowSale,
}) => {
  const [selectedCanteenId, setSelectedCanteenId] = useState<string>('all');
  const [selectedWindow, setSelectedWindow] = useState<string>('all');
  const [selectedShift, setSelectedShift] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSale, setEditingSale] = useState<WindowShiftSale | null>(null);

  // Form State
  const [formDate, setFormDate] = useState(new Date().toISOString().split('T')[0]);
  const [formCanteenId, setFormCanteenId] = useState(canteens[0]?.id || '');
  const [formWindow, setFormWindow] = useState<string>(PRESET_WINDOWS[0]);
  const [formShift, setFormShift] = useState<string>(PRESET_SHIFTS[0]);
  const [formCashSales, setFormCashSales] = useState<string>('');
  const [formTokenSales, setFormTokenSales] = useState<string>('');
  const [formOperator, setFormOperator] = useState('');
  const [formNotes, setFormNotes] = useState('');

  // Filtered sales
  const filteredSales = useMemo(() => {
    return windowSales.filter((sale) => {
      const matchCanteen = selectedCanteenId === 'all' || sale.canteenId === selectedCanteenId;
      const matchWindow = selectedWindow === 'all' || sale.windowName === selectedWindow;
      const matchShift = selectedShift === 'all' || sale.shift === selectedShift;
      const matchDate = !dateFilter || sale.date === dateFilter;
      const matchSearch =
        !searchTerm ||
        sale.windowName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sale.canteenName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (sale.operatorName && sale.operatorName.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (sale.notes && sale.notes.toLowerCase().includes(searchTerm.toLowerCase()));

      return matchCanteen && matchWindow && matchShift && matchDate && matchSearch;
    });
  }, [windowSales, selectedCanteenId, selectedWindow, selectedShift, dateFilter, searchTerm]);

  // Sort descending by date
  const sortedSales = useMemo(() => {
    return [...filteredSales].sort(
      (a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt)
    );
  }, [filteredSales]);

  // Overall Statistics
  const totalSalesRecorded = useMemo(() => {
    return filteredSales.reduce((sum, s) => sum + s.totalSale, 0);
  }, [filteredSales]);

  const totalCashRecorded = useMemo(() => {
    return filteredSales.reduce((sum, s) => sum + s.cashSales, 0);
  }, [filteredSales]);

  const totalTokenRecorded = useMemo(() => {
    return filteredSales.reduce((sum, s) => sum + (s.tokenSales || 0), 0);
  }, [filteredSales]);

  // Top Window & Top Shift
  const windowBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    filteredSales.forEach((s) => {
      map[s.windowName] = (map[s.windowName] || 0) + s.totalSale;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [filteredSales]);

  const shiftBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    filteredSales.forEach((s) => {
      map[s.shift] = (map[s.shift] || 0) + s.totalSale;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [filteredSales]);

  // Day-of-Week Comparison Analysis (e.g. comparing Monday vs Monday)
  const dayWiseComparison = useMemo(() => {
    const dayGroups: Record<string, WindowShiftSale[]> = {
      Monday: [],
      Tuesday: [],
      Wednesday: [],
      Thursday: [],
      Friday: [],
      Saturday: [],
      Sunday: [],
    };

    windowSales.forEach((s) => {
      const d = new Date(s.date + 'T00:00:00');
      const dayName = DAY_NAMES[d.getDay()];
      if (dayGroups[dayName]) {
        dayGroups[dayName].push(s);
      }
    });

    return Object.entries(dayGroups).map(([dayName, items]) => {
      // Sort items by date ascending to compare latest vs previous
      const dates = Array.from(new Set(items.map((x) => x.date))).sort();
      const latestDate = dates[dates.length - 1];
      const prevDate = dates[dates.length - 2];

      const latestTotal = latestDate
        ? items.filter((x) => x.date === latestDate).reduce((sum, x) => sum + x.totalSale, 0)
        : 0;

      const prevTotal = prevDate
        ? items.filter((x) => x.date === prevDate).reduce((sum, x) => sum + x.totalSale, 0)
        : 0;

      const diff = prevTotal > 0 ? latestTotal - prevTotal : 0;
      const pctChange = prevTotal > 0 ? Math.round((diff / prevTotal) * 100) : 0;

      const overallAvg =
        dates.length > 0
          ? Math.round(items.reduce((sum, x) => sum + x.totalSale, 0) / dates.length)
          : 0;

      return {
        dayName,
        latestDate,
        latestTotal,
        prevDate,
        prevTotal,
        diff,
        pctChange,
        overallAvg,
        recordsCount: items.length,
      };
    });
  }, [windowSales]);

  // Open Add Modal
  const handleOpenAdd = () => {
    setEditingSale(null);
    setFormDate(new Date().toISOString().split('T')[0]);
    setFormCanteenId(canteens[0]?.id || '');
    setFormWindow(PRESET_WINDOWS[0]);
    setFormShift(PRESET_SHIFTS[0]);
    setFormCashSales('');
    setFormTokenSales('');
    setFormOperator('');
    setFormNotes('');
    setIsModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (sale: WindowShiftSale) => {
    setEditingSale(sale);
    setFormDate(sale.date);
    setFormCanteenId(sale.canteenId);
    setFormWindow(sale.windowName);
    setFormShift(sale.shift);
    setFormCashSales(sale.cashSales.toString());
    setFormTokenSales(sale.tokenSales ? sale.tokenSales.toString() : '');
    setFormOperator(sale.operatorName || '');
    setFormNotes(sale.notes || '');
    setIsModalOpen(true);
  };

  // Submit Modal Form
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const canteen = canteens.find((c) => c.id === formCanteenId) || canteens[0];
    const cash = parseFloat(formCashSales) || 0;
    const token = parseFloat(formTokenSales) || 0;
    const total = cash + token;

    if (editingSale) {
      onEditWindowSale({
        ...editingSale,
        canteenId: canteen ? canteen.id : formCanteenId,
        canteenName: canteen ? canteen.name : 'Canteen',
        windowName: formWindow,
        shift: formShift,
        date: formDate,
        amount: total,
        cashSales: cash,
        tokenSales: token > 0 ? token : undefined,
        totalSale: total,
        operatorName: formOperator.trim() || undefined,
        notes: formNotes.trim() || undefined,
      });
    } else {
      onAddWindowSale({
        canteenId: canteen ? canteen.id : formCanteenId,
        canteenName: canteen ? canteen.name : 'Canteen',
        windowName: formWindow,
        shift: formShift,
        date: formDate,
        amount: total,
        cashSales: cash,
        tokenSales: token > 0 ? token : undefined,
        totalSale: total,
        operatorName: formOperator.trim() || undefined,
        notes: formNotes.trim() || undefined,
      });
    }

    setIsModalOpen(false);
  };

  // Print Window Sales Report
  const handlePrintReport = () => {
    const rowsHtml = sortedSales
      .map((s) => {
        const d = new Date(s.date + 'T00:00:00');
        const day = DAY_NAMES[d.getDay()];
        return `
          <tr>
            <td style="padding: 7px; border: 1px solid #cbd5e1; text-align: center;">${formatDisplayDate(s.date)} (${day.slice(0, 3)})</td>
            <td style="padding: 7px; border: 1px solid #cbd5e1;">${s.canteenName}</td>
            <td style="padding: 7px; border: 1px solid #cbd5e1; font-weight: bold; color: #1e293b;">${s.windowName}</td>
            <td style="padding: 7px; border: 1px solid #cbd5e1; text-align: center;">${s.shift}</td>
            <td style="padding: 7px; border: 1px solid #cbd5e1;">${s.operatorName || '-'}</td>
            <td style="padding: 7px; border: 1px solid #cbd5e1; text-align: right;">${currencySymbol} ${s.cashSales.toLocaleString()}</td>
            <td style="padding: 7px; border: 1px solid #cbd5e1; text-align: right;">${s.tokenSales ? `${currencySymbol} ${s.tokenSales.toLocaleString()}` : '-'}</td>
            <td style="padding: 7px; border: 1px solid #cbd5e1; text-align: right; font-weight: bold; color: #059669;">${currencySymbol} ${s.totalSale.toLocaleString()}</td>
            <td style="padding: 7px; border: 1px solid #cbd5e1;">${s.notes || '-'}</td>
          </tr>
        `;
      })
      .join('');

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Window & Shift Sales Report</title>
        <style>
          @page { size: A4 landscape; margin: 12mm; }
          body { font-family: 'Segoe UI', Arial, sans-serif; color: #0f172a; margin: 0; padding: 15px; font-size: 12px; }
          .header { text-align: center; border-bottom: 2px solid #0284c7; padding-bottom: 10px; margin-bottom: 15px; }
          .company-name { font-size: 22px; font-weight: bold; color: #0284c7; margin: 0; }
          .sub-title { font-size: 13px; color: #475569; margin: 4px 0 0 0; }
          .meta-bar { display: flex; justify-content: space-between; margin-bottom: 15px; background: #f8fafc; padding: 8px 12px; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 12px; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 11px; }
          th { background: #f1f5f9; color: #334155; padding: 8px; font-weight: bold; border: 1px solid #cbd5e1; text-align: left; }
          .total-box { margin-top: 15px; text-align: right; font-size: 14px; font-weight: bold; color: #0f172a; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1 class="company-name">SKEM CANTEENS MANAGEMENT</h1>
          <p class="sub-title">Window & Shift Sales Performance Report</p>
        </div>
        <div class="meta-bar">
          <div><strong>Report Date:</strong> ${formatDisplayDate(new Date().toISOString().split('T')[0])}</div>
          <div><strong>Total Records:</strong> ${sortedSales.length}</div>
          <div><strong>Total Sales:</strong> ${currencySymbol} ${totalSalesRecorded.toLocaleString()}</div>
        </div>
        <table>
          <thead>
            <tr>
              <th style="text-align: center;">Date</th>
              <th>Canteen</th>
              <th>Window / Counter</th>
              <th style="text-align: center;">Shift</th>
              <th>Staff Incharge</th>
              <th style="text-align: right;">Cash Sales</th>
              <th style="text-align: right;">Token Sales</th>
              <th style="text-align: right;">Total Sale</th>
              <th>Remarks</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>
        <div class="total-box">
          Grand Total Window Sales: ${currencySymbol} ${totalSalesRecorded.toLocaleString()}
        </div>
        <script>
          window.onload = function() { window.print(); };
        </script>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-sky-50 border border-sky-200 text-sky-700 flex items-center justify-center font-bold">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Window & Shift Sales
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                Shift-wise sales records and week-over-week growth tracking across all canteen windows.
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={handlePrintReport}
            className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer"
            title="Print Report"
          >
            <Printer className="w-4 h-4" />
            <span className="hidden sm:inline">Print</span>
          </button>
          <button
            onClick={() => exportWindowSalesExcel(sortedSales, currencySymbol)}
            className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer"
            title="Download Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span className="hidden sm:inline">Excel</span>
          </button>
          <button
            onClick={handleOpenAdd}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white text-xs sm:text-sm font-bold rounded-xl shadow-xs transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Add Window Sale</span>
          </button>
        </div>
      </div>

      {/* Notice Banner: Completely Isolated from Main Dashboard */}
      <div className="bg-sky-50/70 border border-sky-200 rounded-xl p-3 text-xs text-sky-900 flex items-center gap-2">
        <HelpCircle className="w-4 h-4 text-sky-600 shrink-0" />
        <span>
          <strong>Alag Hisab (Strictly Isolated from Dashboard):</strong> Yeh record counters aur shifts ki karkardagi (performance differ) dekhne ke liye hai aur <strong>Main Dashboard Daily Sales ko disturb nahi karta</strong>.
        </span>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Window Sales */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Total Shift Sales (Recorded)
            </span>
            <span className="p-2 bg-sky-50 text-sky-600 rounded-xl">
              <BarChart3 className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900">
            {formatCurrency(totalSalesRecorded, currencySymbol)}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Cash: {formatCurrency(totalCashRecorded, currencySymbol)} • Token: {formatCurrency(totalTokenRecorded, currencySymbol)}
          </div>
        </div>

        {/* Top Window Counter */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Top Window Counter
            </span>
            <span className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-xl font-black text-emerald-700">
            {windowBreakdown[0] ? windowBreakdown[0][0] : 'None'}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            {windowBreakdown[0] ? formatCurrency(windowBreakdown[0][1], currencySymbol) : 'No data'}
          </div>
        </div>

        {/* Top Shift */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Top Performing Shift
            </span>
            <span className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-xl font-black text-indigo-700">
            {shiftBreakdown[0] ? shiftBreakdown[0][0] : 'None'}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            {shiftBreakdown[0] ? formatCurrency(shiftBreakdown[0][1], currencySymbol) : 'No data'}
          </div>
        </div>

        {/* Total Shifts Count */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Shift Entries Logged
            </span>
            <span className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <Store className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900">{filteredSales.length}</div>
          <div className="text-xs text-slate-500 mt-1">Across Windows 1-2, 3-4, Taba, 6-7</div>
        </div>
      </div>

      {/* Week-Over-Week Day Comparison Section (Specifically requested by user!) */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-sky-600" />
              Day-Wise Performance Comparison
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Check if Monday sale increased or decreased compared to the previous Monday, Tuesday vs previous Tuesday, etc.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {dayWiseComparison.map((d) => {
            const hasData = d.recordsCount > 0;
            const isUp = d.diff > 0;
            const isDown = d.diff < 0;

            return (
              <div
                key={d.dayName}
                className="bg-slate-50/70 border border-slate-200 rounded-xl p-3.5 hover:border-slate-300 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">{d.dayName}</span>
                  {hasData && d.prevTotal > 0 && (
                    <span
                      className={`text-[10px] font-black px-1.5 py-0.5 rounded-md flex items-center gap-0.5 ${
                        isUp
                          ? 'bg-emerald-100 text-emerald-800'
                          : isDown
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {isUp && <TrendingUp className="w-3 h-3" />}
                      {isDown && <TrendingDown className="w-3 h-3" />}
                      {d.pctChange > 0 ? `+${d.pctChange}%` : `${d.pctChange}%`}
                    </span>
                  )}
                </div>

                <div className="mt-2 flex items-baseline justify-between">
                  <div>
                    <div className="text-xs text-slate-400">Latest ({d.latestDate ? formatDisplayDate(d.latestDate) : 'N/A'})</div>
                    <div className="text-base font-black text-slate-900">
                      {d.latestTotal > 0 ? formatCurrency(d.latestTotal, currencySymbol) : '-'}
                    </div>
                  </div>

                  {d.prevTotal > 0 && (
                    <div className="text-right">
                      <div className="text-xs text-slate-400">Prev ({formatDisplayDate(d.prevDate)})</div>
                      <div className="text-xs font-semibold text-slate-600">
                        {formatCurrency(d.prevTotal, currencySymbol)}
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-2 pt-2 border-t border-slate-200/60 text-[11px] text-slate-500 flex justify-between">
                  <span>Avg Day Sale:</span>
                  <span className="font-bold text-slate-700">
                    {d.overallAvg > 0 ? formatCurrency(d.overallAvg, currencySymbol) : '-'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          {/* Canteen Filter */}
          <select
            value={selectedCanteenId}
            onChange={(e) => setSelectedCanteenId(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:bg-white focus:outline-none cursor-pointer"
          >
            <option value="all">All Canteens</option>
            {canteens.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          {/* Window Filter */}
          <select
            value={selectedWindow}
            onChange={(e) => setSelectedWindow(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:bg-white focus:outline-none cursor-pointer"
          >
            <option value="all">All Windows / Counters</option>
            {PRESET_WINDOWS.map((w) => (
              <option key={w} value={w}>
                {w}
              </option>
            ))}
          </select>

          {/* Shift Filter */}
          <select
            value={selectedShift}
            onChange={(e) => setSelectedShift(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:bg-white focus:outline-none cursor-pointer"
          >
            <option value="all">All Shifts</option>
            {PRESET_SHIFTS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>

          {/* Date Picker */}
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:bg-white focus:outline-none cursor-pointer"
          />
          {dateFilter && (
            <button
              onClick={() => setDateFilter('')}
              className="text-xs text-rose-600 hover:underline font-bold"
            >
              Clear Date
            </button>
          )}
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-60">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search operator, note..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none"
          />
        </div>
      </div>

      {/* Sales Records Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
          <div className="font-bold text-sm text-slate-900">
            Window & Shift Log ({sortedSales.length} Entries)
          </div>
          <div className="text-xs text-slate-500">
            Showing all recorded counter shifts
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-600 font-bold border-b border-slate-200">
                <th className="py-3 px-4">Date & Day</th>
                <th className="py-3 px-4">Canteen</th>
                <th className="py-3 px-4">Window / Counter</th>
                <th className="py-3 px-4">Shift</th>
                <th className="py-3 px-4">Staff Incharge</th>
                <th className="py-3 px-4 text-right">Cash Sale</th>
                <th className="py-3 px-4 text-right">Token Sale</th>
                <th className="py-3 px-4 text-right">Total Shift Sale</th>
                <th className="py-3 px-4">Remarks</th>
                <th className="py-3 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {sortedSales.map((sale) => {
                const d = new Date(sale.date + 'T00:00:00');
                const dayName = DAY_NAMES[d.getDay()];

                return (
                  <tr key={sale.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-800 whitespace-nowrap">
                      {formatDisplayDate(sale.date)}
                      <span className="ml-1.5 text-[10px] font-bold px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded">
                        {dayName.slice(0, 3)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-700 whitespace-nowrap">{sale.canteenName}</td>
                    <td className="py-3 px-4">
                      <span className="px-2.5 py-1 bg-sky-50 text-sky-800 border border-sky-200 rounded-lg font-bold text-xs">
                        {sale.windowName}
                      </span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded-md font-semibold text-[11px]">
                        {sale.shift}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-700 font-medium">
                      {sale.operatorName || <span className="text-slate-400">-</span>}
                    </td>
                    <td className="py-3 px-4 text-right font-semibold text-slate-800">
                      {formatCurrency(sale.cashSales, currencySymbol)}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-600">
                      {sale.tokenSales ? formatCurrency(sale.tokenSales, currencySymbol) : '-'}
                    </td>
                    <td className="py-3 px-4 text-right font-black text-emerald-700 text-sm">
                      {formatCurrency(sale.totalSale, currencySymbol)}
                    </td>
                    <td className="py-3 px-4 text-slate-500 max-w-xs truncate" title={sale.notes}>
                      {sale.notes || '-'}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => handleOpenEdit(sale)}
                          className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg cursor-pointer transition-colors"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Delete this window sale record for ${sale.windowName}?`)) {
                              onDeleteWindowSale(sale.id);
                            }
                          }}
                          className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {sortedSales.length === 0 && (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400">
                    <Layers className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="font-bold text-sm text-slate-600">No shift sales found</p>
                    <p className="text-xs text-slate-400 mt-0.5">Click '+ Add Window Sale' to record a shift</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Window Sale Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">
                {editingSale ? 'Edit Window / Shift Entry' : 'Record Window Shift Sale'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
              {/* Date & Canteen */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-sky-500/20 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Canteen *</label>
                  <select
                    value={formCanteenId}
                    onChange={(e) => setFormCanteenId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-sky-500/20 cursor-pointer"
                  >
                    {canteens.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Window / Counter Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Window / Counter Name *
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {PRESET_WINDOWS.map((win) => (
                    <button
                      key={win}
                      type="button"
                      onClick={() => setFormWindow(win)}
                      className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                        formWindow === win
                          ? 'bg-sky-50 border-sky-400 text-sky-800'
                          : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {win}
                    </button>
                  ))}
                </div>
              </div>

              {/* Shift Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Shift *</label>
                <div className="grid grid-cols-3 gap-2">
                  {PRESET_SHIFTS.map((sh) => (
                    <button
                      key={sh}
                      type="button"
                      onClick={() => setFormShift(sh)}
                      className={`py-2 px-2 text-xs font-bold rounded-xl border transition-all cursor-pointer text-center ${
                        formShift === sh
                          ? 'bg-indigo-50 border-indigo-400 text-indigo-800'
                          : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {sh}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sales Amounts */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Cash Sales ({currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    placeholder="e.g. 45000"
                    value={formCashSales}
                    onChange={(e) => setFormCashSales(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Token Sales ({currencySymbol})
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="Optional token sale"
                    value={formTokenSales}
                    onChange={(e) => setFormTokenSales(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                  />
                </div>
              </div>

              {/* Total Live Preview */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Total Shift Sale:</span>
                <span className="text-base font-black text-emerald-700">
                  {formatCurrency(
                    (parseFloat(formCashSales) || 0) + (parseFloat(formTokenSales) || 0),
                    currencySymbol
                  )}
                </span>
              </div>

              {/* Operator / Staff Incharge */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Operator / Staff Incharge
                </label>
                <input
                  type="text"
                  placeholder="e.g. Asif, Imran, Ali..."
                  value={formOperator}
                  onChange={(e) => setFormOperator(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                />
              </div>

              {/* Remarks / Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Remarks / Note</label>
                <input
                  type="text"
                  placeholder="e.g. Normal rush, tea inventory shortage, etc."
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl cursor-pointer shadow-xs"
                >
                  {editingSale ? 'Save Changes' : 'Record Shift Sale'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

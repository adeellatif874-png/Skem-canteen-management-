import React, { useState } from 'react';
import {
  Users,
  Building2,
  Plus,
  Search,
  Filter,
  ArrowDownLeft,
  ArrowUpRight,
  FileSpreadsheet,
  Printer,
  Calendar,
  DollarSign,
  Phone,
  MapPin,
  FileText,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertCircle,
  X,
  CreditCard,
  Receipt,
  HelpCircle,
} from 'lucide-react';
import { Party, PartyTransaction, PartyType, PartyTransactionType } from '../types';
import { formatCurrency, formatDisplayDate } from '../lib/storage';
import { calculatePartyBalance, exportPartyLedgerExcel } from '../lib/partiesData';

interface PartiesViewProps {
  parties: Party[];
  transactions: PartyTransaction[];
  currencySymbol: string;
  onAddParty: (party: Omit<Party, 'id' | 'currentBalance' | 'createdAt'>) => void;
  onEditParty: (party: Party) => void;
  onDeleteParty: (id: string) => void;
  onAddTransaction: (tx: Omit<PartyTransaction, 'id' | 'createdAt' | 'balanceAfter'>) => void;
  onDeleteTransaction: (id: string) => void;
}

export const PartiesView: React.FC<PartiesViewProps> = ({
  parties = [],
  transactions = [],
  currencySymbol = 'Rs.',
  onAddParty,
  onEditParty,
  onDeleteParty,
  onAddTransaction,
  onDeleteTransaction,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'supplier' | 'customer'>('all');
  const [selectedParty, setSelectedParty] = useState<Party | null>(null);

  // Modals
  const [isPartyModalOpen, setIsPartyModalOpen] = useState(false);
  const [editingParty, setEditingParty] = useState<Party | null>(null);

  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [txPartyId, setTxPartyId] = useState<string>('');

  // Party Form State
  const [partyName, setPartyName] = useState('');
  const [partyType, setPartyType] = useState<PartyType>('supplier');
  const [partyPhone, setPartyPhone] = useState('');
  const [partyAddress, setPartyAddress] = useState('');
  const [partyOpeningBal, setPartyOpeningBal] = useState<number>(0);
  const [partyNotes, setPartyNotes] = useState('');

  // Transaction Form State
  const [txType, setTxType] = useState<PartyTransactionType>('installment_payment');
  const [txDate, setTxDate] = useState(new Date().toISOString().split('T')[0]);
  const [txAmount, setTxAmount] = useState<string>('');
  const [txBillNo, setTxBillNo] = useState('');
  const [txMethod, setTxMethod] = useState<'Cash' | 'Bank Transfer' | 'Cheque' | 'Slip' | 'Other'>('Cash');
  const [txDesc, setTxDesc] = useState('');

  // Calculate live balances for all parties
  const partiesWithLiveBalance = parties.map((p) => ({
    ...p,
    currentBalance: calculatePartyBalance(p, transactions),
  }));

  // Filtered parties
  const filteredParties = partiesWithLiveBalance.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.phone && p.phone.includes(searchTerm)) ||
      (p.address && p.address.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesType = typeFilter === 'all' || p.type === typeFilter;
    return matchesSearch && matchesType;
  });

  // Calculate overall totals
  const totalPayables = partiesWithLiveBalance
    .filter((p) => p.type === 'supplier')
    .reduce((sum, p) => sum + (p.currentBalance > 0 ? p.currentBalance : 0), 0);

  const totalReceivables = partiesWithLiveBalance
    .filter((p) => p.type === 'customer')
    .reduce((sum, p) => sum + (p.currentBalance > 0 ? p.currentBalance : 0), 0);

  const totalSuppliersCount = partiesWithLiveBalance.filter((p) => p.type === 'supplier').length;
  const totalCustomersCount = partiesWithLiveBalance.filter((p) => p.type === 'customer').length;

  // Open Add Party Modal
  const handleOpenAddParty = () => {
    setEditingParty(null);
    setPartyName('');
    setPartyType('supplier');
    setPartyPhone('');
    setPartyAddress('');
    setPartyOpeningBal(0);
    setPartyNotes('');
    setIsPartyModalOpen(true);
  };

  // Open Edit Party Modal
  const handleOpenEditParty = (party: Party, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingParty(party);
    setPartyName(party.name);
    setPartyType(party.type);
    setPartyPhone(party.phone || '');
    setPartyAddress(party.address || '');
    setPartyOpeningBal(party.openingBalance || 0);
    setPartyNotes(party.notes || '');
    setIsPartyModalOpen(true);
  };

  // Submit Party Form
  const handleSubmitParty = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partyName.trim()) return;

    if (editingParty) {
      onEditParty({
        ...editingParty,
        name: partyName.trim(),
        type: partyType,
        phone: partyPhone.trim() || undefined,
        address: partyAddress.trim() || undefined,
        openingBalance: Number(partyOpeningBal) || 0,
        notes: partyNotes.trim() || undefined,
      });
      // If selected party was edited, update view
      if (selectedParty && selectedParty.id === editingParty.id) {
        setSelectedParty({
          ...selectedParty,
          name: partyName.trim(),
          type: partyType,
          phone: partyPhone.trim() || undefined,
          address: partyAddress.trim() || undefined,
          openingBalance: Number(partyOpeningBal) || 0,
          notes: partyNotes.trim() || undefined,
        });
      }
    } else {
      onAddParty({
        name: partyName.trim(),
        type: partyType,
        phone: partyPhone.trim() || undefined,
        address: partyAddress.trim() || undefined,
        openingBalance: Number(partyOpeningBal) || 0,
        notes: partyNotes.trim() || undefined,
      });
    }

    setIsPartyModalOpen(false);
  };

  // Open Add Transaction Modal
  const handleOpenAddTx = (partyIdToSet?: string, defaultTxType?: PartyTransactionType, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const targetPartyId = partyIdToSet || (parties.length > 0 ? parties[0].id : '');
    setTxPartyId(targetPartyId);
    setTxType(defaultTxType || 'installment_payment');
    setTxDate(new Date().toISOString().split('T')[0]);
    setTxAmount('');
    setTxBillNo('');
    setTxMethod('Cash');
    setTxDesc('');
    setIsTxModalOpen(true);
  };

  // Submit Transaction Form
  const handleSubmitTx = (e: React.FormEvent) => {
    e.preventDefault();
    const party = parties.find((p) => p.id === txPartyId);
    if (!party) return;

    const amt = parseFloat(txAmount);
    if (isNaN(amt) || amt <= 0) return;

    onAddTransaction({
      partyId: party.id,
      partyName: party.name,
      partyType: party.type,
      date: txDate,
      type: txType,
      amount: amt,
      paymentMethod: txMethod,
      invoiceOrBillNo: txBillNo.trim() || undefined,
      description: txDesc.trim() || (txType === 'stock_bill' ? 'Stock Bill' : 'Installment Payment'),
    });

    setIsTxModalOpen(false);
  };

  // Print Statement for Selected Party
  const handlePrintStatement = (party: Party) => {
    const partyTx = transactions.filter((t) => t.partyId === party.id);
    partyTx.sort((a, b) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt));

    let runningBal = party.openingBalance || 0;

    const rowsHtml = partyTx
      .map((tx) => {
        let billAmt = '-';
        let payAmt = '-';
        if (tx.type === 'stock_bill') {
          billAmt = `${currencySymbol} ${tx.amount.toLocaleString()}`;
          runningBal += tx.amount;
        } else {
          payAmt = `${currencySymbol} ${tx.amount.toLocaleString()}`;
          runningBal -= tx.amount;
        }

        return `
          <tr>
            <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">${formatDisplayDate(tx.date)}</td>
            <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">${tx.invoiceOrBillNo || '-'}</td>
            <td style="padding: 8px; border: 1px solid #cbd5e1;">${tx.type === 'stock_bill' ? (party.type === 'supplier' ? 'Stock Received' : 'Stock Delivered') : 'Installment Payment'}</td>
            <td style="padding: 8px; border: 1px solid #cbd5e1;">${tx.description}</td>
            <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">${tx.paymentMethod || '-'}</td>
            <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; font-weight: 600; color: #1e293b;">${billAmt}</td>
            <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; font-weight: 600; color: #059669;">${payAmt}</td>
            <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; font-weight: 700; color: #0f172a;">${currencySymbol} ${runningBal.toLocaleString()}</td>
          </tr>
        `;
      })
      .join('');

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Ledger Statement - ${party.name}</title>
        <style>
          @page { size: A4; margin: 15mm; }
          body { font-family: 'Segoe UI', Arial, sans-serif; color: #0f172a; margin: 0; padding: 20px; font-size: 13px; line-height: 1.5; }
          .header { text-align: center; border-bottom: 2px solid #059669; padding-bottom: 12px; margin-bottom: 20px; }
          .company-name { font-size: 24px; font-weight: bold; color: #059669; margin: 0; }
          .sub-title { font-size: 14px; color: #475569; margin: 4px 0 0 0; }
          .statement-badge { display: inline-block; background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; font-weight: bold; padding: 4px 14px; border-radius: 9999px; margin-top: 8px; }
          .party-card { display: flex; justify-content: space-between; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; margin-bottom: 20px; }
          .party-title { font-size: 16px; font-weight: bold; color: #0f172a; margin-bottom: 4px; }
          .meta-text { color: #64748b; font-size: 12px; margin: 2px 0; }
          .balance-box { text-align: right; }
          .balance-label { font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: 600; }
          .balance-val { font-size: 22px; font-weight: 800; color: ${party.type === 'supplier' ? '#dc2626' : '#059669'}; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12px; }
          th { background: #f1f5f9; color: #334155; padding: 9px 8px; font-weight: bold; border: 1px solid #cbd5e1; text-align: left; }
          .signatures { display: flex; justify-content: space-between; margin-top: 50px; padding-top: 20px; }
          .sig-box { width: 200px; text-align: center; border-top: 1px dashed #64748b; padding-top: 6px; font-size: 12px; color: #475569; font-weight: 600; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1 class="company-name">SKEM CANTEENS MANAGEMENT</h1>
          <p class="sub-title">Parties & Installments Ledger Statement</p>
          <div class="statement-badge">${party.type === 'supplier' ? 'SUPPLIER (VENDOR) LEDGER' : 'CUSTOMER (CLIENT) LEDGER'}</div>
        </div>

        <div class="party-card">
          <div>
            <div class="party-title">${party.name}</div>
            <div class="meta-text"><strong>Phone:</strong> ${party.phone || 'N/A'}</div>
            <div class="meta-text"><strong>Address:</strong> ${party.address || 'N/A'}</div>
            <div class="meta-text"><strong>Statement Date:</strong> ${formatDisplayDate(new Date().toISOString().split('T')[0])}</div>
          </div>
          <div class="balance-box">
            <div class="balance-label">${party.type === 'supplier' ? 'Total Payable (Hum ny dyna hai)' : 'Total Receivable (Hum ny lyna hai)'}</div>
            <div class="balance-val">${currencySymbol} ${runningBal.toLocaleString()}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="text-align: center; width: 85px;">Date</th>
              <th style="text-align: center; width: 90px;">Ref / Bill #</th>
              <th style="width: 130px;">Transaction Type</th>
              <th>Description / Stock Items</th>
              <th style="text-align: center; width: 90px;">Mode</th>
              <th style="text-align: right; width: 110px;">${party.type === 'supplier' ? 'Stock Bill (+)' : 'Stock Sold (+)'}</th>
              <th style="text-align: right; width: 110px;">Installment (-)</th>
              <th style="text-align: right; width: 110px;">Net Balance</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">${formatDisplayDate(party.createdAt.split('T')[0])}</td>
              <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">-</td>
              <td style="padding: 8px; border: 1px solid #cbd5e1;">Opening Balance</td>
              <td style="padding: 8px; border: 1px solid #cbd5e1;">Initial Opening Balance</td>
              <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">-</td>
              <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; font-weight: 600;">${currencySymbol} ${(party.openingBalance || 0).toLocaleString()}</td>
              <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; font-weight: 600;">-</td>
              <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: right; font-weight: 700;">${currencySymbol} ${(party.openingBalance || 0).toLocaleString()}</td>
            </tr>
            ${rowsHtml}
          </tbody>
        </table>

        <div class="signatures">
          <div class="sig-box">Prepared By</div>
          <div class="sig-box">Checked By</div>
          <div class="sig-box">Party Signature / Stamp</div>
        </div>

        <script>
          window.onload = function() {
            window.print();
          };
        </script>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
    }
  };

  const activePartyInModal = parties.find((p) => p.id === txPartyId);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header & Context */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-700 flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Parties & Khata Ledger
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                Comprehensive accounts ledger for suppliers (stock purchases & installments) and clients.
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => handleOpenAddTx()}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold rounded-xl shadow-xs transition-all cursor-pointer"
          >
            <CreditCard className="w-4 h-4" />
            <span>+ Add Installment / Bill</span>
          </button>
          <button
            onClick={handleOpenAddParty}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-bold rounded-xl shadow-xs transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ New Party</span>
          </button>
        </div>
      </div>

      {/* Note that this is completely independent from Canteen Daily Sales/Expenses Dashboard */}
      <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3 text-xs text-amber-800 flex items-center gap-2">
        <HelpCircle className="w-4 h-4 text-amber-600 shrink-0" />
        <span>
          <strong>Alag Hisab (Independent Ledger):</strong> Yeh ledger parties ke installments aur stock hisab ke liye mukhtas hai aur main <strong>Dashboard Total Sales / Expenses ko mutasir nahi karta</strong>.
        </span>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Payables (Suppliers) */}
        <div className="bg-white rounded-2xl p-5 border border-rose-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-rose-700 uppercase tracking-wider">
              Hum ny Dena Hai (Payable)
            </span>
            <span className="p-2 bg-rose-50 text-rose-600 rounded-xl">
              <ArrowUpRight className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-black text-rose-700">
            {formatCurrency(totalPayables, currencySymbol)}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            To <strong>{totalSuppliersCount} Suppliers</strong> (Stock vendors)
          </div>
        </div>

        {/* Total Receivables (Customers like MK Son's) */}
        <div className="bg-white rounded-2xl p-5 border border-emerald-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
              Hum ny Lena Hai (Receivable)
            </span>
            <span className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
              <ArrowDownLeft className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-black text-emerald-700">
            {formatCurrency(totalReceivables, currencySymbol)}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            From <strong>{totalCustomersCount} Clients</strong> (e.g. MK Son's)
          </div>
        </div>

        {/* Suppliers Count */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
              Suppliers (Vendors)
            </span>
            <span className="p-2 bg-slate-50 text-slate-600 rounded-xl">
              <Building2 className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-black text-slate-900">{totalSuppliersCount}</div>
          <div className="text-xs text-slate-500 mt-1">Bakery, Grocery, Dairy & Provisions</div>
        </div>

        {/* Customers Count */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
              Clients (Stock Supply)
            </span>
            <span className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Users className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-2xl font-black text-indigo-700">{totalCustomersCount}</div>
          <div className="text-xs text-slate-500 mt-1">MK Son's & Other institutional clients</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Type Filter Tabs */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl w-full sm:w-auto">
          <button
            onClick={() => setTypeFilter('all')}
            className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              typeFilter === 'all'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Parties ({partiesWithLiveBalance.length})
          </button>
          <button
            onClick={() => setTypeFilter('supplier')}
            className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              typeFilter === 'supplier'
                ? 'bg-white text-rose-700 shadow-xs'
                : 'text-slate-600 hover:text-rose-700'
            }`}
          >
            Suppliers / Vendors ({totalSuppliersCount})
          </button>
          <button
            onClick={() => setTypeFilter('customer')}
            className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              typeFilter === 'customer'
                ? 'bg-white text-emerald-700 shadow-xs'
                : 'text-slate-600 hover:text-emerald-700'
            }`}
          >
            Clients / MK Son's ({totalCustomersCount})
          </button>
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search party, phone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
          />
        </div>
      </div>

      {/* Parties Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredParties.map((party) => {
          const isSupplier = party.type === 'supplier';
          const isSelected = selectedParty?.id === party.id;

          return (
            <div
              key={party.id}
              onClick={() => setSelectedParty(party)}
              className={`bg-white rounded-2xl p-5 border transition-all cursor-pointer relative ${
                isSelected
                  ? 'border-indigo-500 ring-2 ring-indigo-500/20 shadow-md'
                  : 'border-slate-200 hover:border-slate-300 hover:shadow-xs'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-slate-900 text-base truncate">{party.name}</h3>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                        isSupplier
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      }`}
                    >
                      {isSupplier ? 'SUPPLIER / VENDOR' : "CLIENT (MK SON'S TYPE)"}
                    </span>
                  </div>
                </div>

                {/* Edit & Delete Action icons */}
                <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={(e) => handleOpenEditParty(party, e)}
                    className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                    title="Edit Party Info"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm(`Are you sure you want to delete ${party.name} and all associated ledger records?`)) {
                        onDeleteParty(party.id);
                        if (selectedParty?.id === party.id) setSelectedParty(null);
                      }
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                    title="Delete Party"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Contact Meta */}
              <div className="mt-3 space-y-1 text-xs text-slate-500">
                {party.phone && (
                  <div className="flex items-center gap-1.5">
                    <Phone className="w-3 h-3 text-slate-400" />
                    <span>{party.phone}</span>
                  </div>
                )}
                {party.address && (
                  <div className="flex items-center gap-1.5 truncate">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="truncate">{party.address}</span>
                  </div>
                )}
              </div>

              {/* Outstanding Balance */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    {isSupplier ? 'Hum ny dyna hai (Payable)' : 'Hum ny lyna hai (Receivable)'}
                  </span>
                  <div
                    className={`text-lg font-black ${
                      isSupplier ? 'text-rose-600' : 'text-emerald-600'
                    }`}
                  >
                    {formatCurrency(party.currentBalance, currencySymbol)}
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={(e) => handleOpenAddTx(party.id, 'installment_payment', e)}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                  >
                    + Payment
                  </button>
                  <button
                    onClick={() => setSelectedParty(party)}
                    className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                  >
                    Khata &gt;
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {filteredParties.length === 0 && (
          <div className="col-span-full py-12 text-center bg-white rounded-2xl border border-dashed border-slate-300">
            <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-600">No parties found</p>
            <p className="text-xs text-slate-400 mt-0.5">Add a new party or clear search filters</p>
            <button
              onClick={handleOpenAddParty}
              className="mt-3 px-3 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded-xl cursor-pointer"
            >
              + Add New Party
            </button>
          </div>
        )}
      </div>

      {/* Selected Party Detailed Ledger Statement Modal */}
      {selectedParty && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm ${
                    selectedParty.type === 'supplier'
                      ? 'bg-rose-100 text-rose-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {selectedParty.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg sm:text-xl font-black text-slate-900">{selectedParty.name}</h2>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        selectedParty.type === 'supplier'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {selectedParty.type === 'supplier' ? 'Supplier (Vendor)' : "Client (MK Son's)"}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    {selectedParty.phone || 'No phone'} • {selectedParty.address || 'No address'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => exportPartyLedgerExcel(selectedParty, transactions, currencySymbol)}
                  className="hidden sm:flex items-center gap-1 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-bold cursor-pointer"
                  title="Export Ledger to Excel"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Excel</span>
                </button>
                <button
                  onClick={() => handlePrintStatement(selectedParty)}
                  className="flex items-center gap-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold cursor-pointer shadow-2xs"
                  title="Print Ledger Statement"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print</span>
                </button>
                <button
                  onClick={() => setSelectedParty(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-xl cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Quick Ledger Action Bar */}
            <div className="p-4 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  {selectedParty.type === 'supplier' ? 'Current Payable Balance' : 'Current Receivable Balance'}
                </span>
                <div
                  className={`text-xl font-black ${
                    selectedParty.type === 'supplier' ? 'text-rose-600' : 'text-emerald-600'
                  }`}
                >
                  {formatCurrency(calculatePartyBalance(selectedParty, transactions), currencySymbol)}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleOpenAddTx(selectedParty.id, 'stock_bill')}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl cursor-pointer"
                >
                  + {selectedParty.type === 'supplier' ? 'Stock Received (Bill)' : 'Stock Delivered (Bill)'}
                </button>
                <button
                  onClick={() => handleOpenAddTx(selectedParty.id, 'installment_payment')}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl cursor-pointer shadow-2xs"
                >
                  + Record Installment Payment
                </button>
              </div>
            </div>

            {/* Ledger Transactions Table */}
            <div className="overflow-y-auto flex-1 p-4">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-600 font-bold border-b border-slate-200">
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Ref / Bill #</th>
                    <th className="py-2.5 px-3">Type</th>
                    <th className="py-2.5 px-3">Description</th>
                    <th className="py-2.5 px-3">Mode</th>
                    <th className="py-2.5 px-3 text-right">
                      {selectedParty.type === 'supplier' ? 'Stock (+)' : 'Stock Sold (+)'}
                    </th>
                    <th className="py-2.5 px-3 text-right">Installment (-)</th>
                    <th className="py-2.5 px-3 text-right">Running Balance</th>
                    <th className="py-2.5 px-2 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {/* Opening Balance Row */}
                  <tr className="bg-slate-50/50 font-semibold text-slate-700">
                    <td className="py-2 px-3">{formatDisplayDate(selectedParty.createdAt.split('T')[0])}</td>
                    <td className="py-2 px-3 text-slate-400">-</td>
                    <td className="py-2 px-3 text-slate-500">Opening Balance</td>
                    <td className="py-2 px-3 text-slate-500">Initial Account Balance</td>
                    <td className="py-2 px-3 text-slate-400">-</td>
                    <td className="py-2 px-3 text-right">
                      {formatCurrency(selectedParty.openingBalance || 0, currencySymbol)}
                    </td>
                    <td className="py-2 px-3 text-right text-slate-400">-</td>
                    <td className="py-2 px-3 text-right font-bold text-slate-900">
                      {formatCurrency(selectedParty.openingBalance || 0, currencySymbol)}
                    </td>
                    <td className="py-2 px-2 text-center text-slate-400">-</td>
                  </tr>

                  {/* Transactions Loop with Running Balance */}
                  {(() => {
                    const partyTx = transactions.filter((t) => t.partyId === selectedParty.id);
                    partyTx.sort(
                      (a, b) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt)
                    );

                    let runningBal = selectedParty.openingBalance || 0;

                    return partyTx.map((tx) => {
                      let billAmt = 0;
                      let paymentAmt = 0;

                      if (tx.type === 'stock_bill') {
                        billAmt = tx.amount;
                        runningBal += tx.amount;
                      } else {
                        paymentAmt = tx.amount;
                        runningBal -= tx.amount;
                      }

                      return (
                        <tr key={tx.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-2.5 px-3 font-medium text-slate-700">
                            {formatDisplayDate(tx.date)}
                          </td>
                          <td className="py-2.5 px-3 font-semibold text-slate-600">
                            {tx.invoiceOrBillNo || '-'}
                          </td>
                          <td className="py-2.5 px-3">
                            <span
                              className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                                tx.type === 'stock_bill'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {tx.type === 'stock_bill'
                                ? selectedParty.type === 'supplier'
                                  ? 'Stock Received'
                                  : 'Stock Delivered'
                                : 'Installment Paid'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-slate-600 max-w-xs truncate" title={tx.description}>
                            {tx.description}
                          </td>
                          <td className="py-2.5 px-3 text-slate-500 font-medium">{tx.paymentMethod || '-'}</td>
                          <td className="py-2.5 px-3 text-right font-bold text-slate-800">
                            {billAmt > 0 ? formatCurrency(billAmt, currencySymbol) : '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right font-bold text-emerald-700">
                            {paymentAmt > 0 ? formatCurrency(paymentAmt, currencySymbol) : '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right font-black text-slate-900">
                            {formatCurrency(runningBal, currencySymbol)}
                          </td>
                          <td className="py-2.5 px-2 text-center">
                            <button
                              onClick={() => {
                                if (confirm('Are you sure you want to delete this ledger entry?')) {
                                  onDeleteTransaction(tx.id);
                                }
                              }}
                              className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                              title="Delete Transaction"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    });
                  })()}
                </tbody>
              </table>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Total Ledger Entries: {transactions.filter((t) => t.partyId === selectedParty.id).length}
              </span>
              <button
                onClick={() => setSelectedParty(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
              >
                Close Statement
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Party Modal */}
      {isPartyModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">
                {editingParty ? 'Edit Party Details' : 'Add New Party / Account'}
              </h3>
              <button
                onClick={() => setIsPartyModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitParty} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Party Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. MK Son's, Al-Madina Grocery, etc."
                  value={partyName}
                  onChange={(e) => setPartyName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Party Type *
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPartyType('supplier')}
                    className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      partyType === 'supplier'
                        ? 'bg-rose-50 border-rose-400 text-rose-800'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Supplier (Stock Vendor)
                    <span className="block text-[10px] font-normal text-slate-500 mt-0.5">Accounts Payable</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPartyType('customer')}
                    className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      partyType === 'customer'
                        ? 'bg-emerald-50 border-emerald-400 text-emerald-800'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Client (MK Son's)
                    <span className="block text-[10px] font-normal text-slate-500 mt-0.5">Unhon ny payment dyna hai</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    placeholder="0300-1234567"
                    value={partyPhone}
                    onChange={(e) => setPartyPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Opening Balance ({currencySymbol})
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={partyOpeningBal || ''}
                    onChange={(e) => setPartyOpeningBal(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Address / Location</label>
                <input
                  type="text"
                  placeholder="Market, City, or Canteen Area"
                  value={partyAddress}
                  onChange={(e) => setPartyAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Remarks / Notes</label>
                <textarea
                  rows={2}
                  placeholder="Notes about supply items, installment terms, etc."
                  value={partyNotes}
                  onChange={(e) => setPartyNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsPartyModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl cursor-pointer shadow-xs"
                >
                  {editingParty ? 'Save Changes' : 'Create Party'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Transaction / Installment Modal */}
      {isTxModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">
                Record Party Entry
              </h3>
              <button
                onClick={() => setIsTxModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitTx} className="mt-4 space-y-4">
              {/* Select Party */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Select Party *</label>
                <select
                  value={txPartyId}
                  onChange={(e) => setTxPartyId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
                >
                  {parties.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.type === 'supplier' ? 'Supplier' : 'Client'})
                    </option>
                  ))}
                </select>
              </div>

              {/* Transaction Type */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Transaction Type *</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setTxType('installment_payment')}
                    className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      txType === 'installment_payment'
                        ? 'bg-emerald-50 border-emerald-400 text-emerald-800'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Installment Payment
                    <span className="block text-[10px] font-normal text-slate-500 mt-0.5">
                      {activePartyInModal?.type === 'supplier'
                        ? 'Hum ny ada kiya (Payable kam)'
                        : 'Unhon ny ada kiya (Receivable kam)'}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setTxType('stock_bill')}
                    className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      txType === 'stock_bill'
                        ? 'bg-amber-50 border-amber-400 text-amber-800'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Stock / Bill Added
                    <span className="block text-[10px] font-normal text-slate-500 mt-0.5">
                      {activePartyInModal?.type === 'supplier'
                        ? 'Naya stock aya (Bill barha)'
                        : 'Naya stock bheja (Bill barha)'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Date & Amount */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={txDate}
                    onChange={(e) => setTxDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Amount ({currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    placeholder="e.g. 25000"
                    value={txAmount}
                    onChange={(e) => setTxAmount(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              {/* Bill/Ref & Payment Method */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Bill / Receipt #</label>
                  <input
                    type="text"
                    placeholder="e.g. BIL-102 or RCP-55"
                    value={txBillNo}
                    onChange={(e) => setTxBillNo(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Payment Mode</label>
                  <select
                    value={txMethod}
                    onChange={(e: any) => setTxMethod(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
                  >
                    <option value="Cash">Cash</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cheque">Cheque</option>
                    <option value="Slip">Slip</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Description / Items Detail
                </label>
                <input
                  type="text"
                  placeholder="e.g. 1st installment paid, 5 bags flour, tea supplies..."
                  value={txDesc}
                  onChange={(e) => setTxDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsTxModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer shadow-xs"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useMemo } from 'react';
import {
  Wallet,
  Plus,
  Search,
  CreditCard,
  AlertOctagon,
  Building2,
  Users,
  Edit2,
  Trash2,
  ArrowUpRight,
  ArrowDownLeft,
  DollarSign,
  Briefcase,
  Printer,
  MessageSquare,
} from 'lucide-react';
import {
  StaffFinancialRecord,
  FinancialRecordType,
  Canteen,
  Staff,
  AttendanceRecord,
} from '../types';
import { formatCurrency, isCanteenMatch, formatDisplayDate } from '../lib/storage';
import { ConfirmModal } from './ConfirmModal';
import { calculateStaffSalaryBreakdown } from './StaffView';
import { SalarySlipModal, sendWhatsAppSalarySlip } from './SalarySlipModal';

interface StaffFinancialsViewProps {
  staffFinancials: StaffFinancialRecord[];
  staffList: Staff[];
  canteens: Canteen[];
  selectedCanteenId: string;
  currencySymbol: string;
  attendanceRecords?: AttendanceRecord[];
  onAddFinancialRecord: (record: Omit<StaffFinancialRecord, 'id' | 'createdAt'>) => void;
  onEditFinancialRecord: (id: string, record: Partial<StaffFinancialRecord>) => void;
  onDeleteFinancialRecord: (id: string) => void;
}

export const StaffFinancialsView: React.FC<StaffFinancialsViewProps> = ({
  staffFinancials,
  staffList,
  canteens,
  selectedCanteenId,
  currencySymbol,
  attendanceRecords = [],
  onAddFinancialRecord,
  onEditFinancialRecord,
  onDeleteFinancialRecord,
}) => {
  const activeStaff = (staffList || []).filter((s) => s.status === 'active');

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStaffIdFilter, setSelectedStaffIdFilter] = useState<string>('all');
  const [selectedSlipStaff, setSelectedSlipStaff] = useState<Staff | null>(null);

  // Filter staff options based on selected canteen
  const filteredStaffOptions = useMemo(() => {
    return (staffList || []).filter(
      (s) => isCanteenMatch(s, selectedCanteenId, canteens)
    );
  }, [staffList, selectedCanteenId, canteens]);

  React.useEffect(() => {
    if (
      selectedStaffIdFilter !== 'all' &&
      !filteredStaffOptions.some((s) => s.id === selectedStaffIdFilter)
    ) {
      setSelectedStaffIdFilter('all');
    }
  }, [selectedCanteenId, filteredStaffOptions, selectedStaffIdFilter]);

  // Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<StaffFinancialRecord | null>(null);

  // Form State
  const [staffId, setStaffId] = useState('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [type, setType] = useState<FinancialRecordType>('Advance');
  const [amount, setAmount] = useState<number | ''>('');
  const [note, setNote] = useState('');

  // Delete Target
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  // Calculated Staff Balance Summaries
  const staffSummaries = useMemo(() => {
    return staffList.map((s) => {
      const breakdown = calculateStaffSalaryBreakdown(
        s,
        attendanceRecords,
        staffFinancials
      );
      return {
        staff: s,
        ...breakdown,
      };
    }).filter((item) => {
      const matchesCanteen = isCanteenMatch(item.staff, selectedCanteenId, canteens);
      const matchesStaff =
        selectedStaffIdFilter === 'all' || item.staff.id === selectedStaffIdFilter;
      return matchesCanteen && matchesStaff;
    });
  }, [staffList, staffFinancials, attendanceRecords, selectedCanteenId, canteens, selectedStaffIdFilter]);

  // Filtered History Records
  const filteredRecords = useMemo(() => {
    return staffFinancials
      .filter((rec) => {
        const matchesCanteen = isCanteenMatch(rec, selectedCanteenId, canteens);
        const matchesStaff =
          selectedStaffIdFilter === 'all' || rec.staffId === selectedStaffIdFilter;
        const matchesSearch =
          (rec.staffName && rec.staffName.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (rec.note && rec.note.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (rec.canteenName && rec.canteenName.toLowerCase().includes(searchTerm.toLowerCase()));
        return matchesCanteen && matchesStaff && matchesSearch;
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [staffFinancials, selectedCanteenId, canteens, selectedStaffIdFilter, searchTerm]);

  const openAddModal = (preselectedStaffId?: string) => {
    setEditingRecord(null);
    const targetStaff = preselectedStaffId
      ? activeStaff.find((s) => s.id === preselectedStaffId)
      : activeStaff[0];
    setStaffId(targetStaff?.id || activeStaff[0]?.id || '');
    setDate(new Date().toISOString().split('T')[0]);
    setType('Advance');
    setAmount('');
    setNote('');
    setModalOpen(true);
  };

  const openEditModal = (rec: StaffFinancialRecord) => {
    setEditingRecord(rec);
    setStaffId(rec.staffId);
    setDate(rec.date);
    setType(rec.type);
    setAmount(rec.amount);
    setNote(rec.note);
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = typeof amount === 'number' ? amount : 0;
    const targetStaff = staffList.find((s) => s.id === staffId);
    if (!targetStaff || numAmount <= 0) return;

    const data = {
      staffId: targetStaff.id,
      staffName: targetStaff.name,
      canteenId: targetStaff.canteenId,
      canteenName: targetStaff.canteenName,
      date,
      type,
      amount: numAmount,
      note: note.trim(),
    };

    if (editingRecord) {
      onEditFinancialRecord(editingRecord.id, data);
    } else {
      onAddFinancialRecord(data);
    }

    setModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Wallet className="w-7 h-7 text-emerald-600" />
            <span>Staff Advances & Penalties</span>
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Maintain complete audit trails of staff salary advances and disciplinary penalties
          </p>
        </div>

        <button
          onClick={() => openAddModal()}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-xs transition-colors cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Record Advance / Penalty</span>
        </button>
      </div>

      {/* Staff Financial Balance Summaries Grid */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Staff Financial Balances</h2>
            <p className="text-xs text-slate-500">
              Per-staff total advances given, penalties levied, and net outstanding balance
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-400" />
            <select
              value={selectedStaffIdFilter}
              onChange={(e) => setSelectedStaffIdFilter(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800"
            >
              <option value="all">All Staff Members ({filteredStaffOptions.length})</option>
              {filteredStaffOptions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.canteenName})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {staffSummaries.map((item) => (
            <div
              key={item.staff.id}
              className="bg-slate-50/80 rounded-xl p-4 border border-slate-200 hover:border-slate-300 transition-all flex flex-col justify-between space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">{item.staff.name}</h3>
                  <div className="flex items-center gap-1 text-xs text-slate-500 mt-0.5">
                    <Briefcase className="w-3 h-3 text-emerald-600" />
                    <span className="font-semibold text-slate-700">{item.staff.designation}</span>
                    <span className="text-slate-300">•</span>
                    <span>{item.staff.canteenName}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => sendWhatsAppSalarySlip(item.staff, item, currencySymbol, item.staff.canteenName)}
                    className="text-xs font-bold text-white bg-emerald-500 hover:bg-emerald-600 px-2 py-1 rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                    title="Send Salary Slip on WhatsApp"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </button>

                  <button
                    onClick={() => setSelectedSlipStaff(item.staff)}
                    className="text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded-lg transition-colors cursor-pointer flex items-center gap-1 border border-slate-200"
                    title="Print Salary Slip"
                  >
                    <Printer className="w-3.5 h-3.5 text-slate-600" />
                    <span>Slip</span>
                  </button>

                  <button
                    onClick={() => openAddModal(item.staff.id)}
                    className="text-xs font-bold text-emerald-700 bg-emerald-100 hover:bg-emerald-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                  >
                    + Advance/Penalty
                  </button>
                </div>
              </div>

              {/* Salary Breakdown Details */}
              <div className="space-y-2 pt-2 border-t border-slate-200 text-xs">
                <div className="flex items-center justify-between text-slate-600">
                  <span className="font-medium">Total Basic Salary:</span>
                  <span className="font-bold text-slate-900">
                    {formatCurrency(item.basicSalary, currencySymbol)}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-1.5 bg-white p-2 rounded-lg border border-slate-200 text-[11px]">
                  <div>
                    <span className="text-slate-400 font-bold block text-[9px] uppercase">Leave Cut</span>
                    <span className="font-bold text-amber-700">
                      {formatCurrency(item.leaveDeduction, currencySymbol)}
                    </span>
                    <span className="text-[9px] text-slate-400 block">({item.totalAbsentLeaveDays} days)</span>
                  </div>
                  <div>
                    <span className="text-slate-400 font-bold block text-[9px] uppercase">Advances</span>
                    <span className="font-bold text-indigo-700">
                      {formatCurrency(item.totalAdvance, currencySymbol)}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 font-bold block text-[9px] uppercase">Penalties</span>
                    <span className="font-bold text-rose-700">
                      {formatCurrency(item.totalPenalty, currencySymbol)}
                    </span>
                  </div>
                </div>

                {/* Net Remaining Salary */}
                <div className="bg-slate-900 text-white p-2 rounded-lg flex items-center justify-between text-xs">
                  <span className="font-bold text-emerald-300 flex items-center gap-1">
                    <Wallet className="w-3.5 h-3.5 text-emerald-400" />
                    Remaining Salary:
                  </span>
                  <span className="font-black text-emerald-300">
                    {formatCurrency(item.remainingSalary, currencySymbol)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Complete Financial History Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden space-y-4">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Transaction History</h2>
            <p className="text-xs text-slate-500">
              Detailed list of advance disbursements and penalty deductions
            </p>
          </div>

          <div className="relative sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search history by staff or note..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-1.5 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Date</th>
                <th className="py-3.5 px-4">Staff Member</th>
                <th className="py-3.5 px-4">Canteen</th>
                <th className="py-3.5 px-4">Type</th>
                <th className="py-3.5 px-4 text-right">Amount</th>
                <th className="py-3.5 px-4">Note / Reason</th>
                <th className="py-3.5 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <Wallet className="w-10 h-10 mx-auto mb-2 opacity-30" />
                    <p className="font-semibold text-slate-600">No Financial Records Found</p>
                    <p className="text-xs text-slate-400 mt-1">
                      Click "Record Advance / Penalty" to log transactions.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredRecords.map((rec) => (
                  <tr key={rec.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-900 whitespace-nowrap">
                      {formatDisplayDate(rec.date)}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-800">
                      {rec.staffName}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-600">
                      {rec.canteenName}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                          rec.type === 'Advance'
                            ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {rec.type === 'Advance' ? (
                          <>
                            <ArrowUpRight className="w-3.5 h-3.5 text-indigo-600" /> Advance
                          </>
                        ) : (
                          <>
                            <ArrowDownLeft className="w-3.5 h-3.5 text-rose-600" /> Penalty
                          </>
                        )}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-black text-slate-900">
                      {formatCurrency(rec.amount, currencySymbol)}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-600 max-w-xs">
                      {rec.note || '-'}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => openEditModal(rec)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-200 transition-colors cursor-pointer"
                          title="Edit Record"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setDeleteTargetId(rec.id)}
                          className="p-1.5 rounded-lg text-rose-600 hover:text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer"
                          title="Delete Record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Form */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-900">
                {editingRecord ? 'Edit Financial Transaction' : 'Record Advance / Penalty'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Select Staff Member *
                </label>
                <select
                  required
                  value={staffId}
                  onChange={(e) => setStaffId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {activeStaff.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.canteenName})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Type *
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as FinancialRecordType)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Advance">Advance Given</option>
                    <option value="Penalty">Penalty Deduction</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Amount ({currencySymbol}) *
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  placeholder="e.g. 5000"
                  value={amount}
                  onChange={(e) =>
                    setAmount(e.target.value === '' ? '' : Number(e.target.value))
                  }
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Note / Purpose Description *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Medical emergency advance against salary"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 text-sm font-semibold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 text-sm font-semibold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 cursor-pointer shadow-xs"
                >
                  {editingRecord ? 'Save Changes' : 'Save Transaction'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmModal
        isOpen={deleteTargetId !== null}
        title="Delete Transaction?"
        message="Are you sure you want to delete this financial record?"
        confirmLabel="Delete Record"
        onConfirm={() => {
          if (deleteTargetId) onDeleteFinancialRecord(deleteTargetId);
          setDeleteTargetId(null);
        }}
        onClose={() => setDeleteTargetId(null)}
      />

      {/* Salary Slip Modal */}
      <SalarySlipModal
        isOpen={selectedSlipStaff !== null}
        onClose={() => setSelectedSlipStaff(null)}
        staff={selectedSlipStaff}
        canteen={canteens.find((c) => c.id === selectedSlipStaff?.canteenId)}
        currencySymbol={currencySymbol}
        attendanceRecords={attendanceRecords}
        staffFinancials={staffFinancials}
      />
    </div>
  );
};

import React, { useRef, useState } from 'react';
import { Printer, X, DollarSign, Calendar, Building2, User, Phone, CheckCircle2, MessageSquare, Copy, Check } from 'lucide-react';
import { Staff, AttendanceRecord, StaffFinancialRecord, Canteen } from '../types';
import { formatCurrency } from '../lib/storage';
import { calculateStaffSalaryBreakdown } from './StaffView';

export function generateWhatsAppSalaryMessage(
  staff: Staff,
  breakdown: ReturnType<typeof calculateStaffSalaryBreakdown>,
  currencySymbol: string,
  canteenName?: string
) {
  const monthYear = new Date().toLocaleDateString('en-PK', { month: 'long', year: 'numeric' });
  const dateStr = new Date().toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' });

  return `📄 *SKEM CANTEENS - MONTHLY SALARY PAYSLIP*
🗓️ *Month:* ${monthYear}
🏢 *Canteen:* ${canteenName || staff.canteenName || 'SKEM Canteen'}
----------------------------------
👤 *Staff Member:* ${staff.name}
💼 *Designation:* ${staff.designation}
📅 *Date:* ${dateStr}

💵 *Basic Monthly Salary:* ${currencySymbol} ${breakdown.basicSalary.toLocaleString()}
❌ *Leaves/Absents (${breakdown.totalAbsentLeaveDays} Days):* -${currencySymbol} ${breakdown.leaveDeduction.toLocaleString()}
💸 *Advances Taken:* -${currencySymbol} ${breakdown.totalAdvance.toLocaleString()}
⚠️ *Penalties/Deductions:* -${currencySymbol} ${breakdown.totalPenalty.toLocaleString()}
----------------------------------
💰 *NET PAYABLE SALARY:* *${currencySymbol} ${breakdown.remainingSalary.toLocaleString()}*

_Generated automatically by SKEM Canteen Management App. Please contact management if you have any questions._`;
}

export function sendWhatsAppSalarySlip(
  staff: Staff,
  breakdown: ReturnType<typeof calculateStaffSalaryBreakdown>,
  currencySymbol: string,
  canteenName?: string
) {
  const message = generateWhatsAppSalaryMessage(staff, breakdown, currencySymbol, canteenName);

  let cleanedPhone = (staff.phone || '').replace(/[^0-9+]/g, '');
  if (cleanedPhone.startsWith('0')) {
    cleanedPhone = '92' + cleanedPhone.substring(1);
  } else if (cleanedPhone.startsWith('+')) {
    cleanedPhone = cleanedPhone.substring(1);
  }

  const encoded = encodeURIComponent(message);
  const url = cleanedPhone
    ? `https://api.whatsapp.com/send?phone=${cleanedPhone}&text=${encoded}`
    : `https://api.whatsapp.com/send?text=${encoded}`;

  window.open(url, '_blank');
}

interface SalarySlipModalProps {
  isOpen: boolean;
  onClose: () => void;
  staff: Staff | null;
  canteen?: Canteen;
  currencySymbol: string;
  attendanceRecords: AttendanceRecord[];
  staffFinancials: StaffFinancialRecord[];
}

export const SalarySlipModal: React.FC<SalarySlipModalProps> = ({
  isOpen,
  onClose,
  staff,
  canteen,
  currencySymbol,
  attendanceRecords,
  staffFinancials,
}) => {
  const printRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen || !staff) return null;

  const breakdown = calculateStaffSalaryBreakdown(
    staff,
    attendanceRecords,
    staffFinancials
  );

  const currentDate = new Date().toLocaleDateString('en-PK', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const currentMonthYear = new Date().toLocaleDateString('en-PK', {
    month: 'long',
    year: 'numeric',
  });

  const handlePrint = () => {
    window.print();
  };

  const handleSendWhatsApp = () => {
    sendWhatsAppSalarySlip(staff, breakdown, currencySymbol, canteen?.name || staff.canteenName);
  };

  const handleCopyText = () => {
    const text = generateWhatsAppSalaryMessage(staff, breakdown, currencySymbol, canteen?.name || staff.canteenName);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 space-y-6 relative print:shadow-none print:border-none print:w-full print:max-w-none print:p-0">
        {/* Header Bar - Hidden during printing */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                Staff Salary Payslip / Vouchers
              </h2>
              <p className="text-xs text-slate-500">
                Official monthly salary statement for {staff.name}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 px-4 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Print Salary Slip</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PRINTABLE SLIP CONTAINER */}
        <div ref={printRef} className="printable-salary-slip space-y-6 text-slate-900 font-sans p-2">
          {/* Slip Header */}
          <div className="text-center space-y-1 border-b-2 border-slate-900 pb-4">
            <h1 className="text-2xl font-black tracking-wider uppercase text-emerald-800">
              SKEM CANTEENS MANAGEMENT
            </h1>
            <p className="text-xs font-bold text-slate-600">
              SALARY PAYSLIP / MONTHLY VOUCHER ({currentMonthYear.toUpperCase()})
            </p>
            <p className="text-[11px] text-slate-500">
              Generated Date: {currentDate}
            </p>
          </div>

          {/* Canteen & Staff Meta Info Grid */}
          <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs">
            <div className="space-y-1.5">
              <div className="flex items-center gap-1.5 font-bold text-slate-900">
                <User className="w-4 h-4 text-emerald-700 shrink-0" />
                <span className="text-sm">{staff.name}</span>
              </div>
              <p className="text-slate-600 font-semibold">
                Designation: <span className="text-slate-900 font-bold">{staff.designation}</span>
              </p>
              {staff.phone && (
                <p className="text-slate-600">Phone: {staff.phone}</p>
              )}
              <p className="text-slate-500 text-[11px]">Joined: {staff.joiningDate}</p>
            </div>

            <div className="space-y-1.5 text-right">
              <div className="flex items-center justify-end gap-1.5 font-bold text-slate-900">
                <Building2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>{staff.canteenName || canteen?.name}</span>
              </div>
              {canteen?.location && (
                <p className="text-slate-600">Location: {canteen.location}</p>
              )}
              <p className="text-slate-600 font-semibold">
                Status: <span className="text-emerald-700 font-bold uppercase">{staff.status}</span>
              </p>
            </div>
          </div>

          {/* Salary Breakdown Table */}
          <div className="space-y-2">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-700 border-b border-slate-200 pb-1">
              Salary Computation & Deductions Breakdown
            </h3>

            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
                  <th className="p-2.5">Description / Item</th>
                  <th className="p-2.5 text-center">Details</th>
                  <th className="p-2.5 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {/* Basic Salary */}
                <tr>
                  <td className="p-2.5 font-bold text-slate-900">
                    Total Monthly Basic Fixed Salary
                  </td>
                  <td className="p-2.5 text-center text-slate-500">Standard 30 Days</td>
                  <td className="p-2.5 text-right font-black text-slate-900">
                    {formatCurrency(breakdown.basicSalary, currencySymbol)}
                  </td>
                </tr>

                {/* Leaves & Absents */}
                <tr>
                  <td className="p-2.5 text-slate-700 font-medium">
                    Attendance Deduction (Absents & Leaves)
                  </td>
                  <td className="p-2.5 text-center text-amber-800 font-bold">
                    {breakdown.totalAbsentLeaveDays} Days Total
                  </td>
                  <td className="p-2.5 text-right font-bold text-amber-700">
                    - {formatCurrency(breakdown.leaveDeduction, currencySymbol)}
                  </td>
                </tr>

                {/* Advances */}
                <tr>
                  <td className="p-2.5 text-slate-700 font-medium">
                    Total Advances Taken
                  </td>
                  <td className="p-2.5 text-center text-indigo-800 font-bold">
                    Loan / Pre-payments
                  </td>
                  <td className="p-2.5 text-right font-bold text-indigo-700">
                    - {formatCurrency(breakdown.totalAdvance, currencySymbol)}
                  </td>
                </tr>

                {/* Penalties */}
                <tr>
                  <td className="p-2.5 text-slate-700 font-medium">
                    Penalties & Fine Deductions
                  </td>
                  <td className="p-2.5 text-center text-rose-800 font-bold">
                    Violations / Damage
                  </td>
                  <td className="p-2.5 text-right font-bold text-rose-700">
                    - {formatCurrency(breakdown.totalPenalty, currencySymbol)}
                  </td>
                </tr>

                {/* Total Deductions Summary */}
                <tr className="bg-slate-50 font-bold text-slate-800 border-t-2 border-slate-300">
                  <td className="p-2.5">Total Deductions Cut</td>
                  <td className="p-2.5 text-center text-xs text-slate-500">Subtotal Cut</td>
                  <td className="p-2.5 text-right text-rose-700">
                    - {formatCurrency(breakdown.totalDeductions, currencySymbol)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* NET PAYABLE BOX */}
          <div className="bg-emerald-950 text-white rounded-2xl p-5 flex items-center justify-between border-2 border-emerald-600 print:bg-slate-900">
            <div>
              <p className="text-xs uppercase tracking-wider text-emerald-300 font-bold">
                Net Remaining Salary Payable:
              </p>
              <p className="text-[11px] text-emerald-200 mt-0.5">
                Calculated after deducting leaves, advances & penalties
              </p>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black text-emerald-300">
                {formatCurrency(breakdown.remainingSalary, currencySymbol)}
              </span>
            </div>
          </div>

          {/* Signatures Footer */}
          <div className="pt-12 grid grid-cols-2 gap-8 text-xs text-center border-t border-slate-200">
            <div className="space-y-8">
              <div className="border-b border-slate-400 w-3/4 mx-auto" />
              <p className="font-bold text-slate-800">
                Staff Member Signature ({staff.name})
              </p>
            </div>

            <div className="space-y-8">
              <div className="border-b border-slate-400 w-3/4 mx-auto" />
              <p className="font-bold text-slate-800">
                Canteen Manager / Owner Stamp & Sign
              </p>
            </div>
          </div>
        </div>

        {/* Modal Action Buttons (Screen only) */}
        <div className="pt-2 flex flex-wrap items-center justify-between gap-3 print:hidden border-t border-slate-100">
          <div className="flex items-center gap-2">
            <button
              onClick={handleSendWhatsApp}
              className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
              title="Send formatted salary slip to employee on WhatsApp"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Send WhatsApp Slip 📲</span>
            </button>

            <button
              onClick={handleCopyText}
              className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
              title="Copy slip text to clipboard"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Text</span>
                </>
              )}
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer transition-colors"
            >
              Close
            </button>
            <button
              onClick={handlePrint}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Print Slip</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

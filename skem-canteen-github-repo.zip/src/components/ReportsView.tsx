import React, { useState, useMemo } from 'react';
import {
  FileSpreadsheet,
  Download,
  Calendar,
  Building2,
  Users,
  Search,
  Filter,
  Receipt,
  CalendarCheck,
  Wallet,
  TrendingUp,
  DollarSign,
  Briefcase,
  Printer,
} from 'lucide-react';
import {
  AppState,
  Canteen,
  Staff,
} from '../types';
import { formatCurrency, downloadExcel, isCanteenMatch, formatDisplayDate } from '../lib/storage';
import { calculateStaffSalaryBreakdown } from './StaffView';
import { SalarySlipModal } from './SalarySlipModal';

interface ReportsViewProps {
  state: AppState;
  selectedCanteenId: string;
  setSelectedCanteenId: (id: string) => void;
}

type ReportTab =
  | 'daily_canteen'
  | 'monthly_summary'
  | 'attendance'
  | 'staff_financials'
  | 'staff_salary_summary';

export const ReportsView: React.FC<ReportsViewProps> = ({
  state,
  selectedCanteenId,
  setSelectedCanteenId,
}) => {
  const [activeReportTab, setActiveReportTab] = useState<ReportTab>('daily_canteen');
  const [dailySubFilter, setDailySubFilter] = useState<'all' | 'sales' | 'expenses' | 'purchases'>('all');

  // Filter States - default to start of current year/month
  const [startDate, setStartDate] = useState<string>('2026-07-01');
  const [endDate, setEndDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [selectedStaffId, setSelectedStaffId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSlipStaff, setSelectedSlipStaff] = useState<Staff | null>(null);

  const activeCanteens = (state.canteens || []).filter((c) => c.status === 'active');
  const currency = state.currencySymbol || 'Rs.';

  // Filter staff options based on selected canteen
  const filteredStaffOptions = useMemo(() => {
    return (state.staffList || []).filter(
      (s) => isCanteenMatch(s, selectedCanteenId, state.canteens)
    );
  }, [state.staffList, selectedCanteenId, state.canteens]);

  // Reset staff selection if staff is not in the filtered list
  React.useEffect(() => {
    if (
      selectedStaffId !== 'all' &&
      !filteredStaffOptions.some((s) => s.id === selectedStaffId)
    ) {
      setSelectedStaffId('all');
    }
  }, [selectedCanteenId, filteredStaffOptions, selectedStaffId]);

  // Helper date boundary check
  const isDateInRange = (dateStr: string) => {
    if (!startDate && !endDate) return true;
    const d = new Date(dateStr + 'T00:00:00');
    if (startDate) {
      const s = new Date(startDate + 'T00:00:00');
      if (d < s) return false;
    }
    if (endDate) {
      const e = new Date(endDate + 'T23:59:59');
      if (d > e) return false;
    }
    return true;
  };

  // 1. Daily Canteen Data
  const filteredDailyEntries = useMemo(() => {
    return state.dailyEntries
      .filter((e) => {
        const matchesCanteen = isCanteenMatch(e, selectedCanteenId, state.canteens);
        const matchesDate = isDateInRange(e.date);
        const matchesSearch =
          (e.canteenName && e.canteenName.toLowerCase().includes(searchQuery.toLowerCase())) ||
          e.date.includes(searchQuery) ||
          (e.remarks && e.remarks.toLowerCase().includes(searchQuery.toLowerCase()));
        return matchesCanteen && matchesDate && matchesSearch;
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [state.dailyEntries, selectedCanteenId, state.canteens, startDate, endDate, searchQuery]);

  // Filter Daily Entries by sub-category: all, sales, expenses, purchases
  const displayedDailyEntries = useMemo(() => {
    return filteredDailyEntries.filter((e) => {
      if (dailySubFilter === 'sales') return (e.normalSale || 0) > 0 || (e.tokenSale || 0) > 0;
      if (dailySubFilter === 'expenses') return (e.expenses || 0) > 0;
      if (dailySubFilter === 'purchases') return (e.purchase || 0) > 0;
      return true;
    });
  }, [filteredDailyEntries, dailySubFilter]);

  // Daily Report Totals & Baqi Cash Sale calculation
  const dailyReportTotals = useMemo(() => {
    let cashSale = 0;
    let tokenSale = 0;
    let purchase = 0;
    let expenses = 0;

    displayedDailyEntries.forEach((e) => {
      cashSale += e.normalSale || 0;
      tokenSale += e.tokenSale || 0;
      purchase += e.purchase || 0;
      expenses += e.expenses || 0;
    });

    const totalSale = cashSale + tokenSale;
    const totalExpensesAndStock = expenses + purchase;
    const baqiCashSale = cashSale - totalExpensesAndStock;
    const netProfit = totalSale - totalExpensesAndStock;

    return {
      cashSale,
      tokenSale,
      totalSale,
      purchase,
      expenses,
      totalExpensesAndStock,
      baqiCashSale,
      netProfit,
    };
  }, [displayedDailyEntries]);

  // 2. Monthly Summary Data (Grouped by Month & Canteen)
  const monthlySummaryData = useMemo(() => {
    const map: Record<
      string,
      {
        monthYear: string;
        canteenId: string;
        canteenName: string;
        normalSale: number;
        tokenSale: number;
        totalSale: number;
        purchase: number;
        expenses: number;
        netAmount: number;
        entriesCount: number;
      }
    > = {};

    filteredDailyEntries.forEach((e) => {
      const monthYear = e.date.substring(0, 7); // YYYY-MM
      const key = `${monthYear}_${e.canteenId}`;

      if (!map[key]) {
        map[key] = {
          monthYear,
          canteenId: e.canteenId,
          canteenName: e.canteenName,
          normalSale: 0,
          tokenSale: 0,
          totalSale: 0,
          purchase: 0,
          expenses: 0,
          netAmount: 0,
          entriesCount: 0,
        };
      }

      map[key].normalSale += e.normalSale;
      map[key].tokenSale += e.tokenSale;
      map[key].totalSale += e.totalSale;
      map[key].purchase += e.purchase;
      map[key].expenses += e.expenses;
      map[key].netAmount += e.netAmount;
      map[key].entriesCount += 1;
    });

    return Object.values(map).sort((a, b) => a.monthYear.localeCompare(b.monthYear));
  }, [filteredDailyEntries]);

  // 3. Attendance Data
  const filteredAttendance = useMemo(() => {
    return state.attendanceRecords
      .filter((a) => {
        const matchesCanteen = isCanteenMatch(a, selectedCanteenId, state.canteens);
        const matchesStaff =
          selectedStaffId === 'all' || a.staffId === selectedStaffId;
        const matchesDate = isDateInRange(a.date);
        const matchesSearch =
          (a.staffName && a.staffName.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (a.canteenName && a.canteenName.toLowerCase().includes(searchQuery.toLowerCase()));
        return matchesCanteen && matchesStaff && matchesDate && matchesSearch;
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [state.attendanceRecords, selectedCanteenId, state.canteens, selectedStaffId, startDate, endDate, searchQuery]);

  // 4. Staff Financials Data
  const filteredFinancials = useMemo(() => {
    return state.staffFinancials
      .filter((f) => {
        const matchesCanteen = isCanteenMatch(f, selectedCanteenId, state.canteens);
        const matchesStaff =
          selectedStaffId === 'all' || f.staffId === selectedStaffId;
        const matchesDate = isDateInRange(f.date);
        const matchesSearch =
          (f.staffName && f.staffName.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (f.note && f.note.toLowerCase().includes(searchQuery.toLowerCase()));
        return matchesCanteen && matchesStaff && matchesDate && matchesSearch;
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [state.staffFinancials, selectedCanteenId, state.canteens, selectedStaffId, startDate, endDate, searchQuery]);

  // Excel Export Handler according to prompt specification
  const handleExportExcel = () => {
    if (activeReportTab === 'daily_canteen') {
      const exportRows = displayedDailyEntries.map((e) => ({
        Date: formatDisplayDate(e.date),
        Canteen: e.canteenName,
        'Cash Sale (Normal)': e.normalSale,
        'Expenses (Kharcha)': e.expenses,
        'Purchase (Stock)': e.purchase,
        'Baqi Cash Sale': (e.normalSale || 0) - ((e.expenses || 0) + (e.purchase || 0)),
        'Token Sale (Monthly)': e.tokenSale,
        'Total Sale Volume': e.totalSale,
        'Net Profit': e.netAmount,
        'Expense Note': e.expenseNote || '',
        Remarks: e.remarks || '',
      }));
      downloadExcel(exportRows, `Canteen_Daily_Report_${startDate}_to_${endDate}`, 'Daily Financials');
    } else if (activeReportTab === 'monthly_summary') {
      const exportRows = monthlySummaryData.map((m) => ({
        Month: m.monthYear,
        Canteen: m.canteenName,
        'Normal Sale': m.normalSale,
        'Token Sale': m.tokenSale,
        'Total Sale': m.totalSale,
        Purchase: m.purchase,
        Expenses: m.expenses,
        'Net Amount': m.netAmount,
        'Total Days Recorded': m.entriesCount,
      }));
      downloadExcel(exportRows, `Monthly_Canteen_Summary_${startDate}_to_${endDate}`, 'Monthly Totals');
    } else if (activeReportTab === 'attendance') {
      const exportRows = filteredAttendance.map((a) => ({
        Date: formatDisplayDate(a.date),
        'Staff Name': a.staffName,
        Canteen: a.canteenName,
        Status: a.status,
        'In Time': a.inTime || '',
        'Out Time': a.outTime || '',
        'Leave Reason': a.leaveReason || '',
        Remarks: a.remarks || '',
      }));
      downloadExcel(exportRows, `Staff_Attendance_Report_${startDate}_to_${endDate}`, 'Attendance Logs');
    } else if (activeReportTab === 'staff_financials') {
      const exportRows = filteredFinancials.map((f) => ({
        Date: formatDisplayDate(f.date),
        'Staff Name': f.staffName,
        Canteen: f.canteenName,
        Type: f.type,
        Amount: f.amount,
        Note: f.note,
      }));
      downloadExcel(
        exportRows,
        `Staff_Advances_Penalties_${startDate}_to_${endDate}`,
        'Advances & Penalties'
      );
    } else if (activeReportTab === 'staff_salary_summary') {
      const exportRows = staffSalaryReports.map((item) => ({
        'Staff Name': item.staff.name,
        Designation: item.staff.designation,
        Canteen: item.staff.canteenName,
        'Total Monthly Salary': item.basicSalary,
        'Absent/Leave Days': item.totalAbsentLeaveDays,
        'Leave Deduction': item.leaveDeduction,
        'Advances Taken': item.totalAdvance,
        'Penalties Incurred': item.totalPenalty,
        'Total Deductions': item.totalDeductions,
        'Net Remaining Salary': item.remainingSalary,
      }));
      downloadExcel(
        exportRows,
        `Staff_Salary_Remaining_Balance_Report_${new Date().toISOString().split('T')[0]}`,
        'Staff Salary Summary'
      );
    }
  };

  const staffSalaryReports = useMemo(() => {
    return (state.staffList || [])
      .filter((s) => {
        const matchesCanteen =
          selectedCanteenId === 'all' || s.canteenId === selectedCanteenId;
        const matchesStaff =
          selectedStaffId === 'all' || s.id === selectedStaffId;
        const matchesSearch =
          s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.designation.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.canteenName.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCanteen && matchesStaff && matchesSearch;
      })
      .map((staff) => {
        const breakdown = calculateStaffSalaryBreakdown(
          staff,
          state.attendanceRecords || [],
          state.staffFinancials || []
        );
        return {
          staff,
          ...breakdown,
        };
      });
  }, [
    state.staffList,
    state.attendanceRecords,
    state.staffFinancials,
    selectedCanteenId,
    selectedStaffId,
    searchQuery,
  ]);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <FileSpreadsheet className="w-7 h-7 text-emerald-600" />
            <span>Reports & Excel Export</span>
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Generate clean, filterable reports for daily sales, monthly canteen performance, attendance, and advances
          </p>
        </div>

        <button
          onClick={handleExportExcel}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm px-5 py-3 rounded-xl flex items-center gap-2 shadow-sm transition-all hover:scale-[1.02] cursor-pointer self-start md:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Export to Excel (.xlsx)</span>
        </button>
      </div>

      {/* Filter Control Box */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-emerald-600" />
            <span className="text-xs font-bold uppercase text-slate-700 tracking-wider">
              Report Parameters & Date Range
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 text-xs font-bold">
            <button
              onClick={() => {
                setStartDate('');
                setEndDate('');
              }}
              className={`px-2.5 py-1 rounded-lg cursor-pointer transition-colors ${
                !startDate && !endDate ? 'bg-slate-900 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
              }`}
            >
              All Time
            </button>
            <button
              onClick={() => {
                const today = new Date().toISOString().split('T')[0];
                setStartDate(today);
                setEndDate(today);
              }}
              className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg cursor-pointer transition-colors"
            >
              Today (Aaj)
            </button>
            <button
              onClick={() => {
                const y = new Date();
                y.setDate(y.getDate() - 1);
                const yStr = y.toISOString().split('T')[0];
                setStartDate(yStr);
                setEndDate(yStr);
              }}
              className="px-2.5 py-1 bg-teal-50 hover:bg-teal-100 text-teal-800 rounded-lg cursor-pointer transition-colors"
            >
              Yesterday (Kal)
            </button>
            <button
              onClick={() => {
                const now = new Date();
                const start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
                const end = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0];
                setStartDate(start);
                setEndDate(end);
              }}
              className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-lg cursor-pointer transition-colors"
            >
              This Month
            </button>
            <button
              onClick={() => {
                const now = new Date();
                const start = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().split('T')[0];
                const end = new Date(now.getFullYear(), now.getMonth(), 0).toISOString().split('T')[0];
                setStartDate(start);
                setEndDate(end);
              }}
              className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 rounded-lg cursor-pointer transition-colors"
            >
              Last Month
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs font-semibold text-slate-700">
          {/* Start Date */}
          <div>
            <label className="block text-slate-500 mb-1">Start Date</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* End Date */}
          <div>
            <label className="block text-slate-500 mb-1">End Date</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Canteen Filter */}
          <div>
            <label className="block text-slate-500 mb-1">Canteen Filter</label>
            <select
              value={selectedCanteenId}
              onChange={(e) => setSelectedCanteenId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Canteens ({activeCanteens.length})</option>
              {activeCanteens.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Staff Filter */}
          <div>
            <label className="block text-slate-500 mb-1">Staff Member</label>
            <select
              value={selectedStaffId}
              onChange={(e) => setSelectedStaffId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">
                All Staff Members ({filteredStaffOptions.length})
              </option>
              {filteredStaffOptions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.canteenName})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Search */}
        <div className="relative pt-2">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search report records..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>
      </div>

      {/* Report Selection Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-px">
        {[
          { id: 'daily_canteen' as ReportTab, label: 'Daily Canteen Report', icon: Receipt },
          { id: 'monthly_summary' as ReportTab, label: 'Monthly Summary', icon: TrendingUp },
          { id: 'attendance' as ReportTab, label: 'Attendance Report', icon: CalendarCheck },
          { id: 'staff_financials' as ReportTab, label: 'Advances & Penalties', icon: Wallet },
          { id: 'staff_salary_summary' as ReportTab, label: 'Staff Remaining Salary', icon: DollarSign },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeReportTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveReportTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-bold border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'border-emerald-600 text-emerald-700 bg-emerald-50/50 rounded-t-xl'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Report Tables Content */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* TAB 1: DAILY CANTEEN REPORT */}
        {activeReportTab === 'daily_canteen' && (
          <div className="space-y-4">
            {/* Category Filter Pills & Record Counter */}
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold text-slate-500 mr-1">Filter Record Type:</span>
                {[
                  { id: 'all' as const, label: 'Sab Records (All)' },
                  { id: 'sales' as const, label: '🟢 Sales Records' },
                  { id: 'expenses' as const, label: '🔴 Expenses Only (Akhrajaat)' },
                  { id: 'purchases' as const, label: '🟠 Purchases Only (Samaan)' },
                ].map((pill) => (
                  <button
                    key={pill.id}
                    onClick={() => setDailySubFilter(pill.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                      dailySubFilter === pill.id
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {pill.label}
                  </button>
                ))}
              </div>
              <span className="text-xs font-bold text-slate-600 bg-white px-3 py-1 rounded-xl border border-slate-200 self-start sm:self-auto">
                Showing {displayedDailyEntries.length} of {filteredDailyEntries.length} entries
              </span>
            </div>

            {/* Aasan Hisaab Formula KPI Strip */}
            <div className="mx-4 p-4 bg-slate-900 text-white rounded-2xl border border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="text-center p-2 rounded-xl bg-slate-800/60">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">1. Cash Sale (Counter)</span>
                <p className="text-base sm:text-lg font-black text-emerald-400 mt-0.5 font-mono">
                  {formatCurrency(dailyReportTotals.cashSale, currency)}
                </p>
              </div>

              <div className="text-center p-2 rounded-xl bg-rose-950/40 border border-rose-500/30">
                <span className="text-[10px] uppercase font-bold text-rose-300 block">2. Minus Akhrajaat (−)</span>
                <p className="text-base sm:text-lg font-black text-rose-300 mt-0.5 font-mono">
                  −{formatCurrency(dailyReportTotals.totalExpensesAndStock, currency)}
                </p>
                <span className="text-[9px] text-rose-300/70 block mt-0.5">
                  Kharch ({formatCurrency(dailyReportTotals.expenses, currency)}) + Samaan ({formatCurrency(dailyReportTotals.purchase, currency)})
                </span>
              </div>

              <div className="text-center p-2 rounded-xl bg-emerald-950/60 border border-emerald-400 shadow-xs">
                <span className="text-[10px] uppercase font-black text-emerald-300 block">3. Baqi Cash Sale (=)</span>
                <p className="text-base sm:text-lg font-black text-emerald-200 mt-0.5 font-mono">
                  {formatCurrency(dailyReportTotals.baqiCashSale, currency)}
                </p>
                <span className="text-[9px] text-emerald-400 font-bold block mt-0.5">Sale − Kharcha</span>
              </div>

              <div className="text-center p-2 rounded-xl bg-purple-950/40 border border-purple-500/30">
                <span className="text-[10px] uppercase font-bold text-purple-300 block">Token Sale (Alag Hisaab)</span>
                <p className="text-base sm:text-lg font-black text-purple-300 mt-0.5 font-mono">
                  {formatCurrency(dailyReportTotals.tokenSale, currency)}
                </p>
                <span className="text-[9px] text-purple-300/70 block mt-0.5">Month-End Khata</span>
              </div>
            </div>

            {/* Daily Canteen Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-y border-slate-200">
                  <tr>
                    <th className="py-3.5 px-4">Date</th>
                    <th className="py-3.5 px-4">Canteen / Branch</th>
                    <th className="py-3.5 px-4 text-right">Cash Sale (Counter)</th>
                    <th className="py-3.5 px-4 text-right">Expenses (Kharch)</th>
                    <th className="py-3.5 px-4 text-right">Purchase (Samaan)</th>
                    <th className="py-3.5 px-4 text-right">Baqi Cash Sale</th>
                    <th className="py-3.5 px-4 text-right">Token Sale (Alag)</th>
                    <th className="py-3.5 px-4 text-right">Total Sale</th>
                    <th className="py-3.5 px-4">Expense Note / Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {displayedDailyEntries.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-slate-400">
                        No records match parameters for Daily Canteen Report.
                      </td>
                    </tr>
                  ) : (
                    displayedDailyEntries.map((e) => {
                      const baqiCash = (e.normalSale || 0) - ((e.expenses || 0) + (e.purchase || 0));
                      return (
                        <tr key={e.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3.5 px-4 font-mono text-xs font-bold text-slate-800 whitespace-nowrap">
                            {formatDisplayDate(e.date)}
                          </td>
                          <td className="py-3.5 px-4 font-bold text-slate-900">
                            {e.canteenName}
                          </td>
                          <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900">
                            {formatCurrency(e.normalSale, currency)}
                          </td>
                          <td className="py-3.5 px-4 text-right font-mono font-semibold text-rose-700">
                            {e.expenses > 0 ? `−${formatCurrency(e.expenses, currency)}` : '0'}
                          </td>
                          <td className="py-3.5 px-4 text-right font-mono font-semibold text-amber-700">
                            {e.purchase > 0 ? `−${formatCurrency(e.purchase, currency)}` : '0'}
                          </td>
                          <td className="py-3.5 px-4 text-right font-mono font-black">
                            <span
                              className={`inline-block px-2.5 py-1 rounded-lg text-xs ${
                                baqiCash >= 0
                                  ? 'bg-emerald-100 text-emerald-900 border border-emerald-300/80'
                                  : 'bg-rose-100 text-rose-900 border border-rose-300/80'
                              }`}
                            >
                              {formatCurrency(baqiCash, currency)}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-right font-mono font-semibold text-purple-700">
                            {formatCurrency(e.tokenSale, currency)}
                          </td>
                          <td className="py-3.5 px-4 text-right font-mono font-black text-slate-900">
                            {formatCurrency(e.totalSale, currency)}
                          </td>
                          <td className="py-3.5 px-4 text-xs text-slate-600 max-w-xs truncate">
                            {e.expenseNote ? (
                              <span className="font-semibold text-rose-800 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                                {e.expenseNote}
                              </span>
                            ) : (
                              e.remarks || '—'
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
                {displayedDailyEntries.length > 0 && (
                  <tfoot className="bg-slate-100 font-bold text-slate-900 border-t-2 border-slate-200">
                    <tr>
                      <td colSpan={2} className="py-3.5 px-4 text-xs uppercase tracking-wider font-extrabold">
                        Grand Total ({displayedDailyEntries.length} Entries)
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-black text-slate-950">
                        {formatCurrency(dailyReportTotals.cashSale, currency)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-black text-rose-800">
                        −{formatCurrency(dailyReportTotals.expenses, currency)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-black text-amber-800">
                        −{formatCurrency(dailyReportTotals.purchase, currency)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-black text-emerald-900">
                        {formatCurrency(dailyReportTotals.baqiCashSale, currency)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-black text-purple-900">
                        {formatCurrency(dailyReportTotals.tokenSale, currency)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-black text-slate-950">
                        {formatCurrency(dailyReportTotals.totalSale, currency)}
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: MONTHLY SUMMARY */}
        {activeReportTab === 'monthly_summary' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3.5 px-4">Month</th>
                  <th className="py-3.5 px-4">Canteen</th>
                  <th className="py-3.5 px-4 text-center">Entries</th>
                  <th className="py-3.5 px-4 text-right">Normal Sale</th>
                  <th className="py-3.5 px-4 text-right">Token Sale</th>
                  <th className="py-3.5 px-4 text-right">Total Sale</th>
                  <th className="py-3.5 px-4 text-right">Purchase</th>
                  <th className="py-3.5 px-4 text-right">Expenses</th>
                  <th className="py-3.5 px-4 text-right">Net Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {monthlySummaryData.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-slate-400">
                      No data available for Monthly Summary.
                    </td>
                  </tr>
                ) : (
                  monthlySummaryData.map((m, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-black text-slate-900">{m.monthYear}</td>
                      <td className="py-3.5 px-4 font-bold text-slate-800">{m.canteenName}</td>
                      <td className="py-3.5 px-4 text-center font-semibold text-slate-500">{m.entriesCount} days</td>
                      <td className="py-3.5 px-4 text-right font-medium">{formatCurrency(m.normalSale, currency)}</td>
                      <td className="py-3.5 px-4 text-right font-medium text-purple-700">{formatCurrency(m.tokenSale, currency)}</td>
                      <td className="py-3.5 px-4 text-right font-bold text-blue-900">{formatCurrency(m.totalSale, currency)}</td>
                      <td className="py-3.5 px-4 text-right font-medium text-amber-700">{formatCurrency(m.purchase, currency)}</td>
                      <td className="py-3.5 px-4 text-right font-medium text-rose-700">{formatCurrency(m.expenses, currency)}</td>
                      <td className="py-3.5 px-4 text-right font-black">
                        <span className="bg-emerald-50 text-emerald-800 px-2 py-1 rounded-lg">
                          {formatCurrency(m.netAmount, currency)}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* TAB 3: ATTENDANCE REPORT */}
        {activeReportTab === 'attendance' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3.5 px-4">Date</th>
                  <th className="py-3.5 px-4">Staff Member</th>
                  <th className="py-3.5 px-4">Canteen</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">In Time</th>
                  <th className="py-3.5 px-4">Out Time</th>
                  <th className="py-3.5 px-4">Leave Reason</th>
                  <th className="py-3.5 px-4">Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAttendance.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400">
                      No attendance records found for parameters.
                    </td>
                  </tr>
                ) : (
                  filteredAttendance.map((a) => (
                    <tr key={a.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-slate-900">{formatDisplayDate(a.date)}</td>
                      <td className="py-3.5 px-4 font-bold text-slate-800">{a.staffName}</td>
                      <td className="py-3.5 px-4 text-slate-600">{a.canteenName}</td>
                      <td className="py-3.5 px-4 font-bold">
                        <span
                          className={`px-2 py-0.5 rounded-full text-xs ${
                            a.status === 'Present'
                              ? 'bg-emerald-100 text-emerald-800'
                              : a.status === 'Leave'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {a.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-xs font-semibold">{a.inTime || '-'}</td>
                      <td className="py-3.5 px-4 text-xs font-semibold">{a.outTime || '-'}</td>
                      <td className="py-3.5 px-4 text-xs text-slate-600">{a.leaveReason || '-'}</td>
                      <td className="py-3.5 px-4 text-xs text-slate-500 italic">{a.remarks || '-'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* TAB 4: STAFF FINANCIALS REPORT */}
        {activeReportTab === 'staff_financials' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3.5 px-4">Date</th>
                  <th className="py-3.5 px-4">Staff Member</th>
                  <th className="py-3.5 px-4">Canteen</th>
                  <th className="py-3.5 px-4">Type</th>
                  <th className="py-3.5 px-4 text-right">Amount</th>
                  <th className="py-3.5 px-4">Note</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredFinancials.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400">
                      No financial records found for parameters.
                    </td>
                  </tr>
                ) : (
                  filteredFinancials.map((f) => (
                    <tr key={f.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-slate-900">{formatDisplayDate(f.date)}</td>
                      <td className="py-3.5 px-4 font-bold text-slate-800">{f.staffName}</td>
                      <td className="py-3.5 px-4 text-slate-600">{f.canteenName}</td>
                      <td className="py-3.5 px-4 font-bold">
                        <span
                          className={`px-2 py-0.5 rounded-full text-xs ${
                            f.type === 'Advance'
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {f.type}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right font-black">
                        {formatCurrency(f.amount, currency)}
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-600">{f.note || '-'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* TAB 5: STAFF SALARY & REMAINING BALANCE REPORT */}
        {activeReportTab === 'staff_salary_summary' && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3.5 px-4">Staff Member</th>
                  <th className="py-3.5 px-4">Designation</th>
                  <th className="py-3.5 px-4">Canteen</th>
                  <th className="py-3.5 px-4 text-right">Total Basic Salary</th>
                  <th className="py-3.5 px-4 text-center">Absents / Leaves</th>
                  <th className="py-3.5 px-4 text-right">Leave Cut</th>
                  <th className="py-3.5 px-4 text-right">Advances</th>
                  <th className="py-3.5 px-4 text-right">Penalties</th>
                  <th className="py-3.5 px-4 text-right">Remaining Salary</th>
                  <th className="py-3.5 px-4 text-center">Payslip</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {staffSalaryReports.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="py-12 text-center text-slate-400">
                      No staff salary records found matching selected filter.
                    </td>
                  </tr>
                ) : (
                  staffSalaryReports.map((item) => (
                    <tr key={item.staff.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        {item.staff.name}
                      </td>
                      <td className="py-3.5 px-4 text-xs font-semibold text-slate-700">
                        <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded-md border border-slate-200">
                          {item.staff.designation}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-600">
                        {item.staff.canteenName}
                      </td>
                      <td className="py-3.5 px-4 text-right font-bold text-slate-900">
                        {formatCurrency(item.basicSalary, currency)}
                      </td>
                      <td className="py-3.5 px-4 text-center text-xs font-bold text-slate-600">
                        {item.totalAbsentLeaveDays} days
                      </td>
                      <td className="py-3.5 px-4 text-right text-xs font-bold text-amber-700">
                        {formatCurrency(item.leaveDeduction, currency)}
                      </td>
                      <td className="py-3.5 px-4 text-right text-xs font-bold text-indigo-700">
                        {formatCurrency(item.totalAdvance, currency)}
                      </td>
                      <td className="py-3.5 px-4 text-right text-xs font-bold text-rose-700">
                        {formatCurrency(item.totalPenalty, currency)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-black">
                        <span className="bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-lg border border-emerald-300 text-sm">
                          {formatCurrency(item.remainingSalary, currency)}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() => setSelectedSlipStaff(item.staff)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 mx-auto transition-colors cursor-pointer shadow-2xs"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Print Slip</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Salary Slip Modal */}
        <SalarySlipModal
          isOpen={selectedSlipStaff !== null}
          onClose={() => setSelectedSlipStaff(null)}
          staff={selectedSlipStaff}
          canteen={state.canteens.find((c) => c.id === selectedSlipStaff?.canteenId)}
          currencySymbol={currency}
          attendanceRecords={state.attendanceRecords || []}
          staffFinancials={state.staffFinancials || []}
        />
      </div>
    </div>
  );
};

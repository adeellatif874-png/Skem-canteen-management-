import React, { useState, useEffect } from 'react';
import {
  Settings,
  DollarSign,
  Download,
  Upload,
  RefreshCw,
  Database,
  CheckCircle,
  CheckCircle2,
  AlertTriangle,
  Smartphone,
  Laptop,
  Share2,
  MoreVertical,
  AppWindow,
  ShieldCheck,
  Lock,
  Building2,
  Globe,
  ExternalLink,
  Zap,
} from 'lucide-react';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { AppState } from '../types';
import { ConfirmModal } from './ConfirmModal';
import { InstallModal } from './InstallModal';

import { recoverBrowserBackups } from '../lib/storage';

interface SettingsViewProps {
  state: AppState;
  onUpdateCurrency: (symbol: string) => void;
  onRestoreState: (newState: AppState) => void;
  onResetDemoData: () => void;
  onUpdatePin?: (newPin: string) => void;
  onLockApp?: () => void;
  onUpdateLockedCanteen?: (canteenId: string) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  state,
  onUpdateCurrency,
  onRestoreState,
  onResetDemoData,
  onUpdatePin,
  onLockApp,
  onUpdateLockedCanteen,
}) => {
  const [currencySymbol, setCurrencySymbol] = useState(state.currencySymbol || 'Rs.');
  const [pinInput, setPinInput] = useState(state.pinCode || '');
  const [pinSavedMsg, setPinSavedMsg] = useState(false);
  const [resetModalOpen, setResetModalOpen] = useState(false);
  const [installModalOpen, setInstallModalOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [restoreMessage, setRestoreMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Download Pre-built Deployment Bundle ZIP (Works for both Vercel & Netlify)
  const handleDownloadDeployZip = async (platform: 'Vercel' | 'Netlify' = 'Netlify') => {
    setIsZipping(true);
    try {
      // First try deployment-bundle.zip
      let res = await fetch('/deployment-bundle.zip');
      if (!res.ok) {
        res = await fetch('/netlify-deploy-bundle.zip');
      }
      if (res.ok) {
        const blob = await res.blob();
        saveAs(blob, `SKEM_Canteen_Management_${platform}_Ready.zip`);
        setRestoreMessage({
          type: 'success',
          text: `Latest ${platform} Deployment ZIP downloaded! Ab aap is ZIP file ko extract kar ke ${platform} dashboard par drop kar sakte hain.`,
        });
        setIsZipping(false);
        return;
      }
      
      // Fallback
      const zip = new JSZip();
      zip.file('_redirects', '/*  /index.html  200\n');
      const blob = await zip.generateAsync({ type: 'blob' });
      saveAs(blob, `SKEM_Canteen_Management_${platform}_Ready.zip`);

      setRestoreMessage({
        type: 'success',
        text: `${platform} ZIP downloaded! Drag this file into your ${platform} dashboard to update live site!`,
      });
    } catch (err) {
      console.error(err);
      setRestoreMessage({
        type: 'error',
        text: 'Failed to download deployment ZIP file. Please try again.',
      });
    } finally {
      setIsZipping(false);
    }
  };

  // Listen for PWA beforeinstallprompt event
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallApp = async () => {
    if (deferredPrompt) {
      try {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
          setIsInstalled(true);
        }
        setDeferredPrompt(null);
      } catch (e) {
        console.error(e);
      }
    }
    setInstallModalOpen(true);
  };

  const handleSaveCurrency = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateCurrency(currencySymbol.trim() || 'Rs.');
  };

  // Export JSON Backup
  const handleExportBackup = () => {
    const jsonStr = JSON.stringify(state, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SKEM_Canteens_Backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Import JSON Backup
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (
          parsed &&
          Array.isArray(parsed.canteens) &&
          Array.isArray(parsed.dailyEntries) &&
          Array.isArray(parsed.staffList)
        ) {
          onRestoreState(parsed);
          setRestoreMessage({
            type: 'success',
            text: 'Database successfully restored from JSON backup file!',
          });
        } else {
          setRestoreMessage({
            type: 'error',
            text: 'Invalid backup file structure. File must be a SKEM Canteens JSON backup.',
          });
        }
      } catch (err) {
        setRestoreMessage({
          type: 'error',
          text: 'Failed to parse JSON file. Please verify file integrity.',
        });
      }
    };
    reader.readAsText(file);
  };

  const handleScanBrowserBackups = () => {
    const result = recoverBrowserBackups();
    if (
      result.recoveredEntries > 0 ||
      result.recoveredStaff > 0 ||
      result.recoveredAttendance > 0 ||
      result.recoveredFinancials > 0
    ) {
      onRestoreState(result.mergedState);
      setRestoreMessage({
        type: 'success',
        text: `Browser memory scanned! Restored ${result.recoveredEntries} entries, ${result.recoveredStaff} staff members, ${result.recoveredAttendance} attendance logs, and ${result.recoveredFinancials} financial records.`,
      });
    } else {
      setRestoreMessage({
        type: 'error',
        text: 'No additional historical backups found in this browser domain storage.',
      });
    }
  };

  return (
    <div className="space-y-6 pb-12 max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs">
        <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
          <Settings className="w-7 h-7 text-emerald-600" />
          <span>SKEM Canteens Management — Settings & App Install</span>
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Install app directly on mobile/desktop, configure currency, backup/restore database, or wipe entries.
        </p>
      </div>

      {restoreMessage && (
        <div
          className={`p-4 rounded-2xl border text-sm font-semibold flex items-center gap-2 ${
            restoreMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-rose-50 border-rose-200 text-rose-900'
          }`}
        >
          {restoreMessage.type === 'success' ? (
            <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
          )}
          <span>{restoreMessage.text}</span>
        </div>
      )}

      {/* Live Vercel Production Deployment Card */}
      <div className="bg-gradient-to-br from-black via-slate-900 to-zinc-900 text-white rounded-2xl p-6 shadow-md border border-slate-700/60 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-white fill-current" viewBox="0 0 1155 1000">
                <path d="m577.3 0 577.4 1000H0z" />
              </svg>
              <h2 className="text-xl font-black tracking-tight flex items-center gap-2">
                <span>Vercel Live Production</span>
                <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-emerald-400/30 uppercase tracking-wider flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Connected
                </span>
              </h2>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed max-w-xl">
              Your application is connected to Vercel at{' '}
              <a
                href="https://skemcanteenmanagement.vercel.app/"
                target="_blank"
                rel="noreferrer"
                className="underline text-cyan-300 font-bold hover:text-cyan-200"
              >
                https://skemcanteenmanagement.vercel.app/
              </a>
              . Built-in SPA rewrites (<code>vercel.json</code>) are pre-configured.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
            <button
              onClick={() => handleDownloadDeployZip('Vercel')}
              disabled={isZipping}
              className="bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black text-sm px-5 py-3 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all shadow-lg hover:scale-105 disabled:opacity-50"
            >
              <Download className="w-4 h-4 text-slate-950" />
              <span>{isZipping ? 'Downloading...' : 'Download Vercel ZIP'}</span>
            </button>
            <a
              href="https://skemcanteenmanagement.vercel.app/"
              target="_blank"
              rel="noreferrer"
              className="bg-white hover:bg-zinc-100 text-black font-black text-sm px-5 py-3 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all shadow-lg hover:scale-105"
            >
              <span>Open Vercel App</span>
              <ExternalLink className="w-4 h-4 text-black" />
            </a>
          </div>
        </div>

        {/* Vercel Update Instructions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-zinc-800 text-xs">
          <div className="bg-zinc-900/90 p-3.5 rounded-xl border border-zinc-800 space-y-1">
            <div className="font-bold text-white flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Auto-Deploy via GitHub</span>
            </div>
            <p className="text-zinc-400 leading-normal">
              Agar aap ka Vercel project GitHub repository se linked hai, to jab bhi aap GitHub par changes export ya push karte hain, Vercel foran nayi build create kar ke live link ko update kar deta hai.
            </p>
          </div>

          <div className="bg-zinc-900/90 p-3.5 rounded-xl border border-zinc-800 space-y-1">
            <div className="font-bold text-white flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-cyan-400" />
              <span>Vercel Dashboard / CLI</span>
            </div>
            <p className="text-zinc-400 leading-normal">
              Aap <a href="https://vercel.com/dashboard" target="_blank" rel="noreferrer" className="underline text-cyan-300 font-semibold">vercel.com</a> dashboard mein ja kar "Redeploy" par click kar sakte hain, ya terminal mein <code>vercel --prod</code> run kar sakte hain.
            </p>
          </div>
        </div>
      </div>

      {/* 24/7 Netlify Permanent Deployment Card */}
      <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-blue-950 text-white rounded-2xl p-6 shadow-md border border-indigo-700/40 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Globe className="w-6 h-6 text-cyan-400" />
              <h2 className="text-xl font-black tracking-tight flex items-center gap-2">
                <span>Deploy to Netlify (24/7 Free Permanent Hosting)</span>
                <span className="bg-cyan-500/20 text-cyan-300 text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-cyan-400/30 uppercase tracking-wider">
                  Recommended
                </span>
              </h2>
            </div>
            <p className="text-xs text-indigo-200 leading-relaxed max-w-xl">
              Download the complete Netlify project package directly with 1 click. Drag and drop this ZIP into <strong>app.netlify.com/drop</strong> to get your permanent lifetime URL that opens in 1 second and never goes to sleep!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
            <button
              onClick={() => handleDownloadDeployZip('Netlify')}
              disabled={isZipping}
              className="bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-black text-sm px-6 py-3 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all shadow-lg hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Zap className="w-5 h-5 text-slate-950 fill-slate-950" />
              <span>{isZipping ? 'Creating ZIP Package...' : 'Download Netlify ZIP'}</span>
            </button>
          </div>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 border-t border-indigo-800/60 text-xs">
          <div className="bg-indigo-950/60 p-3.5 rounded-xl border border-indigo-800/50 space-y-1">
            <div className="font-bold text-cyan-300 flex items-center gap-1.5">
              <span className="bg-cyan-400 text-slate-950 w-5 h-5 rounded-full flex items-center justify-center font-black text-[10px]">1</span>
              <span>Click Download Button</span>
            </div>
            <p className="text-indigo-200 leading-normal">
              Click <strong>"Download Netlify ZIP"</strong> above to get <code>SKEM_Canteen_Management_Netlify_247_Project.zip</code>.
            </p>
          </div>

          <div className="bg-indigo-950/60 p-3.5 rounded-xl border border-indigo-800/50 space-y-1">
            <div className="font-bold text-cyan-300 flex items-center gap-1.5">
              <span className="bg-cyan-400 text-slate-950 w-5 h-5 rounded-full flex items-center justify-center font-black text-[10px]">2</span>
              <span>Open Netlify Drop</span>
            </div>
            <p className="text-indigo-200 leading-normal">
              Open <a href="https://app.netlify.com/drop" target="_blank" rel="noreferrer" className="underline text-cyan-300 font-bold inline-flex items-center gap-0.5">app.netlify.com/drop <ExternalLink className="w-3 h-3" /></a> in your browser (login with Google).
            </p>
          </div>

          <div className="bg-indigo-950/60 p-3.5 rounded-xl border border-indigo-800/50 space-y-1">
            <div className="font-bold text-cyan-300 flex items-center gap-1.5">
              <span className="bg-cyan-400 text-slate-950 w-5 h-5 rounded-full flex items-center justify-center font-black text-[10px]">3</span>
              <span>Drag & Drop ZIP</span>
            </div>
            <p className="text-indigo-200 leading-normal">
              Drag the downloaded ZIP file onto Netlify. Your app is live 24/7 forever with instant loading!
            </p>
          </div>
        </div>
      </div>

      {/* Direct App Installation Section */}
      <div className="bg-gradient-to-br from-emerald-900 to-slate-900 text-white rounded-2xl p-6 shadow-md space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Smartphone className="w-6 h-6 text-emerald-400" />
              <h2 className="text-xl font-black tracking-tight">
                Install SKEM App on Mobile / PC
              </h2>
            </div>
            <p className="text-xs text-emerald-200 leading-relaxed max-w-xl">
              Install SKEM Canteens Management as an app on your Android, iPhone, or Desktop to launch it directly from your home screen without opening a web browser.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
            <button
              onClick={async () => {
                try {
                  if ('caches' in window) {
                    const keys = await caches.keys();
                    await Promise.all(keys.map((k) => caches.delete(k)));
                  }
                  if ('serviceWorker' in navigator) {
                    const registrations = await navigator.serviceWorker.getRegistrations();
                    for (const reg of registrations) await reg.unregister();
                  }
                } catch (e) {
                  // Ignore
                }
                window.location.reload();
              }}
              className="bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-3 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all border border-emerald-600/60"
              title="Force check for new code updates, clear cache and reload"
            >
              <RefreshCw className="w-4 h-4 text-emerald-300" />
              <span>Reload / Check Updates</span>
            </button>

            <button
              onClick={handleInstallApp}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm px-6 py-3 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all shadow-lg hover:scale-105"
            >
              <Download className="w-5 h-5" />
              <span>{isInstalled ? 'App Installed (Re-install)' : 'Install App Now'}</span>
            </button>
          </div>
        </div>

        {/* Instructions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-emerald-800/60 text-xs">
          <div className="bg-emerald-950/60 p-3.5 rounded-xl border border-emerald-800/50 space-y-1.5">
            <div className="font-bold text-emerald-300 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span>Android / Google Chrome Installation:</span>
            </div>
            <p className="text-slate-300 leading-normal">
              1. Tap the green <strong>"Install App Now"</strong> button above.<br />
              2. Or tap browser menu <strong>(⋮)</strong> at top right -&gt; select <strong>"Add to Home screen"</strong> or <strong>"Install app"</strong>.
            </p>
          </div>

          <div className="bg-emerald-950/60 p-3.5 rounded-xl border border-emerald-800/50 space-y-1.5">
            <div className="font-bold text-emerald-300 flex items-center gap-1.5">
              <Share2 className="w-4 h-4 text-emerald-400" />
              <span>iPhone / iOS Safari Installation:</span>
            </div>
            <p className="text-slate-300 leading-normal">
              1. Tap the Safari Share icon <strong>(⎋)</strong> at the bottom of screen.<br />
              2. Scroll down and tap <strong>"Add to Home Screen"</strong> -&gt; tap <strong>Add</strong> at top right.
            </p>
          </div>
        </div>
      </div>

      {/* Security PIN & Manager App Lock */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <span>Manager Security PIN & App Lock</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Set a 4-digit security PIN to lock access to canteen financials & reports when away.
            </p>
          </div>

          {state.pinCode && onLockApp && (
            <button
              onClick={onLockApp}
              className="bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer border border-rose-200 shrink-0"
            >
              <Lock className="w-4 h-4" />
              <span>Lock / Log Out Now</span>
            </button>
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (onUpdatePin) {
              onUpdatePin(pinInput.trim());
              setPinSavedMsg(true);
              setTimeout(() => setPinSavedMsg(false), 3000);
            }
          }}
          className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3"
        >
          <div className="relative sm:w-60">
            <input
              type="password"
              maxLength={6}
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value)}
              placeholder="e.g. 1234 (Leave blank to disable PIN)"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-4 py-2.5 text-sm font-extrabold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 tracking-widest"
            />
          </div>

          <button
            type="submit"
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm px-5 py-2.5 rounded-xl transition-colors cursor-pointer shadow-xs"
          >
            {pinInput.trim() ? 'Save / Enable Security PIN' : 'Remove Security PIN'}
          </button>

          {pinSavedMsg && (
            <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
              <CheckCircle className="w-4 h-4" /> PIN Updated Successfully!
            </span>
          )}
        </form>

        <p className="text-[11px] text-slate-400">
          * If PIN is enabled, opening the app will require entering this code to view sales or manage staff.
        </p>
      </div>

      {/* Canteen Branch Data Isolation Lock */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-emerald-600" />
            <span>Multi-Canteen Branch Access Lock</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            When giving this app to a specific canteen branch manager, lock the app to their branch so they can only view & work on their own canteen's data.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <select
            value={state.lockedCanteenId || ''}
            onChange={(e) => {
              if (onUpdateLockedCanteen) {
                onUpdateLockedCanteen(e.target.value);
              }
            }}
            className="bg-slate-50 border border-slate-300 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="">Full Manager Access (All Canteens Visible)</option>
            {state.canteens.map((c) => (
              <option key={c.id} value={c.id}>
                🔒 Lock Device to: {c.name}
              </option>
            ))}
          </select>

          {state.lockedCanteenId ? (
            <span className="text-xs font-bold text-amber-700 bg-amber-50 px-3 py-2 rounded-xl border border-amber-200 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                Device is locked to <strong>{state.canteens.find((c) => c.id === state.lockedCanteenId)?.name}</strong>
              </span>
            </span>
          ) : (
            <span className="text-xs font-medium text-slate-500">
              Currently showing all canteens
            </span>
          )}
        </div>
      </div>

      {/* Currency Settings */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-emerald-600" />
          <span>Currency Symbol Preference</span>
        </h2>
        <p className="text-xs text-slate-500">
          Choose the default currency label displayed across daily entries, reports, and dashboards.
        </p>

        <form onSubmit={handleSaveCurrency} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <input
            type="text"
            value={currencySymbol}
            onChange={(e) => setCurrencySymbol(e.target.value)}
            placeholder="e.g. Rs. or PKR"
            className="bg-slate-50 border border-slate-300 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 sm:w-48"
          />

          <button
            type="submit"
            className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm px-5 py-2.5 rounded-xl transition-colors cursor-pointer"
          >
            Save Currency
          </button>
        </form>
      </div>

      {/* Database Backup & Restore */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Database className="w-5 h-5 text-emerald-600" />
            <span>5-Year Long-Term Data Security & Backup</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Ensure your sales, staff attendance, advances, and reports are permanently safe even if you change phones, tablets, or laptops 5 or 10 years later.
          </p>
        </div>

        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-xs text-emerald-950 space-y-2">
          <div className="font-bold flex items-center gap-1.5 text-emerald-950 text-sm">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <span>✅ Live Firebase Cloud Auto-Sync Active (Safe Forever)</span>
          </div>
          <ul className="list-disc pl-5 space-y-1 text-emerald-900 font-medium">
            <li><strong>Automatic Cloud Save:</strong> Every sale, expense, staff record, and attendance entry you add is automatically saved to Google Firebase Cloud Database in real time.</li>
            <li><strong>Multi-Device Access:</strong> Open this app link on your phone, laptop, or tablet—your data syncs automatically!</li>
            <li><strong>Offline + Cloud Backup:</strong> Data is saved both locally on your device and in the cloud. You can also download a manual JSON backup file anytime below for offline safety.</li>
          </ul>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* Scan & Recover Local Backups */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Scan Browser Storage</h3>
              <p className="text-xs text-slate-500 mt-1">
                Scans local browser storage for any previously saved records or local backups and restores them.
              </p>
            </div>
            <button
              onClick={handleScanBrowserBackups}
              className="bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs px-4 py-2.5 rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-xs"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Scan & Recover Data</span>
            </button>
          </div>

          {/* Download Backup */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Export Full Backup</h3>
              <p className="text-xs text-slate-500 mt-1">
                Downloads all canteens, daily sales entries, staff records, attendance, and advances into a JSON file.
              </p>
            </div>
            <button
              onClick={handleExportBackup}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs px-4 py-2.5 rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-xs"
            >
              <Download className="w-4 h-4" />
              <span>Download JSON Backup</span>
            </button>
          </div>

          {/* Import Restore */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Restore from File</h3>
              <p className="text-xs text-slate-500 mt-1">
                Upload a JSON backup file to restore system records on any new phone or computer.
              </p>
            </div>
            <label className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs px-4 py-2.5 rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-xs">
              <Upload className="w-4 h-4" />
              <span>Select Backup File</span>
              <input
                type="file"
                accept=".json"
                onChange={handleImportBackup}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>

      {/* Factory Reset / Wipe Data */}
      <div className="bg-white rounded-2xl p-6 border border-rose-200 shadow-xs space-y-4">
        <h2 className="text-lg font-bold text-rose-900 flex items-center gap-2">
          <RefreshCw className="w-5 h-5 text-rose-600" />
          <span>Clear All Entries & Reset Database</span>
        </h2>
        <p className="text-xs text-slate-500">
          Delete all daily entries, attendance records, staff list, and financial history so you can start entering live data for your canteens.
        </p>

        <button
          onClick={() => setResetModalOpen(true)}
          className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-colors cursor-pointer shadow-xs"
        >
          Clear All Entries & Start Fresh
        </button>
      </div>

      {/* Confirmation Modal for Reset */}
      <ConfirmModal
        isOpen={resetModalOpen}
        title="Clear All System Entries?"
        message="Are you sure you want to delete all entries? This will give you a clean database ready for live data entry."
        confirmLabel="Clear All Data"
        onConfirm={() => {
          onResetDemoData();
          setResetModalOpen(false);
          setRestoreMessage({
            type: 'success',
            text: 'System database cleared successfully! Ready for live data entry.',
          });
        }}
        onClose={() => setResetModalOpen(false)}
      />

      {/* App Installation Modal */}
      <InstallModal
        isOpen={installModalOpen}
        onClose={() => setInstallModalOpen(false)}
        deferredPrompt={deferredPrompt}
        onNativeInstallTriggered={() => setIsInstalled(true)}
      />
    </div>
  );
};
